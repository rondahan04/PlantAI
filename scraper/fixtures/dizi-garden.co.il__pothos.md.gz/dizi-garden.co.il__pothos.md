[Skip to content](https://dizi-garden.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#main)

*   [](https://www.facebook.com/pages/category/Product-Service/DIZIgarden-109882140911359/ "עקבו אחרינו בפייסבוק")[](https://www.instagram.com/dizigarden/ "עקבו אחרינו באינסטגרם")[](mailto:dizigarden@gmail.com "שלח לנו דואר אלקטרוני")[](tel:050-5900190 "Call us") 
*   [וואטסאפ](https://wa.me/972505900190) 

*    Dizigarden 

 דיזיגארדן - עציץ רק ₪60 

 משלוחים מהירים בתל אביב רמת גן וגבעתיים - הזמינו עכשיו 

*   [התחבר](https://dizi-garden.co.il/my-account/)

*   [](https://www.facebook.com/pages/category/Product-Service/DIZIgarden-109882140911359/ "עקבו אחרינו בפייסבוק")[](https://www.instagram.com/dizigarden/ "עקבו אחרינו באינסטגרם")[](mailto:dizigarden@gmail.com "שלח לנו דואר אלקטרוני")[](tel:050-5900190 "Call us") 
*   [וואטסאפ](https://wa.me/972505900190) 

[![Image 1: דיזיגארדן](https://dizi-garden.co.il/wp-content/uploads/2021/11/logo2.jpg)![Image 2: דיזיגארדן](https://dizi-garden.co.il/wp-content/uploads/2021/11/logo2.jpg)](https://dizi-garden.co.il/ "דיזיגארדן - עציץ רק ₪60")

*   [](https://dizi-garden.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

*   [**0**](https://dizi-garden.co.il/cart/ "סל קניות")#### סל קניות

  אין מוצרים בסל הקניות.    

*   [צמחים](https://dizi-garden.co.il/)
    *   [צמחים ב₪35](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9135/)
    *   [צמחים ב₪60](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9160/)

*   [כלים](https://dizi-garden.co.il/%d7%9b%d7%9c%d7%99%d7%9d/)
*   [צמח + כלי](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99/)
*   [מוצרים נלווים](https://dizi-garden.co.il/%d7%9e%d7%95%d7%a6%d7%a8%d7%99%d7%9d-%d7%a0%d7%9c%d7%95%d7%95%d7%99%d7%9d/)
*   [צור קשר](https://dizi-garden.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)
*   [](https://dizi-garden.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
    *   חיפוש עבור:       

*   [סל קניות / ₪0**0**](https://dizi-garden.co.il/cart/ "סל קניות")
    *   אין מוצרים בסל הקניות. 

לא נמצאו מוצרים התואמים את בחירתך.

דיזיגארדן

עציץ רק ₪60

צור קשר

# דיזנגוף 84, תל־אביב

*ניתן לעמוד עם הרכב ברחוב בר כוכבא 52 לאיסוף עצמי

# [050-5900190](tel:0505900190)

שעות פעילות:

א’-ה’:

10:00-20:00

יום ו’:

09:00-16:00

 Copyright 2026 © **דיזיגארדן**

[](https://dizi-garden.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#top)

*   חיפוש עבור:       
*   [צמחים](https://dizi-garden.co.il/)
    *   [צמחים ב₪35](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9135/)
    *   [צמחים ב₪60](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9160/)

*   [כלים](https://dizi-garden.co.il/%d7%9b%d7%9c%d7%99%d7%9d/)
*   [צמח + כלי](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99/)
*   [מוצרים נלווים](https://dizi-garden.co.il/%d7%9e%d7%95%d7%a6%d7%a8%d7%99%d7%9d-%d7%a0%d7%9c%d7%95%d7%95%d7%99%d7%9d/)
*   [צור קשר](https://dizi-garden.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)
*   [התחבר](https://dizi-garden.co.il/my-account/)

![Image 3: סמל נגישות](https://dizi-garden.co.il/wp-content/plugins/accessibility-light/assets/img/wheelchair.png)

סגור את סרגל הכלים של נגישות

#### נגישות

*       *   _visibility\_off_ השבת את ההבזקים

    *   _title_ סמן כותרות

    *   _settings_ צבע רקע

*       *   _zoom\_out_ זום (הקטנה)

    *   _zoom\_in_ זום (הגדלה)

*       *   _remove\_circle\_outline_ הקטנת גופן

    *   _add\_circle\_outline_ הגדלת גופן

    *   _spellcheck_ גופן קריא

*       *   _brightness\_high_ ניגודיות בהירה

    *   _brightness\_low_ ניגודיות כהה

*       *   _format\_underlined_ הוסף קו תחתון לקישורים

    *   _font\_download_ סמן קישורים

*       *   לאפס את כל האפשרויות _cached_

    *   [![Image 4: נגישות לייט](https://dizi-garden.co.il/wp-content/plugins/accessibility-light/assets/img/accessibility-light-logolight80.png)](https://dizi-garden.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product)

### התחבר

שם משתמש או כתובת אימייל*

סיסמה*

- [x] זכור אותי התחבר

[איפוס סיסמה](https://dizi-garden.co.il/my-account/lost-password/)

### הרשמה

כתובת אימייל*

סיסמה*

Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [מדיניות פרטיות](https://dizi-garden.co.il/%d7%9e%d7%93%d7%99%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%a8%d7%98%d7%99%d7%95%d7%aa/).

הרשמה