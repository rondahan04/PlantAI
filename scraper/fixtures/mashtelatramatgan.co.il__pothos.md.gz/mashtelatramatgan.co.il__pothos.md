[דילוג לתוכן](https://mashtelatramatgan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#content)

- [קטלוג צמחים](https://mashtelatramatgan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
  - [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
  - [צמחים לצל מלא](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a6%d7%9c-%d7%9e%d7%9c%d7%90/)
  - [צמחים לשמש מלאה](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/)
    - [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/)
    - [עצי הדר](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/%d7%a2%d7%a6%d7%99-%d7%94%d7%93%d7%a8/)
    - [קקטוסים](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d/)
    - [סוקולנטים](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d-%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/)
  - [צמחים חצי צל חצי שמש](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%97%d7%a6%d7%99-%d7%a6%d7%9c-%d7%97%d7%a6%d7%99-%d7%a9%d7%9e%d7%a9/)
  - [צמחים שקשה להרוג](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%a9%d7%a7%d7%a9%d7%94-%d7%9c%d7%94%d7%a8%d7%95%d7%92/)
  - [המיוחדים מהולנד](https://mashtelatramatgan.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%9e%d7%94%d7%95%d7%9c%d7%a0%d7%93/)
  - [זרעים ופקעות](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%a2%d7%99%d7%9d-%d7%95%d7%a4%d7%a7%d7%a2%d7%95%d7%aa/)
  - [צמחי תבלין](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%aa%d7%91%d7%9c%d7%99%d7%9f/)
  - [צמח \+ כלי as is](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99-as-is/)
- [קטלוג אדניות וכלים](https://mashtelatramatgan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
  - [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/)
  - [תלייה](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%aa%d7%9c%d7%99%d7%99%d7%94/)
  - [קרמיקה](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
  - [פיבר](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a4%d7%99%d7%91%d7%a8/)
  - [פוליאתילן](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a4%d7%95%d7%9c%d7%99%d7%90%d7%aa%d7%99%d7%9c%d7%9f/)
  - [זכוכית](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%96%d7%9b%d7%95%d7%9b%d7%99%d7%aa/)
  - [פלסטיק](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
  - [עץ](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a2%d7%a5/)
  - [קש](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a7%d7%a9/)
- [כלי גינון השקיה ועוד](https://mashtelatramatgan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
  - [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/)
  - [השקיה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%94%d7%a9%d7%a7%d7%99%d7%94/)
  - [צנרת](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%a6%d7%a0%d7%a8%d7%aa/)
  - [מחברי השקיה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%9e%d7%97%d7%91%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%94/)
  - [אביזרי השקיה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%94/)
  - [מערכות השקיה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%9e%d7%a2%d7%a8%d7%9b%d7%95%d7%aa-%d7%94%d7%a9%d7%a7%d7%99%d7%94/)
  - [אביזרי גינה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%94/)
  - [תאורה סולארית](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%aa%d7%90%d7%95%d7%a8%d7%94-%d7%a1%d7%95%d7%9c%d7%90%d7%a8%d7%99%d7%aa/)
  - [מזרקות](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%9e%d7%96%d7%a8%d7%a7%d7%95%d7%aa/)
- [אדמת שתילה ועוד](https://mashtelatramatgan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
  - [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/)
  - [תערובת שתילה](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94/)
  - [דשנים והדברה](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%95%d7%94%d7%93%d7%91%d7%a8%d7%94/)
  - [טוף](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%98%d7%95%d7%a3/)
  - [חלוקי נחל](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%97%d7%9c%d7%95%d7%a7%d7%99-%d7%a0%d7%97%d7%9c/)
- [זרי פרחים](https://mashtelatramatgan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
  - [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  - [זרי פרחים](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  - [מארזי פרחים](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%9e%d7%90%d7%a8%d7%96%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  - [זרים לראש](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%a8%d7%90%d7%a9/)
  - [זרי כלה](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
  - [קישוט רכבים](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%a7%d7%99%d7%a9%d7%95%d7%98-%d7%a8%d7%9b%d7%91%d7%99%d7%9d/)
- [צמחיה מלאכותית](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%94-%d7%9e%d7%9c%d7%90%d7%9b%d7%95%d7%aa%d7%99%d7%aa/)
- [קטלוג ריהוט גן](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a8%d7%99%d7%94%d7%95%d7%98-%d7%92%d7%9f/)
- [גיפט-קארד מתנות ועוד](https://mashtelatramatgan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
  - [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/)
  - [יינות ומארזי שוקולד](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/%d7%99%d7%99%d7%a0%d7%95%d7%aa-%d7%95%d7%9e%d7%90%d7%a8%d7%96%d7%99-%d7%a9%d7%95%d7%a7%d7%95%d7%9c%d7%93/)
  - [בלוני הליום](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/%d7%91%d7%9c%d7%95%d7%a0%d7%99-%d7%94%d7%9c%d7%99%d7%95%d7%9d/)
  - [כרטיסי ברכה](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/%d7%9b%d7%a8%d7%98%d7%99%d7%a1%d7%99-%d7%91%d7%a8%d7%9b%d7%94-%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/)
  - [מתנות וקישוטי נוי](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a7%d7%99%d7%a9%d7%95%d7%98%d7%99-%d7%a0%d7%95%d7%99/)
- [אודותינו](https://mashtelatramatgan.co.il/%d7%90%d7%95%d7%93%d7%95%d7%aa%d7%99%d7%a0%d7%95/)
- [השירותים שלנו](https://mashtelatramatgan.co.il/%d7%94%d7%a9%d7%99%d7%a8%d7%95%d7%aa%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
- [טלפון: 03-7509080](tel:03-7509080)

# Search Results for: פותוס

מחיר

₪ 0 — ₪ 0

גובה מקסימלי

0cm — 1000cm

רוחב מקסימלי

0cm — 1000cm

גודל

רבע ליטר

חצי ליטר

תחתית עגולה 37 ס"מ

תחתית עגולה 46 ס"מ

לעציץ 26

לעציץ 29

לעציץ 36

לעציץ 33

לעציץ 41

לעציץ 49

לעציץ 22

עציץ 7X12

דלי 25 ליטר

עציץ 9

19

עד רוחב אדנית 16 ס''מ

עד רוחב אדנית 20 ס''מ

עציץ 18

עציץ 49

עציץ 15

5 ליטר

1 ליטר

גדול מאוד

עציץ 22

עציץ 26

עציץ 29

עציץ 33

עציץ 36

עציץ 41

קערה 20

ענק

בינוני

עציץ 12

20

4 ליטר

10 ליטר

15

24

15 ליטר

גדול

קטן

תנאי השקיה

השקיה בראש הפרח כאשר המים נאגרים בתחתית העלים

השקייה מועטה

כאשר האדמה יבשה

לא לייבש לחלוטין

לשמור על אדמה לחה

תנאי תאורה

חצי צל (עד 3 שעות קרינת שמש ישירה)

חצי צל (עד 3 שעות קרינת שמש ישירה)-צל מלא (ללא קרינת שמש ישירה)

מקום מואר

צל מלא (ללא קרינת שמש ישירה)

צל מלא (ללא קרינת שמש ישירה) -חצי צל (עד 3 שעות קרינת שמש ישירה)

שמש מלאה (לפחות 4 שעות שמש ישירה)

עונתיות

עונתי

פריחה עונתית

רב שנתי

### מוצרים לא נמצאו

![](https://mashtelatramatgan.co.il/wp-content/uploads/2020/01/good.svg)

התאמת צמחים מדוייקת

![](https://mashtelatramatgan.co.il/wp-content/uploads/2020/01/sofa.svg)

מכל מקום ובכל זמן

![](https://mashtelatramatgan.co.il/wp-content/uploads/2020/01/award.svg)

איכות ללא פשרות

![](https://mashtelatramatgan.co.il/wp-content/uploads/2020/01/truck.svg)

מגיעים עד אליך