*      

[![Image 1: משתלת פרח וגן](https://perahvagan.co.il/wp-content/uploads/2020/04/logo.png)](https://perahvagan.co.il/)

[משתלת פרח וגן](https://perahvagan.co.il/)

## משתלה רמת שרונית

*   [](https://perahvagan.co.il/my-account/)
*   [0](https://perahvagan.co.il/cart/)

*   [ראשי](https://perahvagan.co.il/)
*   [אודות המשתלה](https://perahvagan.co.il/about-us/)
*   [החנות](https://perahvagan.co.il/shop)
*   [פרח וגן לעסקים](https://perahvagan.co.il/contact-us/)

*    ### משתלת פרח וגן

צמחים ופורחים לבית - עד הבית. 
*    ### מתנות לכל מטרה

זר פרחים לאישה? גינת תבלינים לסבתא? עציץ לאמא ליום האם? יש לנו את הכל. 
*    ### צמחים, פרחים ועוד!

גללו למטה לראות את המוצרים שלנו 

### החנות הדיגיטלית של פרח וגן

מבין כל מוצרינו, בחרנו את המובחרים שביותר המותאמים לחוויות השונות שלכם. קונים מתנה לאהוב? מעוניינים בשדרוג הבית עם צמחייה? בא לכם תוספת נחמדה לגינה בבית? בחרו עכשיו את הקטגוריה העונה על המטרה שלכם! 

 לא נמצאו מוצרים התואמים את בחירתך. 

![Image 2: logo](https://perahvagan.co.il/wp-content/uploads/logo-footer-2.png)

Leave this field empty if you're human:  

[](https://www.facebook.com/perahvagan/)[](https://www.instagram.com/perah_vagan/)

דרך משה סנה 199 רמת השרון, [03-648-0818](tel:036480818)

*   [אודות](https://perahvagan.co.il/about-us/)
*   [חנות](https://perahvagan.co.il/shop/)
*   [תנאי שימוש](https://perahvagan.co.il/term-conditions/)
*   [ביטול עסקה](https://perahvagan.co.il/refund_returns/)
*   [מדיניות פרטיות](https://perahvagan.co.il/privacy-policy/)
*   [הסדרי נגישות](https://perahvagan.co.il/accessibility/)

[](https://perahvagan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

*   No products in the cart.

[](https://perahvagan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [ראשי](https://perahvagan.co.il/)
*   [אודות המשתלה](https://perahvagan.co.il/about-us/)
*   [החנות](https://perahvagan.co.il/shop)
*   [פרח וגן לעסקים](https://perahvagan.co.il/contact-us/)

*   [Login](https://perahvagan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

[Forgot?](https://perahvagan.co.il/my-account/lost-password/)

- [x]  Remember me Log in

[Close](https://perahvagan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

[](https://perahvagan.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)