**משלוחים חינם בקנייה מעל 350 ₪ בתל אביב בלבד | לייעוץ והזמנות: [058-5163707](https://wa.me/972585163707)**

[![Image 2: משתלה אורבנית](https://mashtela-urbanit.co.il/images/logo.svg)](https://mashtela-urbanit.co.il/)

*   [ראשי](https://mashtela-urbanit.co.il/)
*   [קטלוג מוצרים](https://mashtela-urbanit.co.il/catalog)
*   [אורבנית לעסקים](https://mashtela-urbanit.co.il/about-2)
*   [הרשמה](https://mashtela-urbanit.co.il/register)
*   [הסל שלי](https://mashtela-urbanit.co.il/%D7%94%D7%A1%D7%9C-%D7%A9%D7%9C%D7%99)
*   [שאלות נפוצות](https://mashtela-urbanit.co.il/faq)
*   [צור קשר](https://mashtela-urbanit.co.il/contect)

[Menu](https://mashtela-urbanit.co.il/#)

[![Image 3: insta1](https://mashtela-urbanit.co.il/images/insta1.png)![Image 4: face](https://mashtela-urbanit.co.il/images/jsn_is_thumbs/images/face.png)](https://www.instagram.com/mashtela.urbanit/)

[שלום אורח](https://mashtela-urbanit.co.il/register/editaddress "התחבר")

![Image 5](https://mashtela-urbanit.co.il//templates/sitetemplate/images/cart-top-arrow.png)

 אין צמחים בסל

מוצרים שתבחר יוצגו כאן

[](https://mashtela-urbanit.co.il/catalog/matanot)

[.](https://mashtela-urbanit.co.il/catalog/gifts_tu_bishvat)

*   ![Image 6: 3 2](https://mashtela-urbanit.co.il/images/Home-slider/2023/3_2.png)
*   [![Image 7: באנר אתר 2025 5](https://mashtela-urbanit.co.il/images/Home-slider/2023/%D7%91%D7%90%D7%A0%D7%A8_%D7%90%D7%AA%D7%A8_2025__-_5.jpeg)](https://mashtela-urbanit.co.il/catalog)
*   [![Image 8: 2 2](https://mashtela-urbanit.co.il/images/Home-slider/2023/2_2.png)](https://mashtela-urbanit.co.il/catalog/stav-sale "מבצעי העונה")
*   ![Image 9: 3 2](https://mashtela-urbanit.co.il/images/Home-slider/2023/3_2.png)
*   [![Image 10: באנר אתר 2025 5](https://mashtela-urbanit.co.il/images/Home-slider/2023/%D7%91%D7%90%D7%A0%D7%A8_%D7%90%D7%AA%D7%A8_2025__-_5.jpeg)](https://mashtela-urbanit.co.il/catalog)

*   [SEASON SALE](https://mashtela-urbanit.co.il/catalog/stav-sale)
*   [מתנות ומארזים](https://mashtela-urbanit.co.il/catalog/matanot)
*   [**Gift Card**](https://mashtela-urbanit.co.il/catalog/matanot/gift-card-detail)
*   [NEW IN](https://mashtela-urbanit.co.il/catalog/new)

[![Image 11: אתר פס](https://mashtela-urbanit.co.il/images/Home-slider/2023/%D7%90%D7%AA%D7%A8_%D7%A4%D7%A1.png)](https://mashtela-urbanit.co.il/index.php/catalog/%D7%98%D7%95-%D7%91%D7%A9%D7%91%D7%98)

1.    החנות 
2.    הצמחים 
3.    המשתלה 
4.    המוצרים 
5.    המועדון 

![Image 12: shop](https://mashtela-urbanit.co.il/images/jsn_is_thumbs/images/home-tabs/shop.png)

**בלב העיר תל אביב, בשוליו של שוק הכרמל, נמצאת חנות הדגל של ה"משתלה האורבנית". החנות הוקמה בשנת 2011 ע"י אלירן בן יהודה, אשר הגיע מהמושב שבהרי ירושלים וחיפש להביא איתו קצת מן הטבע אשר גדל בו, אל תוך העיר הגדולה.**

המטרה הראשונה הייתה לרכז לתוך החנות הקטנה את מגוון הצמחים והמוצרים אשר כל אחד צריך על מנת להקים לעצמו את הפינה הירוקה שלו, כאן, בתוך העיר הגדולה. היום, החנות היא בעצם הלב שלנו, אשר מרכז אליו מגוון לקוחות מכל ערי המרכז, ומציעה להם את המילה האחרונה בתחום הגינון האורבני ובמחירים שפויים המתאימים לכל כיס, תוך דגש על שירות אישי ומקצועי לכל אחד ואחת מלקוחותינו. אנו מזמינים אתכם לגעת, להריח, לראות, וכמובן לפגוש אותנו, פנים אל מול פנים וכמו כן לרכוש את כל מה שהפינה הירוקה שלכם צריכה. והכל במרחק נגיעה.

[קרא עוד](https://mashtela-urbanit.co.il/component/content/?id=1&Itemid=107)

![Image 13: plants](https://mashtela-urbanit.co.il/images/home-tabs/plants.png)

**יצאנו במסע לחיפוש אחר הגידול המושלם, לאחר שלמדנו כי צמחים הם כמו ילדים, צריך להשקיע בהם מהיום שנולדו את כל מה שניתן, על מנת לבנות ולהכין אותם לאתגרים שמציב העולם הגדול.**

אנו מכירים כבר היטב את האתגרים אשר חווים לקוחותינו בגידול שלהם, החל מהצפיפות העירונית, החום הלוהט של חודשי הקיץ ועד הזמן המועט שבאפשרותם להקדיש לצמחים. נזכרתי שבתחילת דרכנו, אמר לי חבר ותיק (יעקב מנשה שמו, אגרונום ומגדל צמחים מהטובים בתחומו), שצמחים אפשר לחנך, לטפח ולהתאים אותם לתנאים אשר קיימים במדינתנו הקטנה ובפרט באזור מישור החוף. בשלב ראשון היו לנו ספקות, אבל בחממה של יעקב יש אלפי הוכחות לכך. אז לקחנו את האידיאולוגיה שלו וכמובן את הצמחים שלו ושמנו בחנות. התוצאות היו מדהימות.

[קרא עוד](https://mashtela-urbanit.co.il/component/content/?id=1&Itemid=107)

![Image 14: mashtela3](https://mashtela-urbanit.co.il/images/home-tabs/mashtela3.png)

**אז למה בעצם משתלה אתם שואלים? אנחנו בעיר, לא?**

מבחינתנו, משתלה זה מקום בו יש שתילים, מקום בו שותלים, וכמובן מקום מלא בצמחיה ירוקה ופרחונית. נוסף על כך, זהו מקום שאליו נגיע על מנת לרכוש את צרכי הגינון השונים. אנו מגדירים את עצמנו, "משתלה אורבנית", דהיינו, משתלה עירונית. מדוע משתלה עירונית? במהלך השנים, צברנו ניסיון עשיר וביססנו את שמנו בקרב המגדלים הטובים בארץ, כמו גם בקרב הספקים המובילים בתחום הירוק. אנו מרכזים לתוך המשתלה את מיטב הספקים המובילים בארץ אשר רואים ב"משתלה אורבנית" מרכז שיווק ומכירה מוביל וחשוב עבור מוצריהם אשר נמצא במרכז העיר הגדולה ומזין אלפים.

[קרא עוד](https://mashtela-urbanit.co.il/component/content/?id=1&Itemid=107)

![Image 15: Mashtela2](https://mashtela-urbanit.co.il/images/home-tabs/Mashtela2.png)ב״משתלה אורבנית" שמנו לעצמנו מטרה לקחת את התחום הירוק כמה צעדים קדימה. הקמנו משתלה יפה בלב שוק הכרמל, הבאנו שתילים ממיטב המגדלים בארצנו הקטנה, אך הבנו עם השנים שלא מספיק רק צמחים טובים.

כמו שכל אדם צריך בית חם, אוכל טוב, טיפול וטיפוח, גם לצמחים זה לא פחות חשוב. זה מתחיל באדמת השתילה שמהווה בסיס לכל צמח, לכלי השתילה כמו אדניות ועציצים, לדשנים, חומרי הדברה ואביזרי הגינון השונים. במשך השנים זרמו לחנות, אלפי המוצרים השונים המוצעים בשוק המשתלות, בחנו אותם בעצמנו ושמענו את דעותיהם של לקוחותינו.[קרא עוד](https://mashtela-urbanit.co.il/component/content/?id=1&Itemid=107)

![Image 16: club](https://mashtela-urbanit.co.il/images/home-tabs/club.png)

**"עיר שאינה נחה לעולם, עיר של ים, בניינים גבוהים, אנשים צבעוניים, עיר שיש בה הכל, רק חסר קצת ירוק מסביב. ב״משתלה אורבנית" לקחנו את התחום הירוק כמה צעדים קדימה. הקמנו משתלה יפה במיוחד עם מגוון שתילים, אדניות, כלי פלסטיק וחרס וכל מה שתוכלו למצוא במשתלה מחוץ לעיר, רק ממש כאן, בשוק הכרמל.**

את מגוון הצמחים הגדול אנו מביאים ממיטב המגדלים בארץ ואת חלקם אנו מגדלים בחממתנו אשר נמצאת בדרום הארץ. הקמנו מערך מתנות ירוקות עבור עובדים וחברות. והכי חשוב, התאמנו עבורכם צמחים אשר מתאימים לסביבת האקלים שלנו, לחשיבות החיסכון במים, ולהפקת המרב מהמעט זמן שיש לנו. כל זה בשילוב של קרבה, מחירים זולים, שירות וכמובן הדרכה מקצועית בכל תחום הגינה האורבנית.

[קרא עוד](https://mashtela-urbanit.co.il/vip-club)

מומלצי החודש

*   [![Image 17: 1595](https://mashtela-urbanit.co.il/images/stories/virtuemart/product/resized/1595_0x270.png)](https://mashtela-urbanit.co.il/catalog/soil/%D7%AA%D7%A2%D7%A8%D7%95%D7%91%D7%AA-%D7%A9%D7%AA%D7%99%D7%9C%D7%94-detail "תערובת שתילה") [תערובת שתילה](https://mashtela-urbanit.co.il/catalog/soil/%D7%AA%D7%A2%D7%A8%D7%95%D7%91%D7%AA-%D7%A9%D7%AA%D7%99%D7%9C%D7%94-detail)22 ₪  
*   [![Image 18: גיפט קארד](https://mashtela-urbanit.co.il/images/stories/virtuemart/product/resized/%D7%92%D7%99%D7%A4%D7%98%20%D7%A7%D7%90%D7%A8%D7%93_0x270.png)](https://mashtela-urbanit.co.il/catalog/matanot/gift-card-detail "GIFT CARD + מתנה 50 שח") [GIFT CARD + מתנה 50 שח](https://mashtela-urbanit.co.il/catalog/matanot/gift-card-detail) 
*   [![Image 19: בטון](https://mashtela-urbanit.co.il/images/stories/virtuemart/product/resized/%D7%91%D7%98%D7%95%D7%9F_0x270.png)](https://mashtela-urbanit.co.il/catalog/matanot/%D7%A7%D7%A2%D7%A8%D7%AA-%D7%91%D7%98%D7%95%D7%9F-%D7%A2%D7%9D-%D7%9E%D7%99%D7%A7%D7%A1-%D7%A6%D7%9E%D7%97%D7%99-%D7%91%D7%99%D7%AA-detail "קערת בטון עם מיקס צמחי בית") [קערת בטון עם מיקס צמחי בית](https://mashtela-urbanit.co.il/catalog/matanot/%D7%A7%D7%A2%D7%A8%D7%AA-%D7%91%D7%98%D7%95%D7%9F-%D7%A2%D7%9D-%D7%9E%D7%99%D7%A7%D7%A1-%D7%A6%D7%9E%D7%97%D7%99-%D7%91%D7%99%D7%AA-detail)185 ₪  
*   [![Image 20: IMG_0644](https://mashtela-urbanit.co.il/images/stories/virtuemart/product/resized/IMG_0644_0x270.jpg)](https://mashtela-urbanit.co.il/catalog/matanot/%D7%9E%D7%90%D7%A8%D7%96-%D7%96%D7%A8%D7%A2%D7%99-%D7%AA%D7%91%D7%9C%D7%99%D7%9F-%D7%9C%D7%A9%D7%AA%D7%99%D7%9C%D7%94-1040-1276-detail "מארז זרעי פרחים לשתילה - 59 שח") [מארז זרעי פרחים לשתילה - 59 שח](https://mashtela-urbanit.co.il/catalog/matanot/%D7%9E%D7%90%D7%A8%D7%96-%D7%96%D7%A8%D7%A2%D7%99-%D7%AA%D7%91%D7%9C%D7%99%D7%9F-%D7%9C%D7%A9%D7%AA%D7%99%D7%9C%D7%94-1040-1276-detail)59 ₪  

[](https://mashtela-urbanit.co.il/)[](https://mashtela-urbanit.co.il/)

### קטלוג מוצרים

[תבלינים וירקות](https://mashtela-urbanit.co.il/catalog/herb-veg "תבלינים וירקות")

[צמחי בית ומשרד](https://mashtela-urbanit.co.il/catalog/home-office "צמחי בית ומשרד")

[ארואידים](https://mashtela-urbanit.co.il/catalog/home-office/aroids "ארואידים") (19) 

[משהו על השולחן](https://mashtela-urbanit.co.il/catalog/home-office/table-plants "משהו על השולחן") (37) 

[דקלים](https://mashtela-urbanit.co.il/catalog/home-office/%D7%93%D7%A7%D7%9C%D7%99%D7%9D "דקלים") (5) 

[עלים מגוונים](https://mashtela-urbanit.co.il/catalog/home-office/colorfull_leaves "עלים מגוונים") (15) 

[פורחים לבית](https://mashtela-urbanit.co.il/catalog/home-office/flower_light "פורחים לבית") (5) 

[פפרומיה](https://mashtela-urbanit.co.il/catalog/home-office/peperomia "פפרומיה") (2) 

[צמחים למקום מואר](https://mashtela-urbanit.co.il/catalog/home-office/like-light "צמחים למקום מואר") (45) 

[נשפכים](https://mashtela-urbanit.co.il/catalog/home-office/hanging-plants "נשפכים") (12) 

[צמחים חזקים במיוחד](https://mashtela-urbanit.co.il/catalog/home-office/strong "צמחים חזקים במיוחד") (27) 

[צמחים בגדול](https://mashtela-urbanit.co.il/catalog/home-office/big-plants "צמחים בגדול") (17) 

[צמחי גינה ומרפסת](https://mashtela-urbanit.co.il/catalog/garden-balcony "צמחי גינה ומרפסת")

[פרחי חוץ](https://mashtela-urbanit.co.il/catalog/garden-balcony/this-season-1 "פרחי חוץ") (13) 

[צמחים ושיחים לצל](https://mashtela-urbanit.co.il/catalog/garden-balcony/shade-plants "צמחים ושיחים לצל") (7) 

[מטפסים](https://mashtela-urbanit.co.il/catalog/garden-balcony/%D7%9E%D7%98%D7%A4%D7%A1%D7%99%D7%9D "מטפסים") (2) 

[צמחים ושיחים לשמש](https://mashtela-urbanit.co.il/catalog/garden-balcony/like-sun-plants "צמחים ושיחים לשמש") (27) 

[עצי פרי](https://mashtela-urbanit.co.il/catalog/garden-balcony/fruit-trees "עצי פרי") (15) 

[כלי שתילה](https://mashtela-urbanit.co.il/catalog/klei-shtila "כלי שתילה")

[מוצרי פלסטיק](https://mashtela-urbanit.co.il/catalog/klei-shtila/plastic "מוצרי פלסטיק") (0) 

[כלי קרמיקה](https://mashtela-urbanit.co.il/catalog/klei-shtila/keramika "כלי קרמיקה") (11) 

[עציצים ואדניות בגדול](https://mashtela-urbanit.co.il/catalog/klei-shtila/big_keramika "עציצים ואדניות בגדול") (8) 

[קש וקוקוס](https://mashtela-urbanit.co.il/catalog/klei-shtila/hash-kokus "קש וקוקוס") (0) 

[אביזרי גינון](https://mashtela-urbanit.co.il/catalog/tools "אביזרי גינון")

[כלי עבודה](https://mashtela-urbanit.co.il/catalog/tools/gargen-tools "כלי עבודה") (7) 

[מוצרי השקייה](https://mashtela-urbanit.co.il/catalog/tools/hashkaya "מוצרי השקייה") (12) 

[סחלבים](https://mashtela-urbanit.co.il/catalog/orchids "סחלבים")

[קקטוסים וסוקולנטים](https://mashtela-urbanit.co.il/catalog/cactus-succulents "קקטוסים וסוקולנטים")

[דשנים והדברה](https://mashtela-urbanit.co.il/catalog/dshanim-vehadbara "דשנים והדברה")

[חומרי דישון](https://mashtela-urbanit.co.il/catalog/dshanim-vehadbara/dshanim "חומרי דישון") (11) 

[חומרי דישון אורגנים](https://mashtela-urbanit.co.il/catalog/dshanim-vehadbara/dshanim-organim "חומרי דישון אורגנים") (3) 

[חומרי הדברה](https://mashtela-urbanit.co.il/catalog/dshanim-vehadbara/hadbara "חומרי הדברה") (17) 

[אדמה ותערובות](https://mashtela-urbanit.co.il/catalog/soil "אדמה ותערובות")

[זרעים ופקעות](https://mashtela-urbanit.co.il/catalog/seeds-b "זרעים ופקעות")

[זרעי ירקות ופירות](https://mashtela-urbanit.co.il/catalog/seeds-b/veg-and-fruit-seeds "זרעי ירקות ופירות") (13) 

[זרעי ירק](https://mashtela-urbanit.co.il/catalog/seeds-b/herb-seed "זרעי ירק") (21) 

[זרעי פרחים](https://mashtela-urbanit.co.il/catalog/seeds-b/flowers-seeds "זרעי פרחים") (8) 

[פקעות](https://mashtela-urbanit.co.il/catalog/seeds-b/pkaot "פקעות") (9) 

[מתנות ארוזות](https://mashtela-urbanit.co.il/catalog/matanot "מתנות ארוזות")

[בית](https://mashtela-urbanit.co.il/) |[אודות](https://mashtela-urbanit.co.il/component/content/?id=1&Itemid=107) |[שאלות נפוצות](https://mashtela-urbanit.co.il/faq) | מבצעים |[צור קשר](https://mashtela-urbanit.co.il/contect) |אתר זה פותח ע"י: [MLY](http://www.mly.co.il/)

[](https://mashtela-urbanit.co.il/)[](javascript:;)[](javascript:;)

[](https://mashtela-urbanit.co.il/#)