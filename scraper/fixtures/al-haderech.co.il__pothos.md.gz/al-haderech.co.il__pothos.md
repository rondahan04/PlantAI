[דילוג לתוכן](https://al-haderech.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#content)

הקדימו הזמנותיכם לראש השנה - מתנות מושלמות מחכות לכם באתר🌸 משלוחים מאשדוד עד נתניה🌸 

[![Image 1: משתלת על הדרך](https://al-haderech.co.il/wp-content/uploads/2020/03/73e7f50e58afe362bd4383dec364a3db.png)](https://al-haderech.co.il/)

*   [החשבון שלי](https://al-haderech.co.il/my-account/)

Search ... 

לכל התוצאות

[![Image 2](https://al-haderech.co.il/wp-content/uploads/2020/03/0e5d3d3bda4e75744ec29e3e7988a071.png)](tel:03-9550043)

[להזמנות **03-9550043**](tel:03-9550043)

[![Image 3](https://al-haderech.co.il/wp-content/uploads/2020/03/137b90bc9e1be1ca2fbb639c1668b9dc.png)](https://waze.com/ul?q=%D7%9E%D7%A9%D7%AA%D7%9C%D7%AA%20%D7%A2%D7%9C%20%D7%94%D7%93%D7%A8%D7%9A%20-%20%D7%A1%D7%A0%D7%99%D7%A3%20%D7%A4%D7%A8%D7%99%D7%99%D7%9E%D7%9F&z=10&navigate=yes)

[יעקב פריימן, **ראשון לציון**](https://waze.com/ul?q=%D7%9E%D7%A9%D7%AA%D7%9C%D7%AA%20%D7%A2%D7%9C%20%D7%94%D7%93%D7%A8%D7%9A%20-%20%D7%A1%D7%A0%D7%99%D7%A3%20%D7%A4%D7%A8%D7%99%D7%99%D7%9E%D7%9F&z=10&navigate=yes)

[₪0.00 0 עגלת קניות](https://al-haderech.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

*   [**מתנות**](https://al-haderech.co.il/product-category/gifts/)
    *   [**ראש השנה 2026**](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-2026/)
    *   [מתנות קטנות](https://al-haderech.co.il/product-category/gifts/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a7%d7%98%d7%a0%d7%95%d7%aa/)
    *   [בלונים, דובים ושוקולדים](https://al-haderech.co.il/product-category/gifts/%d7%91%d7%9c%d7%95%d7%a0%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [עציצים ארוזים](https://al-haderech.co.il/product-category/gifts/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%90%d7%a8%d7%95%d7%96%d7%99%d7%9d/)
    *   [מתנות לתינוק וליולדת](https://al-haderech.co.il/product-category/gifts/baby/)
    *   [ט”ו בשבט](https://al-haderech.co.il/product-category/gifts/%d7%98%d7%95-%d7%91%d7%a9%d7%91%d7%98/)

*   [פרחים טריים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)

    *   [![Image 4: ראש השנה 2026](https://al-haderech.co.il/wp-content/uploads/2021/02/love400.jpg) ## ראש השנה 2026 34 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-2026/)
    *   [![Image 5: זרי פרחים](https://al-haderech.co.il/wp-content/uploads/2020/07/alvin-matthews-AMd-OdlpPs0-unsplash.jpg) ## זרי פרחים 28 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [![Image 6: סידורי פרחים](https://al-haderech.co.il/wp-content/uploads/2020/07/bianca-ackermann-4suxZjeCpYk-unsplash.jpg) ## סידורי פרחים 6 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%99%d7%93%d7%95%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [![Image 7: סחלבים](https://al-haderech.co.il/wp-content/uploads/2020/07/orchid.jpg) ## סחלבים 2 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)
    *   [![Image 8: זרי כלה](https://al-haderech.co.il/wp-content/uploads/2020/08/bride.jpg) ## זרי כלה 10 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
    *   [![Image 9: זרים לראש](https://al-haderech.co.il/wp-content/uploads/2022/03/unnamed-400x400.jpg) ## זרים לראש 6 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%a8%d7%90%d7%a9/)
    *   [![Image 10: קישוטי רכב](https://al-haderech.co.il/wp-content/uploads/2020/07/CAR.jpg) ## קישוטי רכב 3 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a7%d7%99%d7%a9%d7%95%d7%98%d7%99-%d7%a8%d7%9b%d7%91/)
    *   [![Image 11: גלגלי אבל](https://al-haderech.co.il/wp-content/uploads/2025/05/%D7%92%D7%9C%D7%92%D7%9C-%D7%90%D7%91%D7%9C-1.jpg) ## גלגלי אבל 2 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%92%d7%9c%d7%92%d7%9c%d7%99-%d7%90%d7%91%d7%9c/)

*   [צמחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)

    *   [![Image 12: עצים, מטפסים ושיחים](https://al-haderech.co.il/wp-content/uploads/2021/02/trees.jpg) ## עצים, מטפסים ושיחים 36 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%9d-%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d-%d7%95%d7%a9%d7%99%d7%97%d7%99%d7%9d/)
    *   [![Image 13: צמחי תבלין וירקות](https://al-haderech.co.il/wp-content/uploads/2020/07/basil-932079_1920.jpg) ## צמחי תבלין וירקות 28 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%aa%d7%91%d7%9c%d7%99%d7%a0%d7%99%d7%9d/)
    *   [![Image 14: צמחי גן - שמש](https://al-haderech.co.il/wp-content/uploads/2020/07/verbena.jpg) ## צמחי גן - שמש 55 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-12-%d7%a1%d7%9e/)
    *   [![Image 15: צמחי גן - צל](https://al-haderech.co.il/wp-content/uploads/2020/07/begonia400.jpg) ## צמחי גן - צל 36 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-15-%d7%a1%d7%9e/)
    *   [![Image 16: שישיות פורחים](https://al-haderech.co.il/wp-content/uploads/2020/07/geranium.jpg) ## שישיות פורחים 16 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/130262-%d7%a9%d7%99%d7%a9%d7%99%d7%95%d7%aa-%d7%a4%d7%95%d7%a8%d7%97%d7%99%d7%9d/)
    *   [![Image 17: צמחי בית ומשרד](https://al-haderech.co.il/wp-content/uploads/2020/07/office.jpg) ## צמחי בית ומשרד 172 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa/)
    *   [![Image 18: צמחי תלייה לבית](https://al-haderech.co.il/wp-content/uploads/2020/08/hang.jpg) ## צמחי תלייה לבית 36 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9c%d7%91%d7%99%d7%aa/)
    *   [![Image 19: צמחי בית קטנים](https://al-haderech.co.il/wp-content/uploads/2020/07/8d49cfd73a1973a1c32f3abfaed079d6.jpg) ## צמחי בית קטנים 103 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa-%d7%a7%d7%98%d7%a0%d7%99%d7%9d/)
    *   [![Image 20: סחלבים](https://al-haderech.co.il/wp-content/uploads/2020/07/orchid.jpg) ## סחלבים 3 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [![Image 21: צמחים ומוצרים לטרריום](https://al-haderech.co.il/wp-content/uploads/2020/07/b065effa9f2f6cdeb055d19e5374da41.jpg) ## צמחים ומוצרים לטרריום 75 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%98%d7%a8%d7%a8%d7%99%d7%95%d7%9e%d7%99%d7%9d/)
    *   [![Image 22: קקטוסים וסוקולנטים](https://al-haderech.co.il/wp-content/uploads/2020/08/cactus.jpg) ## קקטוסים וסוקולנטים 101 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/105322-%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)

*   [המיוחדים שלנו](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)

    *   [![Image 23: טורפים](https://al-haderech.co.il/wp-content/uploads/2025/06/%D7%9B%D7%93%D7%A0%D7%99%D7%AA-%D7%92%D7%90%D7%99%D7%94-199.9-400x400.jpg) ## טורפים 13 מוצרים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%98%d7%95%d7%a8%d7%a4%d7%99%d7%9d/)
    *   [![Image 24: המיניאטורים](https://al-haderech.co.il/wp-content/uploads/2020/12/image_6483441-2.jpg) ## המיניאטורים 69 מוצרים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%9e%d7%99%d7%a7%d7%a8%d7%95/)
    *   [![Image 25: המיוחדים](https://al-haderech.co.il/wp-content/uploads/2020/12/special.jpg) ## המיוחדים 404 מוצרים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d/)
    *   [![Image 26: הויות מיוחדות](https://al-haderech.co.il/wp-content/uploads/2024/02/IMG_2319-400x400.jpg) ## הויות מיוחדות 117 מוצרים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%95%d7%99%d7%95%d7%aa-%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%95%d7%aa/)

*   [ירקות מהשדה](https://al-haderech.co.il/product-category/%d7%99%d7%a8%d7%a7%d7%95%d7%aa-%d7%98%d7%a8%d7%99%d7%99%d7%9d/)
*   [כלי שתילה ואדניות](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)

    *   [![Image 27: עציצי תלייה מפלסטיק](https://al-haderech.co.il/wp-content/uploads/2020/04/be17786170ffd9022909382eec6ef95b-400x400.jpg) ## עציצי תלייה מפלסטיק מוצר 1](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9e%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
    *   [![Image 28: עציצי פלסטיק](https://al-haderech.co.il/wp-content/uploads/2020/04/aea29b155c207f99a54d0c84e00ccd8f-400x400.jpg) ## עציצי פלסטיק 19 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [![Image 29: אדניות פלסטיק](https://al-haderech.co.il/wp-content/uploads/2020/04/077769dace9aa3260fdfbc0dcbd17ffc-400x400.jpg) ## אדניות פלסטיק 12 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
    *   [![Image 30: אדניות למעקה](https://al-haderech.co.il/wp-content/uploads/2020/04/f54d2c347458d3dd28cd5d6f2ce79c0c-400x400.jpg) ## אדניות למעקה 6 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%9c%d7%9e%d7%a2%d7%a7%d7%94/)

*   [אביזרי גינון](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/)

    *   [![Image 31: מוצרי השקייה](https://al-haderech.co.il/wp-content/uploads/2020/07/water-jet-3611518_1920.jpg) ## מוצרי השקייה 81 מוצרים](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)
    *   [![Image 32: כלי עבודה](https://al-haderech.co.il/wp-content/uploads/2020/07/planting-4226838_1920.jpg) ## כלי עבודה 37 מוצרים](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9b%d7%9c%d7%99-%d7%a2%d7%91%d7%95%d7%93%d7%94/)
    *   [![Image 33: אביזרים למערכות השקייה](https://al-haderech.co.il/wp-content/uploads/2022/11/gardening-tools.jpg) ## אביזרים למערכות השקייה 67 מוצרים](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%9e%d7%a2%d7%a8%d7%9b%d7%95%d7%aa-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)

*   [כדים ודקורציה לבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)

    *   [![Image 34: כדי פלסטיק מעוצבים](https://al-haderech.co.il/wp-content/uploads/2024/10/%D7%A1%D7%A4%D7%A8%D7%94-%D7%90%D7%A4%D7%95%D7%A8-400x400.jpg) ## כדי פלסטיק מעוצבים 9 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d/)
    *   [![Image 35: צמחייה מיובשת ומלאכותית](https://al-haderech.co.il/wp-content/uploads/2020/03/5caafdb9e1ecd3c8661ad3c6c390aa9f-400x315.jpg) ## צמחייה מיובשת ומלאכותית 7 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a6%d7%9e%d7%97%d7%99%d7%94-%d7%9e%d7%99%d7%95%d7%91%d7%a9%d7%aa-%d7%95%d7%9e%d7%9c%d7%90%d7%9b%d7%95%d7%aa%d7%99%d7%aa/)
    *   [![Image 36: כדי קרמיקה](https://al-haderech.co.il/wp-content/uploads/2020/09/ceramic-mug-4797733_640.jpg) ## כדי קרמיקה 33 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
    *   [![Image 37: כדי טרקוטה](https://al-haderech.co.il/wp-content/uploads/2020/09/bouquet-3874595_640.jpg) ## כדי טרקוטה 6 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%98%d7%a8%d7%a7%d7%95%d7%98%d7%94/)
    *   [![Image 38: כדי מתכת](https://al-haderech.co.il/wp-content/uploads/2020/09/cactus-1842260_640.jpg) ## כדי מתכת מוצר 1](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a4%d7%99%d7%91%d7%a8/)
    *   [![Image 39: עיצוב הבית](https://al-haderech.co.il/wp-content/uploads/2020/09/summer-2448878_640.jpg) ## עיצוב הבית 47 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [![Image 40: כדים על רגליים](https://al-haderech.co.il/wp-content/uploads/2020/09/laged.jpg) ## כדים על רגליים 4 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99%d7%9d-%d7%a2%d7%9c-%d7%a8%d7%92%d7%9c%d7%99%d7%99%d7%9d/)
    *   [![Image 41: סלים](https://al-haderech.co.il/wp-content/uploads/2020/09/tulips-708410_640.jpg) ## סלים 9 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a1%d7%9c%d7%99%d7%9d/)
    *   [![Image 42: כדי בטון](https://al-haderech.co.il/wp-content/uploads/2020/09/concrit.jpg) ## כדי בטון 10 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%91%d7%98%d7%95%d7%9f/)
    *   [![Image 43: כלי זכוכית](https://al-haderech.co.il/wp-content/uploads/2020/09/tulip-1230390_640.jpg) ## כלי זכוכית 18 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%9c%d7%99-%d7%96%d7%9b%d7%95%d7%9b%d7%99%d7%aa/)

*   [דשנים הדברה ותערובות](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/)

    *   [![Image 44: תערובות וחיפויים](https://al-haderech.co.il/wp-content/uploads/2020/07/gardening-690940_1920.jpg) ## תערובות וחיפויים 34 מוצרים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa-%d7%95%d7%97%d7%99%d7%a4%d7%95%d7%99%d7%99%d7%9d/)
    *   [![Image 45: חומרי הדברה](https://al-haderech.co.il/wp-content/uploads/2020/07/snail.jpg) ## חומרי הדברה 39 מוצרים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%97%d7%95%d7%9e%d7%a8%d7%99-%d7%94%d7%93%d7%91%d7%a8%d7%94/)
    *   [![Image 46: דשנים](https://al-haderech.co.il/wp-content/uploads/2020/07/4ca35181bb83b46f46486b751d128d7b.jpg) ## דשנים 51 מוצרים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%93%d7%a9%d7%a0%d7%99%d7%9d/)

*   [···](https://al-haderech.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

[![Image 47: משתלת על הדרך](https://al-haderech.co.il/wp-content/uploads/2020/03/73e7f50e58afe362bd4383dec364a3db.png)](https://al-haderech.co.il/)

[![Image 48](https://al-haderech.co.il/wp-content/uploads/2020/03/0e5d3d3bda4e75744ec29e3e7988a071.png)](tel:03-9550043)

[להזמנות **03-9550043**](tel:03-9550043)

*   [**מתנות**](https://al-haderech.co.il/product-category/gifts/)
    *   [**ראש השנה 2026**](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-2026/)
    *   [מתנות קטנות](https://al-haderech.co.il/product-category/gifts/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a7%d7%98%d7%a0%d7%95%d7%aa/)
    *   [בלונים, דובים ושוקולדים](https://al-haderech.co.il/product-category/gifts/%d7%91%d7%9c%d7%95%d7%a0%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [עציצים ארוזים](https://al-haderech.co.il/product-category/gifts/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%90%d7%a8%d7%95%d7%96%d7%99%d7%9d/)
    *   [מתנות לתינוק וליולדת](https://al-haderech.co.il/product-category/gifts/baby/)
    *   [ט”ו בשבט](https://al-haderech.co.il/product-category/gifts/%d7%98%d7%95-%d7%91%d7%a9%d7%91%d7%98/)

*   [פרחים טריים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [סידורי פרחים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%99%d7%93%d7%95%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [סחלבים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)
    *   [זרי פרחים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [זרי כלה](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
    *   [קישוטי רכב](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a7%d7%99%d7%a9%d7%95%d7%98%d7%99-%d7%a8%d7%9b%d7%91/)
    *   [זרים לראש](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%a8%d7%90%d7%a9/)
    *   [גלגלי אבל](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%92%d7%9c%d7%92%d7%9c%d7%99-%d7%90%d7%91%d7%9c/)

*   [צמחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [צמחי תבלין וירקות](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%aa%d7%91%d7%9c%d7%99%d7%a0%d7%99%d7%9d/)
    *   [צמחי גן – שמש](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-12-%d7%a1%d7%9e/)
    *   [צמחי גן – צל](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-15-%d7%a1%d7%9e/)
    *   [שישיות פורחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/130262-%d7%a9%d7%99%d7%a9%d7%99%d7%95%d7%aa-%d7%a4%d7%95%d7%a8%d7%97%d7%99%d7%9d/)
    *   [פקעות וצמחי חורף](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a4%d7%a7%d7%a2%d7%95%d7%aa-%d7%95%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a8%d7%a3/)
    *   [צמחי בית ומשרד](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa/)
    *   [צמחי תלייה לבית](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9c%d7%91%d7%99%d7%aa/)
    *   [צמחי בית קטנים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa-%d7%a7%d7%98%d7%a0%d7%99%d7%9d/)
    *   [סחלבים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [קקטוסים וסוקולנטים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/105322-%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)
    *   [עצים, מטפסים ושיחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%9d-%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d-%d7%95%d7%a9%d7%99%d7%97%d7%99%d7%9d/)
    *   [צמחים ומוצרים לטרריום](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%98%d7%a8%d7%a8%d7%99%d7%95%d7%9e%d7%99%d7%9d/)

*   [המיוחדים שלנו](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
    *   [המיוחדים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d/)
    *   [המיניאטורים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%9e%d7%99%d7%a7%d7%a8%d7%95/)
    *   [הויות מיוחדות](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%95%d7%99%d7%95%d7%aa-%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%95%d7%aa/)
    *   [טורפים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%98%d7%95%d7%a8%d7%a4%d7%99%d7%9d/)

*   [ירקות מהשדה](https://al-haderech.co.il/product-category/%d7%99%d7%a8%d7%a7%d7%95%d7%aa-%d7%98%d7%a8%d7%99%d7%99%d7%9d/)
*   [כלי שתילה ואדניות](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [אדניות למעקה](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%9c%d7%9e%d7%a2%d7%a7%d7%94/)
    *   [אדניות עץ](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a2%d7%a5/)
    *   [אדניות פלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
    *   [עציצי פלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [עציצי תלייה מפלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9e%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)

*   [אביזרי גינון](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
    *   [כלי עבודה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9b%d7%9c%d7%99-%d7%a2%d7%91%d7%95%d7%93%d7%94/)
    *   [מוצרי השקייה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)
    *   [אביזרים למערכות השקייה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%9e%d7%a2%d7%a8%d7%9b%d7%95%d7%aa-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)

*   [כדים ודקורציה לבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [כדי קרמיקה](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
    *   [כדי טרקוטה](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%98%d7%a8%d7%a7%d7%95%d7%98%d7%94/)
    *   [כדי מתכת](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a4%d7%99%d7%91%d7%a8/)
    *   [עיצוב הבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [כדים על רגליים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99%d7%9d-%d7%a2%d7%9c-%d7%a8%d7%92%d7%9c%d7%99%d7%99%d7%9d/)
    *   [כדי בטון](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%91%d7%98%d7%95%d7%9f/)
    *   [סלים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a1%d7%9c%d7%99%d7%9d/)
    *   [כלי זכוכית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%9c%d7%99-%d7%96%d7%9b%d7%95%d7%9b%d7%99%d7%aa/)
    *   [צמחייה מלאכותית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a6%d7%9e%d7%97%d7%99%d7%94-%d7%9e%d7%99%d7%95%d7%91%d7%a9%d7%aa-%d7%95%d7%9e%d7%9c%d7%90%d7%9b%d7%95%d7%aa%d7%99%d7%aa/)

*   [דשנים הדברה ותערובות](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/)
    *   [תערובות וחיפויים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa-%d7%95%d7%97%d7%99%d7%a4%d7%95%d7%99%d7%99%d7%9d/)
    *   [חומרי הדברה](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%97%d7%95%d7%9e%d7%a8%d7%99-%d7%94%d7%93%d7%91%d7%a8%d7%94/)
    *   [דשנים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%93%d7%a9%d7%a0%d7%99%d7%9d/)

*   [**מתנות**](https://al-haderech.co.il/product-category/gifts/)
    *   [**ראש השנה 2026**](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-2026/)
    *   [מתנות קטנות](https://al-haderech.co.il/product-category/gifts/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a7%d7%98%d7%a0%d7%95%d7%aa/)
    *   [בלונים, דובים ושוקולדים](https://al-haderech.co.il/product-category/gifts/%d7%91%d7%9c%d7%95%d7%a0%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [עציצים ארוזים](https://al-haderech.co.il/product-category/gifts/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%90%d7%a8%d7%95%d7%96%d7%99%d7%9d/)
    *   [מתנות לתינוק וליולדת](https://al-haderech.co.il/product-category/gifts/baby/)
    *   [ט”ו בשבט](https://al-haderech.co.il/product-category/gifts/%d7%98%d7%95-%d7%91%d7%a9%d7%91%d7%98/)

*   [פרחים טריים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [סידורי פרחים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%99%d7%93%d7%95%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [סחלבים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)
    *   [זרי פרחים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [זרי כלה](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
    *   [קישוטי רכב](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a7%d7%99%d7%a9%d7%95%d7%98%d7%99-%d7%a8%d7%9b%d7%91/)
    *   [זרים לראש](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%a8%d7%90%d7%a9/)
    *   [גלגלי אבל](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%92%d7%9c%d7%92%d7%9c%d7%99-%d7%90%d7%91%d7%9c/)

*   [צמחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [צמחי תבלין וירקות](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%aa%d7%91%d7%9c%d7%99%d7%a0%d7%99%d7%9d/)
    *   [צמחי גן – שמש](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-12-%d7%a1%d7%9e/)
    *   [צמחי גן – צל](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-15-%d7%a1%d7%9e/)
    *   [שישיות פורחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/130262-%d7%a9%d7%99%d7%a9%d7%99%d7%95%d7%aa-%d7%a4%d7%95%d7%a8%d7%97%d7%99%d7%9d/)
    *   [פקעות וצמחי חורף](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a4%d7%a7%d7%a2%d7%95%d7%aa-%d7%95%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a8%d7%a3/)
    *   [צמחי בית ומשרד](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa/)
    *   [צמחי תלייה לבית](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9c%d7%91%d7%99%d7%aa/)
    *   [צמחי בית קטנים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa-%d7%a7%d7%98%d7%a0%d7%99%d7%9d/)
    *   [סחלבים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [קקטוסים וסוקולנטים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/105322-%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)
    *   [עצים, מטפסים ושיחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%9d-%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d-%d7%95%d7%a9%d7%99%d7%97%d7%99%d7%9d/)
    *   [צמחים ומוצרים לטרריום](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%98%d7%a8%d7%a8%d7%99%d7%95%d7%9e%d7%99%d7%9d/)

*   [המיוחדים שלנו](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
    *   [המיוחדים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d/)
    *   [המיניאטורים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%9e%d7%99%d7%a7%d7%a8%d7%95/)
    *   [הויות מיוחדות](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%95%d7%99%d7%95%d7%aa-%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%95%d7%aa/)
    *   [טורפים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%98%d7%95%d7%a8%d7%a4%d7%99%d7%9d/)

*   [ירקות מהשדה](https://al-haderech.co.il/product-category/%d7%99%d7%a8%d7%a7%d7%95%d7%aa-%d7%98%d7%a8%d7%99%d7%99%d7%9d/)
*   [כלי שתילה ואדניות](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [אדניות למעקה](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%9c%d7%9e%d7%a2%d7%a7%d7%94/)
    *   [אדניות עץ](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a2%d7%a5/)
    *   [אדניות פלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
    *   [עציצי פלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [עציצי תלייה מפלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9e%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)

*   [אביזרי גינון](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
    *   [כלי עבודה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9b%d7%9c%d7%99-%d7%a2%d7%91%d7%95%d7%93%d7%94/)
    *   [מוצרי השקייה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)
    *   [אביזרים למערכות השקייה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%9e%d7%a2%d7%a8%d7%9b%d7%95%d7%aa-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)

*   [כדים ודקורציה לבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [כדי קרמיקה](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
    *   [כדי טרקוטה](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%98%d7%a8%d7%a7%d7%95%d7%98%d7%94/)
    *   [כדי מתכת](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a4%d7%99%d7%91%d7%a8/)
    *   [עיצוב הבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [כדים על רגליים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99%d7%9d-%d7%a2%d7%9c-%d7%a8%d7%92%d7%9c%d7%99%d7%99%d7%9d/)
    *   [כדי בטון](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%91%d7%98%d7%95%d7%9f/)
    *   [סלים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a1%d7%9c%d7%99%d7%9d/)
    *   [כלי זכוכית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%9c%d7%99-%d7%96%d7%9b%d7%95%d7%9b%d7%99%d7%aa/)
    *   [צמחייה מלאכותית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a6%d7%9e%d7%97%d7%99%d7%94-%d7%9e%d7%99%d7%95%d7%91%d7%a9%d7%aa-%d7%95%d7%9e%d7%9c%d7%90%d7%9b%d7%95%d7%aa%d7%99%d7%aa/)

*   [דשנים הדברה ותערובות](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/)
    *   [תערובות וחיפויים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa-%d7%95%d7%97%d7%99%d7%a4%d7%95%d7%99%d7%99%d7%9d/)
    *   [חומרי הדברה](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%97%d7%95%d7%9e%d7%a8%d7%99-%d7%94%d7%93%d7%91%d7%a8%d7%94/)
    *   [דשנים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%93%d7%a9%d7%a0%d7%99%d7%9d/)

[₪0.00 0 עגלת קניות](https://al-haderech.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

*   [דף הבית](https://al-haderech.co.il/)
*   [אודות](https://al-haderech.co.il/about/)
*   [צרו קשר](https://al-haderech.co.il/contact/)
*   [החשבון שלי](https://al-haderech.co.il/my-account/)

*   [דף הבית](https://al-haderech.co.il/)
*   [אודות](https://al-haderech.co.il/about/)
*   [צרו קשר](https://al-haderech.co.il/contact/)
*   [החשבון שלי](https://al-haderech.co.il/my-account/)

[](https://waze.com/ul?q=%D7%9E%D7%A9%D7%AA%D7%9C%D7%AA%20%D7%A2%D7%9C%20%D7%94%D7%93%D7%A8%D7%9A%20-%20%D7%A1%D7%A0%D7%99%D7%A3%20%D7%A4%D7%A8%D7%99%D7%99%D7%9E%D7%9F&z=10&navigate=yes)

Search ... 

לכל התוצאות

[עמוד הבית](https://al-haderech.co.il/)/[חנות](https://al-haderech.co.il/shop/)/תוצאות חיפוש עבור “פותוס”

 לא נמצאו מוצרים התואמים את בחירתך. 

#### קניה משתלמת

![Image 49](https://al-haderech.co.il/wp-content/uploads/2020/03/5eb019800a05c96a911cadb8810cd863.png)

קניה בטוחה בתקן icp

![Image 50](https://al-haderech.co.il/wp-content/uploads/2020/03/1497d204a111b2e70e593b31119c341a.png)

משלוחים עד בית הלקוח בגוש דן והסביבה

![Image 51](https://al-haderech.co.il/wp-content/uploads/2020/03/c0dda6c0971ae4781b0fb680d52f8dca.png)

קניה ישירה מהמגדל איכות ללא פשרות

![Image 52](https://al-haderech.co.il/wp-content/uploads/2020/03/d149d6e43f53d7ce4d6ef231b59c8369.png)

עסק משפחתי

![Image 53](https://al-haderech.co.il/wp-content/uploads/2020/03/a36ad1ae1ea6249157e4c69cc8953d13.png)

שירות ויעוץ מקצועי

![Image 54](https://al-haderech.co.il/wp-content/uploads/2020/03/038b72d0194df321bfdd9df7d38efa62.png)

הטבות והנחות לחברי מועדון

[הצטרפו למועדון ותהנו מ10% הנחה באתר](https://al-haderech.co.il/items/%d7%97%d7%91%d7%a8%d7%95%d7%aa-%d7%91%d7%9e%d7%95%d7%a2%d7%93%d7%95%d7%9f-%d7%94%d7%9c%d7%a7%d7%95%d7%97%d7%95%d7%aa/)

#### מפת האתר

*   [אודות](https://al-haderech.co.il/about/)
*   [צרו קשר](https://al-haderech.co.il/contact/)
*   [תקנון החנות](https://al-haderech.co.il/contract/)
*   [מעקב הזמנות](https://al-haderech.co.il/my-account/orders/)
*   [משלוחים והחזרות](https://al-haderech.co.il/shipping/)
*   [הצהרת נגישות](https://al-haderech.co.il/wp-content/uploads/2023/07/%D7%94%D7%A6%D7%94%D7%A8%D7%AA-%D7%A0%D7%92%D7%99%D7%A9%D7%95%D7%AA-%D7%9E%D7%A9%D7%AA%D7%9C%D7%AA-%D7%A2%D7%9C-%D7%94%D7%93%D7%A8%D7%9A.pdf)

#### קטגוריות ראשיות

*   [**מתנות**](https://al-haderech.co.il/product-category/gifts/)
    *   [**ראש השנה 2026**](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-2026/)
    *   [מתנות קטנות](https://al-haderech.co.il/product-category/gifts/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a7%d7%98%d7%a0%d7%95%d7%aa/)
    *   [בלונים, דובים ושוקולדים](https://al-haderech.co.il/product-category/gifts/%d7%91%d7%9c%d7%95%d7%a0%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [עציצים ארוזים](https://al-haderech.co.il/product-category/gifts/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%90%d7%a8%d7%95%d7%96%d7%99%d7%9d/)
    *   [מתנות לתינוק וליולדת](https://al-haderech.co.il/product-category/gifts/baby/)
    *   [ט”ו בשבט](https://al-haderech.co.il/product-category/gifts/%d7%98%d7%95-%d7%91%d7%a9%d7%91%d7%98/)

*   [פרחים טריים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [סידורי פרחים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%99%d7%93%d7%95%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [סחלבים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)
    *   [זרי פרחים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [זרי כלה](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
    *   [קישוטי רכב](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a7%d7%99%d7%a9%d7%95%d7%98%d7%99-%d7%a8%d7%9b%d7%91/)
    *   [זרים לראש](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%a8%d7%90%d7%a9/)
    *   [גלגלי אבל](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%92%d7%9c%d7%92%d7%9c%d7%99-%d7%90%d7%91%d7%9c/)

*   [צמחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [צמחי תבלין וירקות](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%aa%d7%91%d7%9c%d7%99%d7%a0%d7%99%d7%9d/)
    *   [צמחי גן – שמש](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-12-%d7%a1%d7%9e/)
    *   [צמחי גן – צל](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-15-%d7%a1%d7%9e/)
    *   [שישיות פורחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/130262-%d7%a9%d7%99%d7%a9%d7%99%d7%95%d7%aa-%d7%a4%d7%95%d7%a8%d7%97%d7%99%d7%9d/)
    *   [פקעות וצמחי חורף](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a4%d7%a7%d7%a2%d7%95%d7%aa-%d7%95%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a8%d7%a3/)
    *   [צמחי בית ומשרד](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa/)
    *   [צמחי תלייה לבית](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9c%d7%91%d7%99%d7%aa/)
    *   [צמחי בית קטנים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa-%d7%a7%d7%98%d7%a0%d7%99%d7%9d/)
    *   [סחלבים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [קקטוסים וסוקולנטים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/105322-%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)
    *   [עצים, מטפסים ושיחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%9d-%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d-%d7%95%d7%a9%d7%99%d7%97%d7%99%d7%9d/)
    *   [צמחים ומוצרים לטרריום](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%98%d7%a8%d7%a8%d7%99%d7%95%d7%9e%d7%99%d7%9d/)

*   [המיוחדים שלנו](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
    *   [המיוחדים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d/)
    *   [המיניאטורים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%9e%d7%99%d7%a7%d7%a8%d7%95/)
    *   [הויות מיוחדות](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%95%d7%99%d7%95%d7%aa-%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%95%d7%aa/)
    *   [טורפים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%98%d7%95%d7%a8%d7%a4%d7%99%d7%9d/)

*   [ירקות מהשדה](https://al-haderech.co.il/product-category/%d7%99%d7%a8%d7%a7%d7%95%d7%aa-%d7%98%d7%a8%d7%99%d7%99%d7%9d/)
*   [כלי שתילה ואדניות](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [אדניות למעקה](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%9c%d7%9e%d7%a2%d7%a7%d7%94/)
    *   [אדניות עץ](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a2%d7%a5/)
    *   [אדניות פלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
    *   [עציצי פלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [עציצי תלייה מפלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9e%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)

*   [אביזרי גינון](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
    *   [כלי עבודה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9b%d7%9c%d7%99-%d7%a2%d7%91%d7%95%d7%93%d7%94/)
    *   [מוצרי השקייה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)
    *   [אביזרים למערכות השקייה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%9e%d7%a2%d7%a8%d7%9b%d7%95%d7%aa-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)

*   [כדים ודקורציה לבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [כדי קרמיקה](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
    *   [כדי טרקוטה](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%98%d7%a8%d7%a7%d7%95%d7%98%d7%94/)
    *   [כדי מתכת](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a4%d7%99%d7%91%d7%a8/)
    *   [עיצוב הבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [כדים על רגליים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99%d7%9d-%d7%a2%d7%9c-%d7%a8%d7%92%d7%9c%d7%99%d7%99%d7%9d/)
    *   [כדי בטון](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%91%d7%98%d7%95%d7%9f/)
    *   [סלים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a1%d7%9c%d7%99%d7%9d/)
    *   [כלי זכוכית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%9c%d7%99-%d7%96%d7%9b%d7%95%d7%9b%d7%99%d7%aa/)
    *   [צמחייה מלאכותית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a6%d7%9e%d7%97%d7%99%d7%94-%d7%9e%d7%99%d7%95%d7%91%d7%a9%d7%aa-%d7%95%d7%9e%d7%9c%d7%90%d7%9b%d7%95%d7%aa%d7%99%d7%aa/)

*   [דשנים הדברה ותערובות](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/)
    *   [תערובות וחיפויים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa-%d7%95%d7%97%d7%99%d7%a4%d7%95%d7%99%d7%99%d7%9d/)
    *   [חומרי הדברה](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%97%d7%95%d7%9e%d7%a8%d7%99-%d7%94%d7%93%d7%91%d7%a8%d7%94/)
    *   [דשנים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%93%d7%a9%d7%a0%d7%99%d7%9d/)

*   [**מתנות**](https://al-haderech.co.il/product-category/gifts/)
    *   [**ראש השנה 2026**](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-2026/)
    *   [מתנות קטנות](https://al-haderech.co.il/product-category/gifts/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a7%d7%98%d7%a0%d7%95%d7%aa/)
    *   [בלונים, דובים ושוקולדים](https://al-haderech.co.il/product-category/gifts/%d7%91%d7%9c%d7%95%d7%a0%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [עציצים ארוזים](https://al-haderech.co.il/product-category/gifts/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%90%d7%a8%d7%95%d7%96%d7%99%d7%9d/)
    *   [מתנות לתינוק וליולדת](https://al-haderech.co.il/product-category/gifts/baby/)
    *   [ט”ו בשבט](https://al-haderech.co.il/product-category/gifts/%d7%98%d7%95-%d7%91%d7%a9%d7%91%d7%98/)

*   [פרחים טריים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [סידורי פרחים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%99%d7%93%d7%95%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [סחלבים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)
    *   [זרי פרחים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [זרי כלה](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
    *   [קישוטי רכב](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a7%d7%99%d7%a9%d7%95%d7%98%d7%99-%d7%a8%d7%9b%d7%91/)
    *   [זרים לראש](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%a8%d7%90%d7%a9/)
    *   [גלגלי אבל](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%92%d7%9c%d7%92%d7%9c%d7%99-%d7%90%d7%91%d7%9c/)

*   [צמחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [צמחי תבלין וירקות](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%aa%d7%91%d7%9c%d7%99%d7%a0%d7%99%d7%9d/)
    *   [צמחי גן – שמש](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-12-%d7%a1%d7%9e/)
    *   [צמחי גן – צל](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-15-%d7%a1%d7%9e/)
    *   [שישיות פורחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/130262-%d7%a9%d7%99%d7%a9%d7%99%d7%95%d7%aa-%d7%a4%d7%95%d7%a8%d7%97%d7%99%d7%9d/)
    *   [פקעות וצמחי חורף](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a4%d7%a7%d7%a2%d7%95%d7%aa-%d7%95%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a8%d7%a3/)
    *   [צמחי בית ומשרד](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa/)
    *   [צמחי תלייה לבית](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9c%d7%91%d7%99%d7%aa/)
    *   [צמחי בית קטנים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa-%d7%a7%d7%98%d7%a0%d7%99%d7%9d/)
    *   [סחלבים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
    *   [קקטוסים וסוקולנטים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/105322-%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)
    *   [עצים, מטפסים ושיחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%9d-%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d-%d7%95%d7%a9%d7%99%d7%97%d7%99%d7%9d/)
    *   [צמחים ומוצרים לטרריום](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%98%d7%a8%d7%a8%d7%99%d7%95%d7%9e%d7%99%d7%9d/)

*   [המיוחדים שלנו](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
    *   [המיוחדים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d/)
    *   [המיניאטורים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%9e%d7%99%d7%a7%d7%a8%d7%95/)
    *   [הויות מיוחדות](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%95%d7%99%d7%95%d7%aa-%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%95%d7%aa/)
    *   [טורפים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%98%d7%95%d7%a8%d7%a4%d7%99%d7%9d/)

*   [ירקות מהשדה](https://al-haderech.co.il/product-category/%d7%99%d7%a8%d7%a7%d7%95%d7%aa-%d7%98%d7%a8%d7%99%d7%99%d7%9d/)
*   [כלי שתילה ואדניות](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [אדניות למעקה](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%9c%d7%9e%d7%a2%d7%a7%d7%94/)
    *   [אדניות עץ](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a2%d7%a5/)
    *   [אדניות פלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
    *   [עציצי פלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [עציצי תלייה מפלסטיק](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9e%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)

*   [אביזרי גינון](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
    *   [כלי עבודה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9b%d7%9c%d7%99-%d7%a2%d7%91%d7%95%d7%93%d7%94/)
    *   [מוצרי השקייה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)
    *   [אביזרים למערכות השקייה](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%9e%d7%a2%d7%a8%d7%9b%d7%95%d7%aa-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)

*   [כדים ודקורציה לבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [כדי קרמיקה](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
    *   [כדי טרקוטה](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%98%d7%a8%d7%a7%d7%95%d7%98%d7%94/)
    *   [כדי מתכת](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a4%d7%99%d7%91%d7%a8/)
    *   [עיצוב הבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
    *   [כדים על רגליים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99%d7%9d-%d7%a2%d7%9c-%d7%a8%d7%92%d7%9c%d7%99%d7%99%d7%9d/)
    *   [כדי בטון](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%91%d7%98%d7%95%d7%9f/)
    *   [סלים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a1%d7%9c%d7%99%d7%9d/)
    *   [כלי זכוכית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%9c%d7%99-%d7%96%d7%9b%d7%95%d7%9b%d7%99%d7%aa/)
    *   [צמחייה מלאכותית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a6%d7%9e%d7%97%d7%99%d7%94-%d7%9e%d7%99%d7%95%d7%91%d7%a9%d7%aa-%d7%95%d7%9e%d7%9c%d7%90%d7%9b%d7%95%d7%aa%d7%99%d7%aa/)

*   [דשנים הדברה ותערובות](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/)
    *   [תערובות וחיפויים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa-%d7%95%d7%97%d7%99%d7%a4%d7%95%d7%99%d7%99%d7%9d/)
    *   [חומרי הדברה](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%97%d7%95%d7%9e%d7%a8%d7%99-%d7%94%d7%93%d7%91%d7%a8%d7%94/)
    *   [דשנים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%93%d7%a9%d7%a0%d7%99%d7%9d/)

#### מידע

*   [יעקב פריימן, ראשון-לציון​](https://waze.com/ul?q=%D7%9E%D7%A9%D7%AA%D7%9C%D7%AA%20%D7%A2%D7%9C%20%D7%94%D7%93%D7%A8%D7%9A%20-%20%D7%A1%D7%A0%D7%99%D7%A3%20%D7%A4%D7%A8%D7%99%D7%99%D7%9E%D7%9F&z=10&navigate=yes)
*   [03-9550043](tel:03-9550043)
*   [054-6764600](tel:054-6764600)
*   03-9550072​
*   [c.alhaderech@gmail.com​](mailto:c.alhaderech@gmail.com%E2%80%8B)
*   שעות פעילות: 
*   א-ה' בין השעות 8:00-18:00
*   בימי ו' בין השעות 8:00-15:00
*   חנייה בשפע! בואו לבקר!​

#### חפשו אותנו

[Facebook](https://www.facebook.com/califmashtelot?fref=ts)[Instagram](https://www.instagram.com/al_haderech_nursery/)[Waze](https://waze.com/ul?q=%D7%9E%D7%A9%D7%AA%D7%9C%D7%AA%20%D7%A2%D7%9C%20%D7%94%D7%93%D7%A8%D7%9A%20-%20%D7%A1%D7%A0%D7%99%D7%A3%20%D7%A4%D7%A8%D7%99%D7%99%D7%9E%D7%9F&z=10&navigate=yes)

![Image 55: סמל נגישות](https://al-haderech.co.il/wp-content/plugins/accessibility-light/assets/img/wheelchair.png)

סגור את סרגל הכלים של נגישות

נגישות

*       *   _visibility\_off_ השבת את ההבזקים

    *   _title_ סמן כותרות

    *   _settings_ צבע רקע

*       *   _zoom\_out_ זום (הקטנה)

    *   _zoom\_in_ זום (הגדלה)

*       *   _remove\_circle\_outline_ הקטנת גופן

    *   _add\_circle\_outline_ הגדלת גופן

    *   _spellcheck_ גופן קריא

*       *   _brightness\_high_ ניגודיות בהירה

    *   _brightness\_low_ ניגודיות כהה

*       *   _format\_underlined_ הוסף קו תחתון לקישורים

    *   _font\_download_ סמן קישורים

*       *   לאפס את כל האפשרויות _cached_

    *   [![Image 56: נגישות לייט](https://al-haderech.co.il/wp-content/plugins/accessibility-light/assets/img/accessibility-light-logolight80.png)](https://sitelinx.co.il/)

Scroll to Top

## 🍎🍯 שנה טובה ומתוקה 🍎🍯

ראש השנה 2026 התחלנו! הקדימו הזמנותיכם לחג ושריינו לאהובים שלכם את המתנות הכי יפות שאפשר לקבל :)

## [לחצו כאן!](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a4%d7%a1%d7%97-2026/)

[SHOP NOW](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a4%d7%a1%d7%97-2026/)