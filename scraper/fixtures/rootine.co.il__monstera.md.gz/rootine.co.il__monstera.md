![Image 1: Spinner: White decorative](https://cdn.userway.org/widgetapp/images/spin_wh.svg)

![Image 2](https://cdn.userway.org/widgetapp/images/body_wh.svg)

![Image 3: Spinner: White decorative](https://cdn.userway.org/widgetapp/images/spin_wh.svg)

[דילוג לתוכן](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#MainContent)

*   **חדש!** משלוח אקספרס **1-3 ימי עסקים** זמין לערים נבחרות | משלוחים רגילים לכל הארץ חינם מעל 300₪  
*   **חדש!** משלוח אקספרס **1-3 ימי עסקים** זמין לערים נבחרות | משלוחים רגילים לכל הארץ חינם מעל 300₪  
*   **חדש!** משלוח אקספרס **1-3 ימי עסקים** זמין לערים נבחרות | משלוחים רגילים לכל הארץ חינם מעל 300₪  
*   **חדש!** משלוח אקספרס **1-3 ימי עסקים** זמין לערים נבחרות | משלוחים רגילים לכל הארץ חינם מעל 300₪  
*   **חדש!** משלוח אקספרס **1-3 ימי עסקים** זמין לערים נבחרות | משלוחים רגילים לכל הארץ חינם מעל 300₪  

 תפריט 

*   [דף הבית](https://rootine.co.il/) 
*   [חדש באתר!](https://rootine.co.il/collections/%D7%97%D7%93%D7%A9-%D7%91%D7%90%D7%AA%D7%A8) 
*   [צמחים עמידים לבית](https://rootine.co.il/pages/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%9E%D7%99%D7%93%D7%99%D7%9D-%D7%9C%D7%91%D7%99%D7%AA-%D7%95%D7%9C%D7%92%D7%9F) 
*   [צמחים אקזוטים ונדירים](https://rootine.co.il/pages/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%96%D7%95%D7%98%D7%99%D7%9D-%D7%95%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D) 
*    קטגוריות צמחים  

 קטגוריות צמחים 
    *    צמחים אקזוטים ומיוחדים  

 צמחים אקזוטים ומיוחדים 
        *   [כל הארואידים](https://rootine.co.il/collections/%D7%A4%D7%99%D7%9C%D7%95%D7%A0%D7%93%D7%A0%D7%93%D7%A8%D7%95%D7%9F-copy)
        *   [הויות](https://rootine.co.il/collections/%D7%94%D7%95%D7%99%D7%95%D7%AA)
        *   [מונסטרות](https://rootine.co.il/collections/%D7%94%D7%95%D7%99%D7%95%D7%AA-copy)
        *   [אלוקסיות](https://rootine.co.il/collections/%D7%90%D7%A8%D7%95%D7%90%D7%99%D7%93%D7%99%D7%9D-copy)
        *   [אנטוריומים](https://rootine.co.il/collections/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-copy)
        *   [פילונדנדרון](https://rootine.co.il/collections/%D7%90%D7%A0%D7%98%D7%95%D7%A8%D7%99%D7%95%D7%9D-copy)
        *   [מיניאטורים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9E%D7%99%D7%A0%D7%99%D7%98%D7%95%D7%A8%D7%99%D7%9D)
        *   [הנדירים של רוטין](https://rootine.co.il/collections/%D7%94%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D-%D7%91%D7%99%D7%95%D7%AA%D7%A8)
        *   [ידידותי לתקציב](https://rootine.co.il/collections/%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D-%D7%99%D7%93%D7%99%D7%93%D7%95%D7%AA%D7%99-%D7%9C%D7%AA%D7%A7%D7%A6%D7%99%D7%91)

    *   [צמחים טורפים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%98%D7%95%D7%A8%D7%A4%D7%99%D7%9D)
    *   [כל הצמחים](https://rootine.co.il/collections/%D7%9B%D7%9C-%D7%94%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
    *   [צמחים עמידים לבית](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%9E%D7%99%D7%93%D7%99%D7%9D-%D7%9C%D7%91%D7%99%D7%AA)
    *   [צמחי בית עמידים, אור חלש](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99-%D7%91%D7%99%D7%AA-%D7%9E%D7%AA%D7%90%D7%99%D7%9E%D7%99%D7%9D-%D7%9C%D7%A6%D7%9C-%D7%9E%D7%9C%D7%90)
    *   [צמחים נדירים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D)
    *   [צמחים נשפכים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%A9%D7%A4%D7%9B%D7%99%D7%9D)
    *   [צמחים מיניאטורים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9E%D7%99%D7%A0%D7%99%D7%98%D7%95%D7%A8%D7%99%D7%9D)
    *   [צמחי תבלין ומאכל](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99-%D7%AA%D7%91%D7%9C%D7%99%D7%9F-%D7%9E%D7%90%D7%9B%D7%9C)
    *   [צמחים למרפסת ולגינה](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%9E%D7%99%D7%93%D7%99%D7%9D-%D7%9C%D7%9E%D7%A8%D7%A4%D7%A1%D7%AA)
    *   [צמחים בטוחים לבעלי חיים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%91%D7%98%D7%95%D7%97%D7%99%D7%9D-%D7%9C%D7%91%D7%A2%D7%9C%D7%99-%D7%97%D7%99%D7%99%D7%9D)
    *   [סוקולנטים](https://rootine.co.il/collections/%D7%A1%D7%95%D7%A7%D7%95%D7%9C%D7%A0%D7%98%D7%99%D7%9D)

*    מצעי שתילה | דשנים | חומרי הדברה  

 מצעי שתילה | דשנים | חומרי הדברה 
    *   [אדמה ומצעי שתילה](https://rootine.co.il/collections/%D7%9E%D7%A6%D7%A2%D7%99-%D7%92%D7%99%D7%93%D7%95%D7%9C-%D7%90%D7%93%D7%9E%D7%94)
    *   [דשן & אוכל לצמחים](https://rootine.co.il/collections/%D7%93%D7%A9%D7%9F-%D7%90%D7%95%D7%9B%D7%9C-%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
    *   [חומרי הדברה](https://rootine.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94)

*    עציצים | כדים | אדניות  

 עציצים | כדים | אדניות 
    *   [כל הכלי שתילה](https://rootine.co.il/collections/%D7%9B%D7%9C-%D7%9B%D7%9C%D7%99-%D7%94%D7%92%D7%99%D7%93%D7%95%D7%9C)
    *   [כדים](https://rootine.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D)
    *   [עציצים](https://rootine.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99%D7%9D)
    *   [אדניות](https://rootine.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA)

*   [מערכות השקיה לבית ולמרפסת](https://rootine.co.il/collections/mp205) 
*   [מערכות הידרופוניות](https://rootine.co.il/collections/%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%94%D7%99%D7%93%D7%A8%D7%95%D7%A4%D7%95%D7%A0%D7%99%D7%95%D7%AA) 
*    שירות לקוחות  

 שירות לקוחות 
    *   [מי אנחנו](https://rootine.co.il/pages/%D7%90%D7%99%D7%9A-%D7%94%D7%A7%D7%9E%D7%AA%D7%99-%D7%90%D7%AA-%D7%A8%D7%95%D7%98%D7%99%D7%9F?_pos=1&_sid=66d6919f6&_ss=r)
    *   [שאלות & תשובות](https://rootine.co.il/pages/contact)
    *   [מדריך להתקנת מערכת ההשקיה](https://rootine.co.il/pages/%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%9C%D7%94%D7%AA%D7%A7%D7%A0%D7%AA-%D7%9E%D7%A2%D7%A8%D7%9B%D7%AA-mp205s)
    *   [מדריכי צמחים](https://rootine.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
    *   [גיפט קארד דיגיטלי רוטין](https://rootine.co.il/products/%D7%92%D7%99%D7%A4%D7%98-%D7%A7%D7%90%D7%A8%D7%93-%D7%93%D7%99%D7%92%D7%99%D7%98%D7%9C%D7%99-%D7%A8%D7%95%D7%98%D7%99%D7%9F)
    *   [תוכנית השותפים של רוטין](https://rootine-hub.co.il/)
    *   [הביקורות שלכם](https://rootine.co.il/pages/%D7%94%D7%91%D7%99%D7%A7%D7%95%D7%A8%D7%95%D7%AA-%D7%A9%D7%9C%D7%9B%D7%9D)

*    הטבות החודש  

 הטבות החודש 
    *   [מונסטרה אדנסוניי במתנה](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99%D7%99)
    *   [דיונאה צמח טורף במתנה](https://rootine.co.il/products/%D7%93%D7%99%D7%95%D7%A0%D7%90%D7%94-%D7%9E%D7%91%D7%A6%D7%A2-%D7%91%D7%99%D7%99%D7%91%D7%99)
    *   [30% על מערכות ההשקיה](https://rootine.co.il/products/mp205)

[התחברות](https://rootine.co.il/customer_authentication/redirect?locale=he&region_country=IL)

*   [Facebook](https://www.facebook.com/Rootine)
*   [Instagram](https://www.instagram.com/rootine_il/)
*   [YouTube](https://www.youtube.com/@yarok-ba-mirpeset)
*   [TikTok](https://www.tiktok.com/@gananimisrael?_t=ZS-8uqGuj7xgcp&_r=1)

[![Image 4: Rootine](https://rootine.co.il/cdn/shop/files/ROOTINE_new_4.png?v=1762168765&width=500)![Image 5: Rootine](https://rootine.co.il/cdn/shop/files/ROOTINE_e5047578-0bf0-4e81-9815-30123f7a0101.png?v=1769856125&width=500)](https://rootine.co.il/)
*   [דף הבית](https://rootine.co.il/)
*   [חדש באתר!](https://rootine.co.il/collections/%D7%97%D7%93%D7%A9-%D7%91%D7%90%D7%AA%D7%A8)
*   [צמחים עמידים לבית](https://rootine.co.il/pages/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%9E%D7%99%D7%93%D7%99%D7%9D-%D7%9C%D7%91%D7%99%D7%AA-%D7%95%D7%9C%D7%92%D7%9F)
*   [צמחים אקזוטים ונדירים](https://rootine.co.il/pages/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%96%D7%95%D7%98%D7%99%D7%9D-%D7%95%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D)
*   
קטגוריות צמחים
    *   
צמחים אקזוטים ומיוחדים
        *   [כל הארואידים](https://rootine.co.il/collections/%D7%A4%D7%99%D7%9C%D7%95%D7%A0%D7%93%D7%A0%D7%93%D7%A8%D7%95%D7%9F-copy)
        *   [הויות](https://rootine.co.il/collections/%D7%94%D7%95%D7%99%D7%95%D7%AA)
        *   [מונסטרות](https://rootine.co.il/collections/%D7%94%D7%95%D7%99%D7%95%D7%AA-copy)
        *   [אלוקסיות](https://rootine.co.il/collections/%D7%90%D7%A8%D7%95%D7%90%D7%99%D7%93%D7%99%D7%9D-copy)
        *   [אנטוריומים](https://rootine.co.il/collections/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-copy)
        *   [פילונדנדרון](https://rootine.co.il/collections/%D7%90%D7%A0%D7%98%D7%95%D7%A8%D7%99%D7%95%D7%9D-copy)
        *   [מיניאטורים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9E%D7%99%D7%A0%D7%99%D7%98%D7%95%D7%A8%D7%99%D7%9D)
        *   [הנדירים של רוטין](https://rootine.co.il/collections/%D7%94%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D-%D7%91%D7%99%D7%95%D7%AA%D7%A8)
        *   [ידידותי לתקציב](https://rootine.co.il/collections/%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D-%D7%99%D7%93%D7%99%D7%93%D7%95%D7%AA%D7%99-%D7%9C%D7%AA%D7%A7%D7%A6%D7%99%D7%91)

    *   [צמחים טורפים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%98%D7%95%D7%A8%D7%A4%D7%99%D7%9D)
    *   [כל הצמחים](https://rootine.co.il/collections/%D7%9B%D7%9C-%D7%94%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
    *   [צמחים עמידים לבית](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%9E%D7%99%D7%93%D7%99%D7%9D-%D7%9C%D7%91%D7%99%D7%AA)
    *   [צמחי בית עמידים, אור חלש](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99-%D7%91%D7%99%D7%AA-%D7%9E%D7%AA%D7%90%D7%99%D7%9E%D7%99%D7%9D-%D7%9C%D7%A6%D7%9C-%D7%9E%D7%9C%D7%90)
    *   [צמחים נדירים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D)
    *   [צמחים נשפכים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%A9%D7%A4%D7%9B%D7%99%D7%9D)
    *   [צמחים מיניאטורים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9E%D7%99%D7%A0%D7%99%D7%98%D7%95%D7%A8%D7%99%D7%9D)
    *   [צמחי תבלין ומאכל](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99-%D7%AA%D7%91%D7%9C%D7%99%D7%9F-%D7%9E%D7%90%D7%9B%D7%9C)
    *   [צמחים למרפסת ולגינה](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%9E%D7%99%D7%93%D7%99%D7%9D-%D7%9C%D7%9E%D7%A8%D7%A4%D7%A1%D7%AA)
    *   [צמחים בטוחים לבעלי חיים](https://rootine.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%91%D7%98%D7%95%D7%97%D7%99%D7%9D-%D7%9C%D7%91%D7%A2%D7%9C%D7%99-%D7%97%D7%99%D7%99%D7%9D)
    *   [סוקולנטים](https://rootine.co.il/collections/%D7%A1%D7%95%D7%A7%D7%95%D7%9C%D7%A0%D7%98%D7%99%D7%9D)

*   
מצעי שתילה | דשנים | חומרי הדברה
    *   [אדמה ומצעי שתילה](https://rootine.co.il/collections/%D7%9E%D7%A6%D7%A2%D7%99-%D7%92%D7%99%D7%93%D7%95%D7%9C-%D7%90%D7%93%D7%9E%D7%94)
    *   [דשן & אוכל לצמחים](https://rootine.co.il/collections/%D7%93%D7%A9%D7%9F-%D7%90%D7%95%D7%9B%D7%9C-%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
    *   [חומרי הדברה](https://rootine.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94)

*   
עציצים | כדים | אדניות
    *   [כל הכלי שתילה](https://rootine.co.il/collections/%D7%9B%D7%9C-%D7%9B%D7%9C%D7%99-%D7%94%D7%92%D7%99%D7%93%D7%95%D7%9C)
    *   [כדים](https://rootine.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D)
    *   [עציצים](https://rootine.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99%D7%9D)
    *   [אדניות](https://rootine.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA)

*   [מערכות השקיה לבית ולמרפסת](https://rootine.co.il/collections/mp205)
*   [מערכות הידרופוניות](https://rootine.co.il/collections/%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%94%D7%99%D7%93%D7%A8%D7%95%D7%A4%D7%95%D7%A0%D7%99%D7%95%D7%AA)
*   
שירות לקוחות
    *   [מי אנחנו](https://rootine.co.il/pages/%D7%90%D7%99%D7%9A-%D7%94%D7%A7%D7%9E%D7%AA%D7%99-%D7%90%D7%AA-%D7%A8%D7%95%D7%98%D7%99%D7%9F?_pos=1&_sid=66d6919f6&_ss=r)
    *   [שאלות & תשובות](https://rootine.co.il/pages/contact)
    *   [מדריך להתקנת מערכת ההשקיה](https://rootine.co.il/pages/%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%9C%D7%94%D7%AA%D7%A7%D7%A0%D7%AA-%D7%9E%D7%A2%D7%A8%D7%9B%D7%AA-mp205s)
    *   [מדריכי צמחים](https://rootine.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
    *   [גיפט קארד דיגיטלי רוטין](https://rootine.co.il/products/%D7%92%D7%99%D7%A4%D7%98-%D7%A7%D7%90%D7%A8%D7%93-%D7%93%D7%99%D7%92%D7%99%D7%98%D7%9C%D7%99-%D7%A8%D7%95%D7%98%D7%99%D7%9F)
    *   [תוכנית השותפים של רוטין](https://rootine-hub.co.il/)
    *   [הביקורות שלכם](https://rootine.co.il/pages/%D7%94%D7%91%D7%99%D7%A7%D7%95%D7%A8%D7%95%D7%AA-%D7%A9%D7%9C%D7%9B%D7%9D)

*   
הטבות החודש
    *   [מונסטרה אדנסוניי במתנה](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99%D7%99)
    *   [דיונאה צמח טורף במתנה](https://rootine.co.il/products/%D7%93%D7%99%D7%95%D7%A0%D7%90%D7%94-%D7%9E%D7%91%D7%A6%D7%A2-%D7%91%D7%99%D7%99%D7%91%D7%99)
    *   [30% על מערכות ההשקיה](https://rootine.co.il/products/mp205)

חיפוש 

[התחברות](https://rootine.co.il/customer_authentication/redirect?locale=he&region_country=IL)[עגלת קניות](https://rootine.co.il/cart)

## העגלה שלך ריקה

[המשיכו לקנות](https://rootine.co.il/collections/all)
יש לכם משתמש?

[התחברו](https://rootine.co.il/customer_authentication/redirect?locale=he&region_country=IL) כדי לשלם מהר יותר.

## 0 מוצרים בעגלה

הטבות בדמי משלוח, עלות נוכחית: 35 ש״ח

משלוח עד הבית 35 ש״ח

משלוח עד הבית 29 ש״ח

משלוח חינם מעל 300!

טוען...

 הערות מיוחדות להזמנה הערות מיוחדות להזמנה 

**הטבות לזמן מוגבל**

![Image 6: דשן אצות ביו גל לצמחי בית, גן ומרפסת - רוטין (ירוק במרפסת לשעבר)](https://rootine.co.il/cdn/shop/files/dsh-avt-biv-gl-lmi-bit-g-vmrfst-7844431.png?v=1763570860&width=500)

### [דשן אצות ביו גל לצמחי בית, גן ומרפסת](https://rootine.co.il/products/%D7%91%D7%99%D7%95-%D7%92%D7%9C-%D7%93%D7%A9%D7%9F-%D7%90%D7%A6%D7%95%D7%AA)

49.00 ₪55.00 ₪

**הוסף**+

![Image 7: ספגנום מוס באיכות פרימיום 2 ליטר - רוטין (ירוק במרפסת לשעבר)](https://rootine.co.il/cdn/shop/files/sfgnvm-mvs-baivt-frimivm-2-lir-4938619.png?v=1763570736&width=500)

### [ספגנום מוס טרי באיכות פרימיום 1 ליטר](https://rootine.co.il/products/%D7%A1%D7%A4%D7%92%D7%A0%D7%95%D7%9D-%D7%9E%D7%95%D7%A1-%D7%91%D7%90%D7%99%D7%9B%D7%95%D7%AA-%D7%A4%D7%A8%D7%99%D7%9E%D7%99%D7%95%D7%9D-%D7%92%D7%A8%D7%9D)

19.00 ₪24.00 ₪

**הוסף**+

![Image 8: עציץ מגדלים שקוף במגוון גדלים - רוטין (ירוק במרפסת לשעבר)](https://rootine.co.il/cdn/shop/files/i-mgdlim-shkvf-bmgvv-gdlim-3423061.jpg?v=1763570622&width=500)

### [עציץ מגדלים שקוף במגוון גדלים](https://rootine.co.il/products/%D7%A2%D7%A6%D7%99%D7%A5-%D7%9E%D7%92%D7%93%D7%9C%D7%99%D7%9D-%D7%A9%D7%A7%D7%95%D7%A3-%D7%91%D7%9E%D7%92%D7%95%D7%95%D7%9F-%D7%92%D7%93%D7%9C%D7%99%D7%9D)

6.00 ₪6.00 ₪

**הוסף**+

![Image 9: בקר השקיה אוטומטי עם חיישן לחות מובנה + קיט השקיה](https://rootine.co.il/cdn/shop/files/ROOT_33.png?v=1777305631&width=500)

### [בקר השקיה אוטומטי עם חיישן לחות מובנה + קיט השקיה](https://rootine.co.il/products/mp205)

379.00 ₪558.00 ₪

**הוסף**+

 הערות מיוחדות להזמנה הערות מיוחדות להזמנה 

**סה״כ אחרי הנחה****0.00 ₪**

 תשלום 

# תוצאות חיפוש

חיפוש 

## סינון:

טווח מחירים 

0.00 ₪ -599.88 ₪ [איפוס](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

₪

מ 

₪

עד 

 ₪0 ₪599.88

אור 

 0 נבחרו [איפוס](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

אור
*   - [x]  צל חלקי (11) צל חלקי (11 מוצרים)  
*   - [x]  צל מלא (1) צל מלא (מוצר 1)  
*   - [x]  צל מלא, הרבה אור מסונן (21) צל מלא, הרבה אור מסונן (21 מוצרים)  

*   - [x]  צל חלקי (11) צל חלקי (11 מוצרים)  
*   - [x]  צל מלא (1) צל מלא (מוצר 1)  
*   - [x]  צל מלא, הרבה אור מסונן (21) צל מלא, הרבה אור מסונן (21 מוצרים)  

עונתיות 

 0 נבחרו [איפוס](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

עונתיות
*   - [x]  ירוק עד (20) ירוק עד (20 מוצרים)  
*   - [x]  רב שנתי (21) רב שנתי (21 מוצרים)  

*   - [x]  ירוק עד (20) ירוק עד (20 מוצרים)  
*   - [x]  רב שנתי (21) רב שנתי (21 מוצרים)  

מתאים ל 

 0 נבחרו [איפוס](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

מתאים ל
*   - [x]  בית (21) בית (21 מוצרים)  
*   - [x]  מרפסת (5) מרפסת (5 מוצרים)  
*   - [x]  משרד (11) משרד (11 מוצרים)  

*   - [x]  בית (21) בית (21 מוצרים)  
*   - [x]  מרפסת (5) מרפסת (5 מוצרים)  
*   - [x]  משרד (11) משרד (11 מוצרים)  

רמת קושי 

 0 נבחרו [איפוס](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

רמת קושי
*   - [x]  מתחילים (5) מתחילים (5 מוצרים)  
*   - [x]  מתקדמים (10) מתקדמים (10 מוצרים)  
*   - [x]  מנוסים (11) מנוסים (11 מוצרים)  
*   - [x]  מנוסים מאוד (3) מנוסים מאוד (3 מוצרים)  
*   - [x]  עמידים מאוד (1) עמידים מאוד (מוצר 1)  

*   - [x]  מתחילים (5) מתחילים (5 מוצרים)  
*   - [x]  מתקדמים (10) מתקדמים (10 מוצרים)  
*   - [x]  מנוסים (11) מנוסים (11 מוצרים)  
*   - [x]  מנוסים מאוד (3) מנוסים מאוד (3 מוצרים)  
*   - [x]  עמידים מאוד (1) עמידים מאוד (מוצר 1)  

משפחת צמחים 

 0 נבחרו [איפוס](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

משפחת צמחים
*   - [x]  אלוקסיה (1) אלוקסיה (מוצר 1)  
*   - [x]  ארואידים (21) ארואידים (21 מוצרים)  
*   - [x]  מונסטרה (20) מונסטרה (20 מוצרים)  

*   - [x]  אלוקסיה (1) אלוקסיה (מוצר 1)  
*   - [x]  ארואידים (21) ארואידים (21 מוצרים)  
*   - [x]  מונסטרה (20) מונסטרה (20 מוצרים)  

אופן צמיחה 

 0 נבחרו [איפוס](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

אופן צמיחה
*   - [x]  זקופים (2) זקופים (2 מוצרים)  
*   - [x]  מטפסים (21) מטפסים (21 מוצרים)  
*   - [x]  נשפכים (11) נשפכים (11 מוצרים)  
*   - [x]  שיחיים (1) שיחיים (מוצר 1)  

*   - [x]  זקופים (2) זקופים (2 מוצרים)  
*   - [x]  מטפסים (21) מטפסים (21 מוצרים)  
*   - [x]  נשפכים (11) נשפכים (11 מוצרים)  
*   - [x]  שיחיים (1) שיחיים (מוצר 1)  

[הסר הכל](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&options%5Bprefix%5D=last&sort_by=relevance)

## מיון לפי:

## 45 תוצאות

סינון ומיון סינון 

## סינון ומיון

## סינון

45 תוצאות

טווח מחירים

₪

מ 

₪

עד 

 ₪0 ₪599.88

אור

*   - [x]  צל חלקי (11) צל חלקי (11 מוצרים)  
*   - [x]  צל מלא (1) צל מלא (מוצר 1)  
*   - [x]  צל מלא, הרבה אור מסונן (21) צל מלא, הרבה אור מסונן (21 מוצרים)  

עונתיות

*   - [x]  ירוק עד (20) ירוק עד (20 מוצרים)  
*   - [x]  רב שנתי (21) רב שנתי (21 מוצרים)  

מתאים ל

*   - [x]  בית (21) בית (21 מוצרים)  
*   - [x]  מרפסת (5) מרפסת (5 מוצרים)  
*   - [x]  משרד (11) משרד (11 מוצרים)  

רמת קושי

*   - [x]  מתחילים (5) מתחילים (5 מוצרים)  
*   - [x]  מתקדמים (10) מתקדמים (10 מוצרים)  
*   - [x]  מנוסים (11) מנוסים (11 מוצרים)  
*   - [x]  מנוסים מאוד (3) מנוסים מאוד (3 מוצרים)  
*   - [x]  עמידים מאוד (1) עמידים מאוד (מוצר 1)  

משפחת צמחים

*   - [x]  אלוקסיה (1) אלוקסיה (מוצר 1)  
*   - [x]  ארואידים (21) ארואידים (21 מוצרים)  
*   - [x]  מונסטרה (20) מונסטרה (20 מוצרים)  

אופן צמיחה

*   - [x]  זקופים (2) זקופים (2 מוצרים)  
*   - [x]  מטפסים (21) מטפסים (21 מוצרים)  
*   - [x]  נשפכים (11) נשפכים (11 מוצרים)  
*   - [x]  שיחיים (1) שיחיים (מוצר 1)  

מיון לפי: 

[הסר הכל](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&options%5Bprefix%5D=last&sort_by=relevance) החל 

סינון ומיון 

[הסר הכל](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&options%5Bprefix%5D=last&sort_by=relevance)

## 45 תוצאות

*   ![Image 10: מונסטרה אלבו | גדול](https://rootine.co.il/cdn/shop/files/invimg_f1d93ce5d10a4674-fKCeUaf9S23hDdvmMxmTLIH3sPp8mt.png?v=1787215534&width=533)  ### [מונסטרה אלבו | גדול](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%9C%D7%91%D7%95-%D7%A2%D7%A6%D7%99%D7%A5-15-%D7%A1%D7%9E?_pos=1&_sid=9e87dd8b1&_ss=r) הנחה 33%     צילום לאישור 
### צילום לאישור

אנו נשלח לכם תמונה של הצמח לאישורכם לפני המשלוח    ### [מונסטרה אלבו | גדול](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%9C%D7%91%D7%95-%D7%A2%D7%A6%D7%99%D7%A5-15-%D7%A1%D7%9E?_pos=1&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 399.00 ₪  מחיר רגיל 399.00 ₪ מחיר מבצע~~ 599.00 ₪ ~~ מחיר יחידה/לכל     33%     
*   ![Image 11: מונסטרה דליסיוסה | בינוני](https://rootine.co.il/cdn/shop/files/download_2c89d5d2-453b-48e1-a307-76120b84a5d6.jpg?v=1764669169&width=533)  ### [מונסטרה דליסיוסה | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%93%D7%9C%D7%99%D7%A1%D7%99%D7%95%D7%A1%D7%94-%D7%A2%D7%A6%D7%99%D7%A5-12?_pos=2&_sid=9e87dd8b1&_ss=r)       ### [מונסטרה דליסיוסה | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%93%D7%9C%D7%99%D7%A1%D7%99%D7%95%D7%A1%D7%94-%D7%A2%D7%A6%D7%99%D7%A5-12?_pos=2&_sid=9e87dd8b1&_ss=r)

מחיר רגיל החל מ-46.80 ₪  מחיר רגיל החל מ-46.80 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 12: מונסטרה אדנסוניי מינט | בינוני-3-nan.png.png](https://rootine.co.il/cdn/shop/files/download_bc424e73-b80f-4951-87df-add509aceb3e.jpg?v=1778232374&width=533)  ### [מונסטרה אדנסוניי מינט | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99%D7%99-%D7%9E%D7%99%D7%A0%D7%98-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=3&_sid=9e87dd8b1&_ss=r)       ### [מונסטרה אדנסוניי מינט | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99%D7%99-%D7%9E%D7%99%D7%A0%D7%98-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=3&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 99.00 ₪  מחיר רגיל 99.00 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 13: מונסטרה bmf קוטר 5 - רוטין (ירוק במרפסת לשעבר)](https://rootine.co.il/cdn/shop/files/mvnsrh-bmf-kvr-5-8588102.png?v=1763570733&width=533)  ### [מונסטרה bmf | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-bmf?_pos=4&_sid=9e87dd8b1&_ss=r) הנחה 40%      ### [מונסטרה bmf | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-bmf?_pos=4&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 59.00 ₪  מחיר רגיל 59.00 ₪ מחיר מבצע~~ 99.00 ₪ ~~ מחיר יחידה/לכל     40%     
*   ![Image 14: מונסטרה אדנסוניי | בינוני](https://rootine.co.il/cdn/shop/files/download_df45ae93-3621-4c0a-8866-32c46b026a1e.jpg?v=1763991092&width=533)  ### [מונסטרה אדנסוניי | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99%D7%99?_pos=5&_sid=9e87dd8b1&_ss=r) הנחה 7%      ### [מונסטרה אדנסוניי | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99%D7%99?_pos=5&_sid=9e87dd8b1&_ss=r)

מחיר רגיל החל מ-60.00 ₪  מחיר רגיל החל מ-60.00 ₪ מחיר מבצע~~ 65.00 ₪ ~~ מחיר יחידה/לכל     7%     
*   ![Image 15: מונסטרה סטדליאנה סטאר דאסט | בינוני-3-nan.png.png](https://rootine.co.il/cdn/shop/files/download_af2611bc-812e-4dc9-809c-cc341ddfee72.jpg?v=1778228168&width=533)  ### [מונסטרה סטדליאנה סטאר דאסט | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A1%D7%98%D7%93%D7%9C%D7%99%D7%90%D7%A0%D7%94-%D7%A1%D7%98%D7%90%D7%A8-%D7%93%D7%90%D7%A1%D7%98-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=6&_sid=9e87dd8b1&_ss=r)     צילום לאישור 
### צילום לאישור

אנו נשלח לכם תמונה של הצמח לאישורכם לפני המשלוח    ### [מונסטרה סטדליאנה סטאר דאסט | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A1%D7%98%D7%93%D7%9C%D7%99%D7%90%D7%A0%D7%94-%D7%A1%D7%98%D7%90%D7%A8-%D7%93%D7%90%D7%A1%D7%98-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=6&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 479.88 ₪  מחיר רגיל 479.88 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 16: מונסטרה וויט מונסטר | בינוני-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_0cc6529b-adbb-4cdc-a907-25894fef7b51.jpg?v=1782982199&width=533)  ### [מונסטרה וויט מונסטר | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%95%D7%95%D7%99%D7%98-%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=7&_sid=9e87dd8b1&_ss=r)      ### [מונסטרה וויט מונסטר | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%95%D7%95%D7%99%D7%98-%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=7&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 359.88 ₪  מחיר רגיל 359.88 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 17: מונסטרה אדסוניי מגוונת | בייבי-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_c86b8662-71bd-4c28-8c20-dd64fddb69b5.jpg?v=1767281301&width=533)  ### [מונסטרה אדנסוני מגוונת | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A1%D7%95%D7%A0%D7%99%D7%99-%D7%9E%D7%92%D7%95%D7%95%D7%A0%D7%AA-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=8&_sid=9e87dd8b1&_ss=r)      צילום לאישור 
### צילום לאישור

אנו נשלח לכם תמונה של הצמח לאישורכם לפני המשלוח    ### [מונסטרה אדנסוני מגוונת | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A1%D7%95%D7%A0%D7%99%D7%99-%D7%9E%D7%92%D7%95%D7%95%D7%A0%D7%AA-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=8&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 192.00 ₪  מחיר רגיל 192.00 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 18: מונסטרה תאי קוטר 5 - רוטין (ירוק במרפסת לשעבר)](https://rootine.co.il/cdn/shop/files/mvnsrh-tai-kvr-5-9364830.png?v=1763570675&width=533)  ### [מונסטרה תאי | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%AA%D7%90%D7%99-%D7%A7%D7%95%D7%98%D7%A8-5?_pos=9&_sid=9e87dd8b1&_ss=r)       ### [מונסטרה תאי | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%AA%D7%90%D7%99-%D7%A7%D7%95%D7%98%D7%A8-5?_pos=9&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 119.88 ₪  מחיר רגיל 119.88 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 19: מונסטרה גולדן/ למון ליים | בייבי-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_3266212c-327c-4f89-a1da-9f3e0d429b40.jpg?v=1782934783&width=533)  ### [מונסטרה גולדן/ למון ליים | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%92%D7%95%D7%9C%D7%93%D7%9F-%D7%9C%D7%9E%D7%95%D7%9F-%D7%9C%D7%99%D7%99%D7%9D-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=10&_sid=9e87dd8b1&_ss=r)       ### [מונסטרה גולדן/ למון ליים | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%92%D7%95%D7%9C%D7%93%D7%9F-%D7%9C%D7%9E%D7%95%D7%9F-%D7%9C%D7%99%D7%99%D7%9D-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=10&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 359.88 ₪  מחיר רגיל 359.88 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 20: מונסטרה אבליקה פרו | בייבי-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_98a28646-02e2-48b3-8b58-ba885606249e.jpg?v=1770718484&width=533)  ### [מונסטרה אובליקה פרו | בייבי מבצע](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%91%D7%9C%D7%99%D7%A7%D7%94-%D7%A4%D7%A8%D7%95-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=11&_sid=9e87dd8b1&_ss=r) הנחה 11%     ### [מונסטרה אובליקה פרו | בייבי מבצע](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%91%D7%9C%D7%99%D7%A7%D7%94-%D7%A4%D7%A8%D7%95-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=11&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 69.00 ₪  מחיר רגיל 69.00 ₪ מחיר מבצע~~ 78.00 ₪ ~~ מחיר יחידה/לכל     11%     
*   ![Image 21: מונסטרה פרוזן פרקלס — 1](https://rootine.co.il/cdn/shop/files/D7_9E_D7_95_D7_A0_D7_A1_D7_98_D7_A8_D7_94-_D7_A4_D7_A8_D7_95_D7_96_D7_9F-_D7_A4_D7_A8_D7_A7_D7_9C_D7_A1-_D7_91_D7_99_D7_99_D7_91_D7_99-1-1-E6c0HtZ84l92FivVzsab1Q6aGOP2jx.png?v=1787163180&width=533)  ### [מונסטרה פרוזן פרקלס | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A4%D7%A8%D7%95%D7%96%D7%9F-%D7%A4%D7%A8%D7%A7%D7%9C%D7%A1-%D7%91%D7%99%D7%99%D7%91%D7%99-1?_pos=12&_sid=9e87dd8b1&_ss=r)     ### [מונסטרה פרוזן פרקלס | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A4%D7%A8%D7%95%D7%96%D7%9F-%D7%A4%D7%A8%D7%A7%D7%9C%D7%A1-%D7%91%D7%99%D7%99%D7%91%D7%99-1?_pos=12&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 70.80 ₪  מחיר רגיל 70.80 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 22: מונסטרה פרו מגוונת | בינוני-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_b7ed334d-3f16-4819-a0e8-923132cc6ec8.jpg?v=1780307324&width=533)  ### [מונסטרה פרו מגוונת | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A4%D7%A8%D7%95-%D7%9E%D7%92%D7%95%D7%95%D7%A0%D7%AA-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=13&_sid=9e87dd8b1&_ss=r)       ### [מונסטרה פרו מגוונת | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A4%D7%A8%D7%95-%D7%9E%D7%92%D7%95%D7%95%D7%A0%D7%AA-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=13&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 478.80 ₪  מחיר רגיל 478.80 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 23: מונסטרה אוסיי דרים — 1](https://rootine.co.il/cdn/shop/files/D7_9E_D7_95_D7_A0_D7_A1_D7_98_D7_A8_D7_94-_D7_90_D7_95_D7_A1_D7_99_D7_99-_D7_93_D7_A8_D7_99_D7_9D-_D7_91_D7_99_D7_A0_D7_95_D7_A0_D7_99-1-qoZQaL7OkBZzZMihhC2PcMLfNhkhUK.png?v=1787162100&width=533)  ### [מונסטרה אוסיי דרים | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%95%D7%A1%D7%99%D7%99-%D7%93%D7%A8%D7%99%D7%9D-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=14&_sid=9e87dd8b1&_ss=r)     ### [מונסטרה אוסיי דרים | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%95%D7%A1%D7%99%D7%99-%D7%93%D7%A8%D7%99%D7%9D-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=14&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 418.80 ₪  מחיר רגיל 418.80 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 24: מונסטרה מינט | בייבי מבצע-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_793b4d71-f12d-4374-8896-74b03d4b8a9a.jpg?v=1770726771&width=533)  ### [מונסטרה מינט | בייבי מבצע](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%99%D7%A0%D7%98-%D7%91%D7%99%D7%99%D7%91%D7%99-%D7%9E%D7%91%D7%A6%D7%A2?_pos=15&_sid=9e87dd8b1&_ss=r) הנחה 10%    צילום לאישור 
### צילום לאישור

אנו נשלח לכם תמונה של הצמח לאישורכם לפני המשלוח    ### [מונסטרה מינט | בייבי מבצע](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%99%D7%A0%D7%98-%D7%91%D7%99%D7%99%D7%91%D7%99-%D7%9E%D7%91%D7%A6%D7%A2?_pos=15&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 348.60 ₪  מחיר רגיל 348.60 ₪ מחיר מבצע~~ 388.44 ₪ ~~ מחיר יחידה/לכל     10%     
*   ![Image 25: סטרה סטאדליאנה מגוונת | בינוני-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_ac589fc0-b957-4ea4-b7bc-9ade12d6abf2.jpg?v=1778235101&width=533)  ### [מונסטרה סטאדליאנה מגוונת | בינוני](https://rootine.co.il/products/%D7%A1%D7%98%D7%A8%D7%94-%D7%A1%D7%98%D7%90%D7%93%D7%9C%D7%99%D7%90%D7%A0%D7%94-%D7%9E%D7%92%D7%95%D7%95%D7%A0%D7%AA-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=16&_sid=9e87dd8b1&_ss=r)       ### [מונסטרה סטאדליאנה מגוונת | בינוני](https://rootine.co.il/products/%D7%A1%D7%98%D7%A8%D7%94-%D7%A1%D7%98%D7%90%D7%93%D7%9C%D7%99%D7%90%D7%A0%D7%94-%D7%9E%D7%92%D7%95%D7%95%D7%A0%D7%AA-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=16&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 178.80 ₪  מחיר רגיל 178.80 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 26: מונסטרה באלבזור | בייבי-3-nan.png.png](https://rootine.co.il/cdn/shop/files/download_6ff20c9e-c585-4fa5-8578-a2fef6d4a1c1.jpg?v=1778227309&width=533)  ### [מונסטרה באלבזור | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%91%D7%90%D7%9C%D7%91%D7%96%D7%95%D7%A8-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=17&_sid=9e87dd8b1&_ss=r) הנחה 39%    צילום לאישור 
### צילום לאישור

אנו נשלח לכם תמונה של הצמח לאישורכם לפני המשלוח    ### [מונסטרה באלבזור | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%91%D7%90%D7%9C%D7%91%D7%96%D7%95%D7%A8-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=17&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 599.88 ₪  מחיר רגיל 599.88 ₪ מחיר מבצע~~ 999.00 ₪ ~~ מחיר יחידה/לכל     39%     
*   ![Image 27: מונסטרה אדנסוני אוריאה | בינוני-2-nan.png.png](https://rootine.co.il/cdn/shop/files/download_8ec72fcb-a5ea-4482-a47a-0c8e2c8bd280.jpg?v=1775839936&width=533)  ### [מונסטרה אדנסוני אוריאה | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99-%D7%90%D7%95%D7%A8%D7%99%D7%90%D7%94-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=18&_sid=9e87dd8b1&_ss=r)     צילום לאישור 
### צילום לאישור

אנו נשלח לכם תמונה של הצמח לאישורכם לפני המשלוח    ### [מונסטרה אדנסוני אוריאה | בינוני](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99-%D7%90%D7%95%D7%A8%D7%99%D7%90%D7%94-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=18&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 298.80 ₪  מחיר רגיל 298.80 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 28: מונסטרה סילטה פיקנה אוריאה — 3](https://rootine.co.il/cdn/shop/files/D7_9E_D7_95_D7_A0_D7_A1_D7_98_D7_A8_D7_94-_D7_A1_D7_99_D7_9C_D7_98_D7_94-_D7_A4_D7_99_D7_A7_D7_A0_D7_94-_D7_90_D7_95_D7_A8_D7_99_D7_90_D7_94-_D7_91_D7_99_D7_99_D7_91_D7_99-3-Kfor4qYS.png?v=1787166630&width=533)  ### [מונסטרה סילטה פיקנה אוריאה | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A1%D7%99%D7%9C%D7%98%D7%94-%D7%A4%D7%99%D7%A7%D7%A0%D7%94-%D7%90%D7%95%D7%A8%D7%99%D7%90%D7%94-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=19&_sid=9e87dd8b1&_ss=r)     ### [מונסטרה סילטה פיקנה אוריאה | בייבי](https://rootine.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A1%D7%99%D7%9C%D7%98%D7%94-%D7%A4%D7%99%D7%A7%D7%A0%D7%94-%D7%90%D7%95%D7%A8%D7%99%D7%90%D7%94-%D7%91%D7%99%D7%99%D7%91%D7%99?_pos=19&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 599.88 ₪  מחיר רגיל 599.88 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 29: מצע גידול מאוורר לארואידים 2 ליטר - רוטין (ירוק במרפסת לשעבר)](https://rootine.co.il/cdn/shop/files/m-gidvl-mavvrr-larvaidim-2-lir-9580159.png?v=1763570735&width=533)  ### [מצע גידול מאוורר לארואידים 2 ליטר](https://rootine.co.il/products/%D7%9E%D7%A6%D7%A2-%D7%92%D7%99%D7%93%D7%95%D7%9C-%D7%9E%D7%90%D7%95%D7%95%D7%A8%D7%A8-%D7%9C%D7%90%D7%A8%D7%95%D7%A8%D7%99%D7%93%D7%99%D7%9D-%D7%9C%D7%99%D7%98%D7%A8?_pos=20&_sid=9e87dd8b1&_ss=r)     ### [מצע גידול מאוורר לארואידים 2 ליטר](https://rootine.co.il/products/%D7%9E%D7%A6%D7%A2-%D7%92%D7%99%D7%93%D7%95%D7%9C-%D7%9E%D7%90%D7%95%D7%95%D7%A8%D7%A8-%D7%9C%D7%90%D7%A8%D7%95%D7%A8%D7%99%D7%93%D7%99%D7%9D-%D7%9C%D7%99%D7%98%D7%A8?_pos=20&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 19.00 ₪  מחיר רגיל 19.00 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 30: עמוד מוס | גובה 45 קוטר 5-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_e56cedd3-a0a4-4a19-ba98-1779b99e43c2.jpg?v=1776858810&width=533)  ### [עמוד מוס | מכיל ספגנום איכותי | גובה 45סמ קוטר 4סמ מבצע](https://rootine.co.il/products/%D7%A2%D7%9E%D7%95%D7%93-%D7%9E%D7%95%D7%A1?_pos=21&_sid=9e87dd8b1&_ss=r)     ### [עמוד מוס | מכיל ספגנום איכותי | גובה 45סמ קוטר 4סמ מבצע](https://rootine.co.il/products/%D7%A2%D7%9E%D7%95%D7%93-%D7%9E%D7%95%D7%A1?_pos=21&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 59.00 ₪  מחיר רגיל 59.00 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 31: שלישיית מבחנות לייחור צמחים-1-nan.png.png](https://rootine.co.il/cdn/shop/files/download_002d3bc5-686c-4258-b7f7-0315dc834191.jpg?v=1776858982&width=533)  ### [שלישיית מבחנות לייחור צמחים](https://rootine.co.il/products/%D7%9E%D7%91%D7%97%D7%A0%D7%95%D7%AA-%D7%94%D7%99%D7%93%D7%A8%D7%95%D7%A4%D7%95%D7%A0%D7%99%D7%95%D7%AA?_pos=22&_sid=9e87dd8b1&_ss=r)     ### [שלישיית מבחנות לייחור צמחים](https://rootine.co.il/products/%D7%9E%D7%91%D7%97%D7%A0%D7%95%D7%AA-%D7%94%D7%99%D7%93%D7%A8%D7%95%D7%A4%D7%95%D7%A0%D7%99%D7%95%D7%AA?_pos=22&_sid=9e87dd8b1&_ss=r)

מחיר רגיל 47.88 ₪  מחיר רגיל 47.88 ₪ מחיר מבצע מחיר יחידה/לכל        
*   ![Image 32: המדריך המקיף לגידול מונסטרה דליקיוזה 🌿 - רוטין (ירוק במרפסת לשעבר)](https://rootine.co.il/cdn/shop/articles/hmdri-hmkif-lgidvl-mvnsrh-dlikivzh-9726972.png?v=1763570406&width=533)  ### [המדריך המקיף לגידול מונסטרה דליקיוזה 🌿](https://rootine.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%94%D7%9E%D7%A7%D7%99%D7%A3-%D7%9C%D7%92%D7%99%D7%93%D7%95%D7%9C-%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%93%D7%9C%D7%99%D7%A7%D7%99%D7%95%D7%96%D7%94-%F0%9F%8C%BF?_pos=23&_sid=9e87dd8b1&_ss=r)

2 בספטמבר 2024  בלוג   ### [המדריך המקיף לגידול מונסטרה דליקיוזה 🌿](https://rootine.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%94%D7%9E%D7%A7%D7%99%D7%A3-%D7%9C%D7%92%D7%99%D7%93%D7%95%D7%9C-%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%93%D7%9C%D7%99%D7%A7%D7%99%D7%95%D7%96%D7%94-%F0%9F%8C%BF?_pos=23&_sid=9e87dd8b1&_ss=r)

2 בספטמבר 2024  בלוג    
*   ![Image 33: המדריך המקיף לגידול מונסטרה אדנסוני (Monstera adansonii) 🧀 - רוטין (ירוק במרפסת לשעבר)](https://rootine.co.il/cdn/shop/articles/hmdri-hmkif-lgidvl-mvnsrh-adnsvni-monstera-adansonii-3567154.png?v=1763570518&width=533)  ### [המדריך המקיף לגידול מונסטרה אדנסוני (Monstera a...](https://rootine.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%94%D7%9E%D7%A7%D7%99%D7%A3-%D7%9C%D7%92%D7%99%D7%93%D7%95%D7%9C-%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99-monstera-adansonii-%F0%9F%A7%80?_pos=24&_sid=9e87dd8b1&_ss=r)

12 באפריל 2025  בלוג   ### [המדריך המקיף לגידול מונסטרה אדנסוני (Monstera a...](https://rootine.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%94%D7%9E%D7%A7%D7%99%D7%A3-%D7%9C%D7%92%D7%99%D7%93%D7%95%D7%9C-%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%93%D7%A0%D7%A1%D7%95%D7%A0%D7%99-monstera-adansonii-%F0%9F%A7%80?_pos=24&_sid=9e87dd8b1&_ss=r)

12 באפריל 2025  בלוג    

*   [1](https://rootine.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)
*   [2](https://rootine.co.il/search?page=2&q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)
*   [](https://rootine.co.il/search?page=2&q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

[](https://wa.me/972559935950)

![Image 34](https://rootine.co.il/cdn/shop/files/ROOTINE_new_4.png?v=1762168765&width=760)

## הצטרפו למשפחת רוטין

טיפים מקצועיים, מדריכי צמחים מקיפים והנחות בלעדיות בניוזלטר שלנו!

 כתובת מייל  

 אני רוצה! 

## ראשי

*   [חנות](https://rootine.co.il/)
*   [שירות לקוחות](https://rootine.co.il/pages/contact)
*   [הסיפור שלנו](https://rootine.co.il/pages/%D7%94%D7%A1%D7%99%D7%A4%D7%95%D7%A8-%D7%A9%D7%9C%D7%A0%D7%95)
*   [מדריכי צמחים](https://rootine.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
*   [תוכנית השותפים של רוטין](https://rootine-hub.co.il/)

## מידע

*   [יצירת קשר](https://rootine.co.il/pages/contact)
*   [תקנון האתר](https://rootine.co.il/pages/%D7%AA%D7%A7%D7%A0%D7%95%D7%9F-%D7%94%D7%90%D7%AA%D7%A8)
*   [מדיניות משלוחים/ החזרות](https://rootine.co.il/pages/%D7%9E%D7%93%D7%99%D7%A0%D7%99%D7%95%D7%AA-%D7%9E%D7%A9%D7%9C%D7%95%D7%97%D7%99%D7%9D)
*   [משלוח אקספרס 1-3 ימי עסקים (ערים זכאיות)](https://rootine.co.il/pages/%D7%9E%D7%A9%D7%9C%D7%95%D7%97-%D7%90%D7%A7%D7%A1%D7%A4%D7%A8%D7%A1-1-3-%D7%99%D7%9E%D7%99-%D7%A2%D7%A1%D7%A7%D7%99%D7%9D-%D7%A2%D7%A8%D7%99%D7%9D-%D7%96%D7%9B%D7%90%D7%99%D7%95%D7%AA)
*   [אחריות מורחבת 45 יום (מערכות השקיה)](https://rootine.co.il/pages/%D7%AA%D7%A7%D7%A0%D7%95%D7%9F-%D7%94%D7%97%D7%96%D7%A8%D7%95%D7%AA-%D7%91%D7%9E%D7%A1%D7%92%D7%A8%D7%AA-45-%D7%99%D7%95%D7%9D-%D7%94%D7%AA%D7%A0%D7%A1%D7%95%D7%AA)
*   [אבטחת מידע ופרטיות](https://rootine.co.il/pages/%D7%90%D7%91%D7%98%D7%97%D7%AA-%D7%9E%D7%99%D7%93%D7%A2-%D7%95%D7%A4%D7%A8%D7%98%D7%99%D7%95%D7%AA)
*   [נגישות](https://rootine.co.il/pages/%D7%A0%D7%92%D7%99%D7%A9%D7%95%D7%AA)

## טלפון: 055-993-5950

שירות הלקוחות שלנו זמין בימים ראשון עד חמישי: 10:00-18:00 [](https://wa.me/972559935950 "https://wa.me/972559935950")לינק ישיר לוואצאפ: [https://wa.me/972559935950](https://wa.me/972559935950 "https://wa.me/972559935950")

ובמייל: info@gananim-israel.com

**כתובת משרדים****(ללא קבלת קהל)**:

ראשון לציון, שדה נחום 10

*   [Facebook](https://www.facebook.com/Rootine)
*   [Instagram](https://www.instagram.com/rootine_il/)
*   [YouTube](https://www.youtube.com/@yarok-ba-mirpeset)
*   [TikTok](https://www.tiktok.com/@gananimisrael?_t=ZS-8uqGuj7xgcp&_r=1)

אמצעי תשלום

 © 2026, [Rootine](https://rootine.co.il/)כל הזכויות שמורות

*   בחירת תוצאות נבחרות בעמוד מלא חדש.
*   פותח בחלון חדש.

category: