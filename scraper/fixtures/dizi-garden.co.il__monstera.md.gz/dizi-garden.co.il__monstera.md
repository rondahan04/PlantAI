[Skip to content](#main)

* Dizigarden   
   דיזיגארדן - עציץ רק ₪60   
    משלוחים מהירים בתל אביב רמת גן וגבעתיים - הזמינו עכשיו

* [וואטסאפ](https://wa.me/972505900190)

[![דיזיגארדן](https://dizi-garden.co.il/wp-content/uploads/2021/11/logo2.jpg)![דיזיגארדן](https://dizi-garden.co.il/wp-content/uploads/2021/11/logo2.jpg)](https://dizi-garden.co.il/ "דיזיגארדן - עציץ רק ₪60")

* [**0**](https://dizi-garden.co.il/cart/ "סל קניות") 

  #### סל קניות

  אין מוצרים בסל הקניות.

* [צמחים](https://dizi-garden.co.il/)
  + [צמחים ב₪35](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9135/)
  + [צמחים ב₪60](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9160/)
* [כלים](https://dizi-garden.co.il/%d7%9b%d7%9c%d7%99%d7%9d/)
* [צמח + כלי](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99/)
* [מוצרים נלווים](https://dizi-garden.co.il/%d7%9e%d7%95%d7%a6%d7%a8%d7%99%d7%9d-%d7%a0%d7%9c%d7%95%d7%95%d7%99%d7%9d/)
* [צור קשר](https://dizi-garden.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)
* [סל קניות / ₪0   **0**](https://dizi-garden.co.il/cart/ "סל קניות") 
  + אין מוצרים בסל הקניות.

מציג את כל 2 התוצאות

[![](https://dizi-garden.co.il/wp-content/uploads/2021/12/IMG_5681-300x300.jpeg)](https://dizi-garden.co.il/product/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%90%d7%a0%d7%a7%d7%99-%d7%a7%d7%95%d7%98%d7%a8-12/)

[תצוגה מהירה](#quick-view)

[מונסטרה מאנקי – קוטר 12](https://dizi-garden.co.il/product/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%90%d7%a0%d7%a7%d7%99-%d7%a7%d7%95%d7%98%d7%a8-12/)

₪60

[הוספה לסל](?add-to-cart=2577)

[![](https://dizi-garden.co.il/wp-content/uploads/2021/11/WhatsApp-Image-2021-11-23-at-15.24.58-e1637745127620-300x300.jpeg)](https://dizi-garden.co.il/product/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a7%d7%95%d7%98%d7%a8-24/)

[תצוגה מהירה](#quick-view)

[מונסטרה – קוטר 24](https://dizi-garden.co.il/product/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a7%d7%95%d7%98%d7%a8-24/)

₪60

[הוספה לסל](?add-to-cart=2442)

* [צמחים](https://dizi-garden.co.il/)
  + [צמחים ב₪35](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9135/)
  + [צמחים ב₪60](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9160/)
* [כלים](https://dizi-garden.co.il/%d7%9b%d7%9c%d7%99%d7%9d/)
* [צמח + כלי](https://dizi-garden.co.il/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99/)
* [מוצרים נלווים](https://dizi-garden.co.il/%d7%9e%d7%95%d7%a6%d7%a8%d7%99%d7%9d-%d7%a0%d7%9c%d7%95%d7%95%d7%99%d7%9d/)
* [צור קשר](https://dizi-garden.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)
* [התחבר](https://dizi-garden.co.il/my-account/)

#### נגישות

* + *visibility\_off*השבת את ההבזקים
  + *title*סמן כותרות
  + *settings*צבע רקע
* + *zoom\_out*זום (הקטנה)
  + *zoom\_in*זום (הגדלה)
* + *remove\_circle\_outline*הקטנת גופן
  + *add\_circle\_outline*הגדלת גופן
  + *spellcheck*גופן קריא
* + *brightness\_high*ניגודיות בהירה
  + *brightness\_low*ניגודיות כהה
* + *format\_underlined*הוסף קו תחתון לקישורים
  + *font\_download*סמן קישורים
* + לאפס את כל האפשרויות*cached*

### התחבר

### הרשמה

 