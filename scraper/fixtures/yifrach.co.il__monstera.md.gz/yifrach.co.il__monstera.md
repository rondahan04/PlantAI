עדכונים

![Image 1](https://yifrach.co.il/images/System/news_arrow.png)

#### משלוח עד יום עסקים אחד בהתאם למלאי.

#### כתובת למגיעים ברכב: הנגרים 14 תל אביב (חניה חינם, או לחפש ברחובות הסמוכים)

#### באים מפלורנטין? הכניסה לסמטה מרחוב אברבאנל 35 (ליד הגרפיטי של רחל)

#### באים ברכבת קלה? תרדו בתחנת אליפלט- 7 דקות הליכה

- [x] 
*   [![Image 2](https://yifrach.co.il/images/System/flags/lang_new_2019.png)שפות](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#customer_login)
    *   [![Image 3](https://yifrach.co.il/images/System/flags/heb_lang_icon.png)עברית](javascript:__doPostBack('ctl00$ctl12$lblHeb',''))
    *   [![Image 4](https://yifrach.co.il/images/System/flags/en_lang_icon.png)English](javascript:__doPostBack('ctl00$ctl12$lblEng',''))
    *   [![Image 5](https://yifrach.co.il/images/System/flags/sp_lang_icon.png)Arab](javascript:__doPostBack('ctl00$ctl12$lblArab',''))
    *   [![Image 6](https://yifrach.co.il/images/System/flags/gr_lang_icon.png)Russian](javascript:__doPostBack('ctl00$ctl12$lblRu',''))
    *   [![Image 7](https://yifrach.co.il/images/System/flags/fr_flag.png)French](javascript:__doPostBack('ctl00$ctl12$lblFr',''))

[](https://www.facebook.com/%D7%99%D7%A4%D7%A8%D7%97-%D7%9E%D7%A9%D7%AA%D7%9C%D7%94-%D7%90%D7%95%D7%A4%D7%98%D7%99%D7%9E%D7%99%D7%AA-108111661749862)[](https://wa.me/9720549380028)[](https://www.instagram.com/yifrach_/)[054-9380028](https://api.whatsapp.com/send?phone=9720549380028)

- [x] 0![Image 8](https://yifrach.co.il/images/System/icons/cart/cart_yifrach.png) 

מוצרים: 0

[סגירה](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)

[לסל הקניות 0₪](https://yifrach.co.il/cart.aspx)[המשך קניה](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)

- [x] 
*   [![Image 9](https://yifrach.co.il/images/System/icons/cart/login_yifrach.png) כניסה](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#customer_login)
    *   [החשבון שלי](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)
    *   [מועדפים](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)
    *   [יציאה](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)

[![Image 10: 9720549380028](https://yifrach.co.il/images/header_website_image1_rndjkvv.png)](https://yifrach.co.il/index.aspx)

[צרו קשר](https://yifrach.co.il/contact.aspx)[לעסקים](https://yifrach.co.il/pid.aspx?P_pageId=10&P_catId=1)[משלוחים](https://yifrach.co.il/pid.aspx?P_pageId=9&P_catId=1)[אודות](https://yifrach.co.il/pid.aspx?P_pageId=1&P_catId=1)[נגישות](https://yifrach.co.il/pid.aspx?P_pageId=8&P_catId=1)[תקנון אתר](https://yifrach.co.il/pid.aspx?P_pageId=6&P_catId=1)[מדיניות החזרת מוצרים](https://yifrach.co.il/pid.aspx?P_pageId=7&P_catId=1)[מדיניות פרטיות](https://yifrach.co.il/pid.aspx?P_pageId=11&P_catId=1)[](https://yifrach.co.il/mineraz.aspx)

[חיפוש](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#openSearch)[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)

*   [דפי האתר](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)#### [לעסקים](https://yifrach.co.il/pid.aspx?P_pageId=10&P_catId=1)#### [משלוחים](https://yifrach.co.il/pid.aspx?P_pageId=9&P_catId=1)#### [אודות](https://yifrach.co.il/pid.aspx?P_pageId=1&P_catId=1)#### [נגישות](https://yifrach.co.il/pid.aspx?P_pageId=8&P_catId=1)#### [תקנון אתר](https://yifrach.co.il/pid.aspx?P_pageId=6&P_catId=1)#### [מדיניות החזרת מוצרים](https://yifrach.co.il/pid.aspx?P_pageId=7&P_catId=1)#### [מדיניות פרטיות](https://yifrach.co.il/pid.aspx?P_pageId=11&P_catId=1) #### צרו קשר   
*   [צמחים](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=5)## [צמחי בית](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=339) ## [צמחים חזקים שקשה להרוג](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=340) ## [צמחים למקומות חשוכים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=341) ## [מיוחדים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=362) ## [קקטוסים וסוקולנטים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=346) ## [צמחי חוץ](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=347) ## [פרחים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=373) ## [תבלינים וירקות](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=372) ## [פורחים לבית](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=363) ## [פקעות וזרעים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=364) ## [נשפכים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=378) ## [עצים ושיחים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=379) ## [מטפסים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=380)   
*   [כלי שתילה](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=3)## [קרמיקה וחרס](https://yifrach.co.il/store-products.aspx?StoreCategoryId=3&StoreSubCategoryId=330) ## [בטון](https://yifrach.co.il/store-products.aspx?StoreCategoryId=3&StoreSubCategoryId=366) ## [פלסטיק](https://yifrach.co.il/store-products.aspx?StoreCategoryId=3&StoreSubCategoryId=332) ## [דמוי בטון](https://yifrach.co.il/store-products.aspx?StoreCategoryId=3&StoreSubCategoryId=333) ## [קוקוס קש ומקרמה](https://yifrach.co.il/store-products.aspx?StoreCategoryId=3&StoreSubCategoryId=368)   
*   [דישון הדברה ואביזרים](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=14)## [דישון](https://yifrach.co.il/store-products.aspx?StoreCategoryId=14&StoreSubCategoryId=356) ## [הדברה](https://yifrach.co.il/store-products.aspx?StoreCategoryId=14&StoreSubCategoryId=357) ## [אביזרים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=14&StoreSubCategoryId=369)   
*   [תערובת שתילה ותוספים](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=15)## [תערובת שתילה](https://yifrach.co.il/store-products.aspx?StoreCategoryId=15&StoreSubCategoryId=358) ## [תוספים](https://yifrach.co.il/store-products.aspx?StoreCategoryId=15&StoreSubCategoryId=370)   
*   [מארזים ומתנות](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=13)## [מתנות שכייף לקבל ולתת](https://yifrach.co.il/store-products.aspx?StoreCategoryId=13&StoreSubCategoryId=374)   

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)

[המשך קניה](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)[לסל הקניות](https://yifrach.co.il/cart.aspx)

לכל צמח מחכה בית אוהב

נשמח להתאים בניכם

‏ 

מכאן תוכלו להזמין צמחים,

 עציצים, אדמה, חומרי הדברה ודישון

‏ 

חדש!

אנחנו בוחרים באופן אישי

 את הצמחים הכי רעננים

‏ 

![Image 11](https://yifrach.co.il/images/generalSlideshow_image1_id104_rnderfg.jpg?1788792446397)

[](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

ברוכים הבאים למשתלה

 הכי אופטימית בישראל

‏ 

[](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

[](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

[](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

*   0
*   1
*   2
*   3

לכל צמח מחכה בית אוהב

נשמח להתאים בניכם

‏ 

מכאן תוכלו להזמין צמחים,

 עציצים, אדמה, חומרי הדברה ודישון

‏ 

חדש!

אנחנו בוחרים באופן אישי

 את הצמחים הכי רעננים

‏ 

![Image 12](https://yifrach.co.il/images/generalSlideshow_image2_id104_rndvnan.jpg?1788792446402)

[](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

ברוכים הבאים למשתלה

 הכי אופטימית בישראל

‏ 

[](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

[](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

[](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

*   0
*   1
*   2
*   3

קלתיאה טריו סטאר צמח יפיפייה בעל שלושה צבעים בשילוב יוצא דופן.

![Image 13](https://yifrach.co.il/images/banners_categories_items_image1_id101_rndslgn.jpg?1788792446406)

[](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1690&StoreSubCategoryId=374)

מארז צמחים חזקים במיוחד למתחילים חמישיית צמחים בטוחה להצלחה

[](https://www.yifrach.co.il/product-id.aspx?StoreProductId=120&storeSubCategoryId=339)

*   0
*   1

[כל בית צריך צמחי בית](https://www.yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=339)

הצמחים המומלצים שלנו

[לעוד צמחים שווים](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

[![Image 14](https://yifrach.co.il/images/storeCategories_image1_id5_rnd0DW2.jpg)צמחים](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=5)[![Image 15](https://yifrach.co.il/images/storeCategories_image1_id3_rnduSsq.jpg)כלי שתילה](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=3)[![Image 16](https://yifrach.co.il/images/storeCategories_image1_id14_rnd7Mxa.jpg)דישון הדברה ואביזרים](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=14)[![Image 17](https://yifrach.co.il/images/storeCategories_image1_id15_rndcTG4.jpg)תערובת שתילה ותוספים](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=15)[![Image 18](https://yifrach.co.il/images/storeCategories_image1_id13_rndLan4.jpg)מארזים ומתנות](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=13)

טעימה מהעציצים שלנו 

[לכל כלי השתילה](https://yifrach.co.il/store-categories.aspx?StoreCategoryId=3)

![Image 19](https://yifrach.co.il/images/System/header_sep.png)דף הבית מתחת למומלצים![Image 20](https://yifrach.co.il/images/System/header_sep.png)

[![Image 21](https://yifrach.co.il/images/banners_categories_items_image1_id83_rnd2ETy.jpg)עסקים צומחים איתנו בואו להכיר את כל הדרכים לצמוח לרעיונות לחצו כאן](https://www.yifrach.co.il/pid.aspx?P_pageId=10&P_catId=1)[![Image 22](https://yifrach.co.il/images/banners_categories_items_image1_id71_rndIh4G.jpg)מתי אלמד לגדל נכון?עצות ותמיכה בעציצים שמתקשים לפרוח התיעצו איתנו כאן](https://www.yifrach.co.il/contact.aspx)

מעניינים

הבלוג המלא של יפרח

[01-12-2024 ### 3 מקומות סודיים ברובע הנגרים חדש!](https://yifrach.co.il/blog-post-id.aspx?BlogPostId=157)

הכי פופולריים שלנו

[לכל הממלצות שלנו](https://yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=339)

עדה

 יפרח, משתלה אופטימית, כשמה כן היא! הצמחים יפהפיים ובאיכות גבוהה! והיחס - אין לי מילים, עדי עזר לי בסבלנות, אהבה ואכפתיות אמיתית! עכשיו, שמצאתי אותם, זו המשתלה אליה אחזור תמיד! 

עדי גלבוע

 שירות משלוחים מעולה! ביצעתי הזמנה דרך האתר ואחד השתילים שהזמנתי היה חסר אז התקשרו לעדכן אותי בעיכוב ויום אחרי המשלוח כבר הגיע, כל השתילים במצב מעולה ופינקו עם אקסטרה אדמת שתילה :) בטוח אזמין שוב! 

דנה ווינטר

 משתלה מהממת במיקום עוד יותר מהמם! מבחר גדול מאוד של עציצים וכל מה שצריך לגינה. קיבלתי יחס אדיב מאוד מהבעלים והרבה עזרה, מקצועי וכיפי. 

טובי רמות

 בא לי ללקט צמחים קצת אחרת ..און ליין לשם שינו , ענה לי עדי מיפרח משתלה אורבנית אופטימית .תיתקנו הזמנה עם הסבר והכוונה ,יום שישי ב15.00, ב17.00 הבחור החתיך הזה( לא קשור אבל מה זה משנה🙂) עמד אל מול הדלת עם כל מה שהזמנתי ויותר! אין דברים כאלה!! תודה על שירות מדהים !! 

שרון אריאל

 חפשתי לקנות מהיום למחר שתילים לבית, הגעתי במקרה למשתלה יפרח באינטרנט ואני מאושרת שמצאתי אותכם :-) תודה רבה על השירות האדיב והמהיר, הטיפול והצמחים המקסימים שקבלתי 

מאיה ידין

 משתלה מהממת מהממת בפלורנטין, עם צמחים ממש מיוחדים, ועדי המהמם שעזר עם בחירה מדויקת של עציצים לבית, וכלים מתאימים, משלוח מהיר וזמין תמיד להתייעצות לגבי הטיפול בעציצים בהמשך והרגעה שעדיין לא הרגתי אותם והם גדלים יפה :) 

עפרה שני

 אין מילים להביע את הערכתי בכל פרמטר אפשרי! הזמנתי בונסאי זית.קיבלתי הסבר מדויק והמלצות שהוכחו כנכונות.השתיל והעציץ היגיעו בדיוק בזמן לשביעות רצוננו המלאה.היחס והשירות מעולים! מומלץ בחום ויותר.והמחירים מעולים! תודה רבה לכם ולעדי. 

שרה פלאש

 זה כבר המקום הקבוע שלנו בעבודה בשביל מתנות יומולדת לחברי צוות. אחלה צמחים באחלה מחירים, והצמחים באמת נראים כמו בתמונות באתר. עדי הלך מעל ומעבר כדי להתאים לי את ההזמנה לבול מה שרציתי- איזה שירות מעולה! אקנה עוד הרבה מכם :) 

אביבה סינואני

 חווית קנייה מאוד נעימה עם שירות יוצא דופן וברמה גבוהה מעל המצופה, היה לי חסר 2 פריטים בהזמנה והקפיצו לי באופן מיוחד, כמו כן קבלתי ללא תמורה צמח סינגוניום, עקב אי הבנה בזמן ההזמנה, לסיכום יחס אדיב שירות מהיר וזריז, מאוד ממליצה לרכוש ממשתלה זו כי אין ספק שאמשיך להיות לקוחה שלהם. 

אילן אדרי

 עציצים זו התמכרות וכולנו בחיפוש מתמיד אחרי המשתלה הכי טובה בעיר,אז אתם יכולים לעצור, כי מצאתם אותה.המשתלה של עדי קטנה ונסתרת, מלאה בסחורה וצמחים מדהימים, איכותיים, מיוחדים ויחודיים, השירות סבלני, אדיב, מלמד, מסביר ותמיד בא לקראת העציץ שהלקוח הכי יהנה ויפיק ממנו.המחיר זול והוגן, המשלוח בחינם(!) ואם יהיה לכם מזל - עדי יהיה גם זה שיביא לכם את הילדים החדשים הביתה.בקיצור, זו המשתלה החדשה שלכם בעיר, תתחדשו

adiya imri Orr

שירות מעולה, עציצים במצב מצוין. תמיד הלכתי למשתלות ועקב עומס מתמשך החלטתי בחשש מסוים להזמין. זו פעם ראשונה שאני מזמינה צמחים במשלוח ויצאתי סופר מרוצה. עדי יצר קשר לברר אם הצמח שהזמנתי אכן מתאים לתנאים, גילינו שאפשר לדייק את ההזמנה יותר, הוא שלח לי למחרת בבוקר מה הגיע, בחרתי ואפילו פינק בדשן שרציתי להוסיף מבלי לחייב אותי על ההפרש. מאחר שהצמחים הגיעו כשהייתי בעבודה הוא בירר איתי פעמיים - כשהגיעו ובערב כשחזרתי הביתה שהכל לשביעות רצוני. ואני כאמור סופר שבעת רצון. עשר מעשר, תודה!

הגר אייל

וואווו משתלה מדהימה! הגעתי אחרי שקראתי את החוות דעת פה ובאמת, התגשמות החלומות של כל חובב צמחים :) הצמחים בחנות מהממים ביופיים, בריאים ושמחים. השירות של עדי מכל הלב והכי חשוב מקצועי מאוד. הוא אפילו הסכים להגיע אלינו הביתה ולעזור לנו בבחירת הצמחים. מאז כבר חזרנו כמה פעמים וממשיכים להגיע קבוע. התמכרות מובטחת! איזה כיף שיש משתלב כזאת בעיר.

תומר שוורץ

שירות מדהים!ביצעתי הזמנה טלפונית - היו ממש סבלניים ועזרו בהרכבת עציץ עד שיצא טוב, גם עזרו להוציא את זה למשלוח בהפתעה (למרות הקשיים שהיו, הם לא וויתרו), וכל זה באחלה מחיר. מומלץ בחום.

צור לוין

למרות שאני חשדנית הזמנתי בהמלצת חבר צמחים ממשתלת יפרח, הצמחים הגיעו יום למחרת! עדי היה חמוד וסבלני- צילם לי את הצמחים לראות שאני מרוצה והגדיל להתקשר יום אחרי לבדוק שהכל הגיע בסדר. בקיצור עופו לקנות! 

אנסטסיה בן דוד

הזמנתי קקטוסים במשלוח וכולם הגיעו במצב מעולה, יפים מאוד ואפילו שדרגו לנו לגודל גדול יותר בחינם!! שירות מעולה, גם עונים מהר מאוד בווטסאפ לבירורים. ממליצה בחום!

הדר סטפני

משתלה חדשה בת"א עם צוות מקסים. הזמנתי מהאינטרנט ונעזרתי בהם בוואטסאפ לבירור על צמח ושמחו לבדוק עבורי.שירות סופר מהיר - הגיע תוך מספר שעות מרגע ההזמנה מה שהפתיע אותי ממש.הפתעה טובה שנייה הייתה שאפילו הביאו לי צמחים גדולים יותר ממה שהזמנתי וגם אמרו שלכל שאלה על הצמחים הם זמינים.ממליצה :)

ענבר כהן לרנר

משתלה מתוקה ומקסימה בדרום תל אביב. חיפשתי את הטרריום המושלם והגעתי לאתר של משתלת יפרח. קיבלתי מענה מהיר ונעים וכבר באותו יום המשלוח היה מוכן והגיע אלי למחרת.

עדי המקסים זמין לכל שאלה ואני סופר סופר מרוצה 🌞 ואכן הטרריום מושלם.חוץ מזה המשתלה מהממת ויש בה הכל! מגוון עציצים מעלפים והמון סוגי צמחים. מומלץ מאוד!

עדה

 יפרח, משתלה אופטימית, כשמה כן היא! הצמחים יפהפיים ובאיכות גבוהה! והיחס - אין לי מילים, עדי עזר לי בסבלנות, אהבה ואכפתיות אמיתית! עכשיו, שמצאתי אותם, זו המשתלה אליה אחזור תמיד! 

עדי גלבוע

 שירות משלוחים מעולה! ביצעתי הזמנה דרך האתר ואחד השתילים שהזמנתי היה חסר אז התקשרו לעדכן אותי בעיכוב ויום אחרי המשלוח כבר הגיע, כל השתילים במצב מעולה ופינקו עם אקסטרה אדמת שתילה :) בטוח אזמין שוב! 

דנה ווינטר

 משתלה מהממת במיקום עוד יותר מהמם! מבחר גדול מאוד של עציצים וכל מה שצריך לגינה. קיבלתי יחס אדיב מאוד מהבעלים והרבה עזרה, מקצועי וכיפי. 

טובי רמות

 בא לי ללקט צמחים קצת אחרת ..און ליין לשם שינו , ענה לי עדי מיפרח משתלה אורבנית אופטימית .תיתקנו הזמנה עם הסבר והכוונה ,יום שישי ב15.00, ב17.00 הבחור החתיך הזה( לא קשור אבל מה זה משנה🙂) עמד אל מול הדלת עם כל מה שהזמנתי ויותר! אין דברים כאלה!! תודה על שירות מדהים !! 

שרון אריאל

 חפשתי לקנות מהיום למחר שתילים לבית, הגעתי במקרה למשתלה יפרח באינטרנט ואני מאושרת שמצאתי אותכם :-) תודה רבה על השירות האדיב והמהיר, הטיפול והצמחים המקסימים שקבלתי 

מאיה ידין

 משתלה מהממת מהממת בפלורנטין, עם צמחים ממש מיוחדים, ועדי המהמם שעזר עם בחירה מדויקת של עציצים לבית, וכלים מתאימים, משלוח מהיר וזמין תמיד להתייעצות לגבי הטיפול בעציצים בהמשך והרגעה שעדיין לא הרגתי אותם והם גדלים יפה :) 

עפרה שני

 אין מילים להביע את הערכתי בכל פרמטר אפשרי! הזמנתי בונסאי זית.קיבלתי הסבר מדויק והמלצות שהוכחו כנכונות.השתיל והעציץ היגיעו בדיוק בזמן לשביעות רצוננו המלאה.היחס והשירות מעולים! מומלץ בחום ויותר.והמחירים מעולים! תודה רבה לכם ולעדי. 

שרה פלאש

 זה כבר המקום הקבוע שלנו בעבודה בשביל מתנות יומולדת לחברי צוות. אחלה צמחים באחלה מחירים, והצמחים באמת נראים כמו בתמונות באתר. עדי הלך מעל ומעבר כדי להתאים לי את ההזמנה לבול מה שרציתי- איזה שירות מעולה! אקנה עוד הרבה מכם :) 

אביבה סינואני

 חווית קנייה מאוד נעימה עם שירות יוצא דופן וברמה גבוהה מעל המצופה, היה לי חסר 2 פריטים בהזמנה והקפיצו לי באופן מיוחד, כמו כן קבלתי ללא תמורה צמח סינגוניום, עקב אי הבנה בזמן ההזמנה, לסיכום יחס אדיב שירות מהיר וזריז, מאוד ממליצה לרכוש ממשתלה זו כי אין ספק שאמשיך להיות לקוחה שלהם. 

אילן אדרי

 עציצים זו התמכרות וכולנו בחיפוש מתמיד אחרי המשתלה הכי טובה בעיר,אז אתם יכולים לעצור, כי מצאתם אותה.המשתלה של עדי קטנה ונסתרת, מלאה בסחורה וצמחים מדהימים, איכותיים, מיוחדים ויחודיים, השירות סבלני, אדיב, מלמד, מסביר ותמיד בא לקראת העציץ שהלקוח הכי יהנה ויפיק ממנו.המחיר זול והוגן, המשלוח בחינם(!) ואם יהיה לכם מזל - עדי יהיה גם זה שיביא לכם את הילדים החדשים הביתה.בקיצור, זו המשתלה החדשה שלכם בעיר, תתחדשו

adiya imri Orr

שירות מעולה, עציצים במצב מצוין. תמיד הלכתי למשתלות ועקב עומס מתמשך החלטתי בחשש מסוים להזמין. זו פעם ראשונה שאני מזמינה צמחים במשלוח ויצאתי סופר מרוצה. עדי יצר קשר לברר אם הצמח שהזמנתי אכן מתאים לתנאים, גילינו שאפשר לדייק את ההזמנה יותר, הוא שלח לי למחרת בבוקר מה הגיע, בחרתי ואפילו פינק בדשן שרציתי להוסיף מבלי לחייב אותי על ההפרש. מאחר שהצמחים הגיעו כשהייתי בעבודה הוא בירר איתי פעמיים - כשהגיעו ובערב כשחזרתי הביתה שהכל לשביעות רצוני. ואני כאמור סופר שבעת רצון. עשר מעשר, תודה!

הגר אייל

וואווו משתלה מדהימה! הגעתי אחרי שקראתי את החוות דעת פה ובאמת, התגשמות החלומות של כל חובב צמחים :) הצמחים בחנות מהממים ביופיים, בריאים ושמחים. השירות של עדי מכל הלב והכי חשוב מקצועי מאוד. הוא אפילו הסכים להגיע אלינו הביתה ולעזור לנו בבחירת הצמחים. מאז כבר חזרנו כמה פעמים וממשיכים להגיע קבוע. התמכרות מובטחת! איזה כיף שיש משתלב כזאת בעיר.

תומר שוורץ

שירות מדהים!ביצעתי הזמנה טלפונית - היו ממש סבלניים ועזרו בהרכבת עציץ עד שיצא טוב, גם עזרו להוציא את זה למשלוח בהפתעה (למרות הקשיים שהיו, הם לא וויתרו), וכל זה באחלה מחיר. מומלץ בחום.

צור לוין

למרות שאני חשדנית הזמנתי בהמלצת חבר צמחים ממשתלת יפרח, הצמחים הגיעו יום למחרת! עדי היה חמוד וסבלני- צילם לי את הצמחים לראות שאני מרוצה והגדיל להתקשר יום אחרי לבדוק שהכל הגיע בסדר. בקיצור עופו לקנות! 

אנסטסיה בן דוד

הזמנתי קקטוסים במשלוח וכולם הגיעו במצב מעולה, יפים מאוד ואפילו שדרגו לנו לגודל גדול יותר בחינם!! שירות מעולה, גם עונים מהר מאוד בווטסאפ לבירורים. ממליצה בחום!

הדר סטפני

משתלה חדשה בת"א עם צוות מקסים. הזמנתי מהאינטרנט ונעזרתי בהם בוואטסאפ לבירור על צמח ושמחו לבדוק עבורי.שירות סופר מהיר - הגיע תוך מספר שעות מרגע ההזמנה מה שהפתיע אותי ממש.הפתעה טובה שנייה הייתה שאפילו הביאו לי צמחים גדולים יותר ממה שהזמנתי וגם אמרו שלכל שאלה על הצמחים הם זמינים.ממליצה :)

ענבר כהן לרנר

משתלה מתוקה ומקסימה בדרום תל אביב. חיפשתי את הטרריום המושלם והגעתי לאתר של משתלת יפרח. קיבלתי מענה מהיר ונעים וכבר באותו יום המשלוח היה מוכן והגיע אלי למחרת.

עדי המקסים זמין לכל שאלה ואני סופר סופר מרוצה 🌞 ואכן הטרריום מושלם.חוץ מזה המשתלה מהממת ויש בה הכל! מגוון עציצים מעלפים והמון סוגי צמחים. מומלץ מאוד!

עדה

 יפרח, משתלה אופטימית, כשמה כן היא! הצמחים יפהפיים ובאיכות גבוהה! והיחס - אין לי מילים, עדי עזר לי בסבלנות, אהבה ואכפתיות אמיתית! עכשיו, שמצאתי אותם, זו המשתלה אליה אחזור תמיד! 

‹›

[לכל ההמלצות](https://www.google.com/search?gs_ssp=eJwBTQCy_woNL2cvMTFydmN2eHFzbjABOiUweDE1MWQ0ZGFiYjA5NmM4ZWQ6MHgzNzc2NWY2ZGY1YWEzY2RjShPXmdek16jXlyDXntep16rXnNeUqiseDg&q=%D7%99%D7%A4%D7%A8%D7%97+%D7%9E%D7%A9%D7%AA%D7%9C%D7%94&oq=%D7%99%D7%A4%D7%A8%D7%97&aqs=chrome.1.69i57j46i39i175i199j46i175i199i512j0i512l3j46i175i199i512j0i512j46i175i199i512l2.2100j0j15&sourceid=chrome&ie=UTF-8#lrd=0x151d4dabb096c8ed:0x37765f6df5aa3cdc,1,,,)

# יפרח משתלה בתל אביב

## משתלה בתל אביב שיש בה הכל, מכאן תוכלו להזמין משלוחי צמחים כלים, אדמה דשנים ומתנות עד הבית. או שפשוט תקפצו להגיד שלום, בכל מקרה כדאי לכם להיות חברי מועדון ולקבל מבצעים והטבות לפני כולם.

[הרשמה לאתר](https://yifrach.co.il/Registration.aspx)

- [x] 

 מאשר/ת קבלת דיוור בהתאם למדיניות הפרטיות 

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)

![Image 23](https://yifrach.co.il/GenerateCaptcha.ashx)

![Image 24](https://yifrach.co.il/images/System/loading-page.gif)

![Image 25](https://yifrach.co.il/images/System/toy.png)

[![Image 26](https://yifrach.co.il/images/web_links_items_image1_id1_rndlGnx.jpg) ### איזורי חלוקה תל אביב, ערי המרכז והשרון](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)[![Image 27](https://yifrach.co.il/images/web_links_items_image1_id2_rndYiwy.jpg) ### מוקד הצמחים צריכים תמיכה או יעוץ בנוגע לצמחים שלכם? אנחנו זמינים- 03-7320173](https://www.yifrach.co.il/contact.aspx)[![Image 28](https://yifrach.co.il/images/web_links_items_image1_id3_rnd2F8R.jpg) ### רכישה בטוחה האתר מאובטח לרכישה און ליין בתקני אבטחה מחמירים](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)[![Image 29](https://yifrach.co.il/images/web_links_items_image1_id4_rndd8xk.jpg) ### המשתלה שלנו בואו לבקר אותנו, צריפין 35 תל אביב](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)

יפרח - משתלה אופטימית

משתלה בפלורנטין שיש בה צמחי בית וחוץ, תערובות שתילה, תבלינים, כלי שתילה מסודים שונים, דשנים והדברה ועוד- כדי שתוכלו לחיות ולעבוד בסביבה ירוקה!

שעות פתיחה

[![Image 30](https://yifrach.co.il/images/footer_website_image2_rndD7FM.png)](https://yifrach.co.il/Registration.aspx)

ראשון עד חמישי: 10:00-18:00

 שישי: 16:00- 9:00

 מקבלים הזמנות באתר בוואצאפ ובטלפון

רכישה מאובטחת

![Image 31](https://yifrach.co.il/images/web_links_items_image1_id53_rndVeof.png)

![Image 32](https://yifrach.co.il/images/web_links_items_image1_16_rnd_1570.png)

![Image 33](https://yifrach.co.il/images/web_links_items_image1_17_rnd_6026.png)

האתר מאובטח לרכישה באמצעות טכנולוגיית ssl מהמובילות בעולם. הסליקה מתבצעת עם חברת טרנזילה ועומדת בתקן - pci

זמינים לשירותכם

[מייל: YifrachTlv@gmail.com](mailto:info@fusion-shop.co.il)[טלפון: 03-7320173](tel:03-7320173)[כתובת: צריפין 35, תל אביב](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)[ווצאפ: 0549380028](https://api.whatsapp.com/send?phone=9720549380028)

איך מגיעים

מידע נוסף

[הצהרת נגישות](https://yifrach.co.il/pid.aspx?P_pageId=8&P_catId=0)[תקנון ומדיניות אתר](https://www.yifrach.co.il/pid.aspx?P_pageId=6&P_catId=1)

תשארו מחוברים

[](https://www.instagram.com/yifrach_/)[](https://www.facebook.com/%D7%99%D7%A4%D7%A8%D7%97-%D7%9E%D7%A9%D7%AA%D7%9C%D7%94-%D7%90%D7%95%D7%A4%D7%98%D7%99%D7%9E%D7%99%D7%AA-108111661749862)[](https://wa.me/9720549380028)

כל הזכויות שמורות © ל- יפרח משתלה אופטימית 2022

[![Image 34: פיוז'ן סטודיו](https://yifrach.co.il/images/System/icon-good-small-white.png)](https://very-good.co.il/)

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#x)

התחברות לאתר

[שכחתם סיסמה?](https://yifrach.co.il/password_Recovery.aspx)

- [x] 

השאירו אותי מחובר

עדיין לא מחוברים?[צרו חשבון חדש](https://yifrach.co.il/Registration.aspx)

[המשך כאורח](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)

![Image 35](https://yifrach.co.il/images/System/loading-page.gif)

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#close)

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#popup_wishlistAlert)

רוצים להוסיף את המוצר למועדפים? היכנסו לחשבונכם או הרשמו לאתר ותהנו מהטבות ומבצעים כל השנה, נשמח לראותכם :)

[התחברו/הרשמו](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#customer_login)

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#close)

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)

[![Image 36](https://yifrach.co.il/images/popup_jumping_image1_rndx1JZ.jpg)](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#a)

[](javascript:closePopup())

[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#popup_add_to_cart)

[![Image 37](https://yifrach.co.il/images/System/popup_addToCart.jpg)](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)[](https://yifrach.co.il/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#close)

![Image 38: נגישות](https://yifrach.co.il/Moduls/accessibility/icons/accesibility.svg)

×

### נגישות

[הצהרת נגישות](https://yifrach.co.il/pid.aspx?P_pageId=8&P_catId=1)![Image 39: בטל נגישות](https://yifrach.co.il/Moduls/accessibility/icons/cancel.svg) בטל נגישות

![Image 40: הגדלת טקסט](https://yifrach.co.il/Moduls/accessibility/icons/bigText.svg) הגדלת טקסט![Image 41](https://yifrach.co.il/Moduls/accessibility/icons/spaceLines.svg) מרווח שורות![Image 42](https://yifrach.co.il/Moduls/accessibility/icons/TextAlignment.svg) יישור טקסט![Image 43](https://yifrach.co.il/Moduls/accessibility/icons/legibleFont.svg) גופן קריא![Image 44](https://yifrach.co.il/Moduls/accessibility/icons/greyColors.svg) גווני אפור![Image 45](https://yifrach.co.il/Moduls/accessibility/icons/contrastIcon.svg) ניגודיות![Image 46](https://yifrach.co.il/Moduls/accessibility/icons/image.svg) הסתר תמונות![Image 47](https://yifrach.co.il/Moduls/accessibility/icons/underline.svg) הדגשת קישורים

התאמת צבעים 

גודל גופן קטן בינוני גדול ענק

![Image 48](https://yifrach.co.il/Moduls/accessibility/icons/blockFlickering.svg) חסום הבהובים![Image 49](https://yifrach.co.il/Moduls/accessibility/icons/mute.svg) השתקת אודיו![Image 50](https://yifrach.co.il/Moduls/accessibility/icons/enlarge.svg) הגדלת כותרות![Image 51](https://yifrach.co.il/Moduls/accessibility/icons/keyboard.svg) מקלדת וירטואלית