[דילוג לתוכן](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#MainContent)

## העגלה שלך ריקה

 המשיכו לקנות 
יש לכם משתמש?

[התחברו](https://shopify.com/91747975468/account?locale=he-IL&buyer_flags=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiI5amQzanAtZWQubXlzaG9waWZ5LmNvbSIsImZsYWdzIjpbXSwiZXhwIjoxNzg5Mzk2ODM3LCJuYmYiOjE3ODg3OTIwMzd9.fYiZ_R6-XND64MP8N-7PlU5t5lNHITkldANJPkeZ6Y8&region_country=IL) כדי לשלם מהר יותר.

העגלה שלי

טוען...

 הערות מיוחדות להזמנה הערות מיוחדות להזמנה 

## סכום משוער

0.00 ₪

[המשך לתשלום](https://decogarden.co.il/cart)

הצמחים היפים ביותר מהמשתלה ישירות אליכם הביתה!

מבצעים ומחירים שווים!

משלוחים עד הבית

*   [כל הקטגוריות](https://decogarden.co.il/collections)
*   
 צמחים 

 צמחים 
    *   [כל הצמחים](https://decogarden.co.il/collections/%D7%94%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A9%D7%9C%D7%A0%D7%95)
    *   
 צמחים לבית 

 צמחים לבית 
        *   [צמחים שקשה להרוג](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%97%D7%96%D7%A7%D7%99%D7%9D-1)
        *   [צמחים נתלים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%AA%D7%9C%D7%99%D7%9D)
        *   [צמחים פורחים לבית](https://decogarden.co.il/collections/%D7%A4%D7%95%D7%A8%D7%97%D7%99%D7%9D-%D7%A2%D7%9D-%D7%A6%D7%91%D7%A2)
        *   [לאקי במבוק](https://decogarden.co.il/collections/%D7%9C%D7%90%D7%A7%D7%99-%D7%91%D7%9E%D7%91%D7%95%D7%A7)

    *   
 צמחים לגינה 

 צמחים לגינה 
        *   [צמחים מטפסים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9E%D7%98%D7%A4%D7%A1%D7%99%D7%9D)
        *   [צמחי תבלין](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99-%D7%AA%D7%91%D7%9C%D7%99%D7%9F)
        *   [פורחים](https://decogarden.co.il/collections/%D7%A4%D7%95%D7%A8%D7%97%D7%99%D7%9D)
        *   [צמחים נשפכים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%A9%D7%A4%D7%9B%D7%99%D7%9D)
        *   [עצי פרי](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99-%D7%A4%D7%A8%D7%99)
        *   [שיחים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A9%D7%99%D7%97%D7%99%D7%99%D7%9D)
        *   [עונתיים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%95%D7%A0%D7%AA%D7%99%D7%99%D7%9D)

    *   
 זרעים 

 זרעים 
        *   [גינת ירק](https://decogarden.co.il/collections/%D7%92%D7%99%D7%A0%D7%AA-%D7%99%D7%A8%D7%A7)
        *   [זרעי פרחים](https://decogarden.co.il/collections/%D7%96%D7%A8%D7%A2%D7%99-%D7%A4%D7%A8%D7%97%D7%99%D7%9D)

    *   [צמחים טרופיים\נדירים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%98%D7%A8%D7%95%D7%A4%D7%99%D7%99%D7%9D)
    *   [צמחים אקזוטיים ונדירים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%96%D7%95%D7%98%D7%99%D7%99%D7%9D-%D7%95%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D)
    *   [סוקולנטים וקקטוסים](https://decogarden.co.il/collections/%D7%A1%D7%95%D7%A7%D7%95%D7%9C%D7%A0%D7%98%D7%99%D7%9D-%D7%95%D7%A7%D7%A7%D7%98%D7%95%D7%A1%D7%99%D7%9D)

*   
 עציצים לאירוע מארזים ומתנות 

 עציצים לאירוע מארזים ומתנות 
    *   [עציצים עטופים](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99%D7%9D%D7%9C%D7%90%D7%99%D7%A8%D7%95%D7%A2)
    *   [מארזים ומתנות](https://decogarden.co.il/collections/%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%9E%D7%95%D7%9B%D7%A0%D7%95%D7%AA)

*   
 כדים ואדניות 

 כדים ואדניות 
    *   [עציצי פלסטיק](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99-%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%96%D7%95%D7%9C%D7%99%D7%9D)
    *   [כדים מקרמיקה לשולחן](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%9E%D7%A7%D7%A8%D7%9E%D7%99%D7%A7%D7%94-%D7%A2%D7%91%D7%95%D7%93%D7%AA-%D7%99%D7%93)
    *   [כדים גדולים](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%92%D7%93%D7%95%D7%9C%D7%99%D7%9D)
    *   [כדים מפלסטיק ברזילאי](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%9E%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%91%D7%A8%D7%96%D7%99%D7%9C%D7%90%D7%99)
    *   [אדניות גדולות](https://decogarden.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA-%D7%92%D7%93%D7%95%D7%9C%D7%95%D7%AA)
    *   [אדניות מפלסטיק צרפתי](https://decogarden.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA-%D7%9E%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%A6%D7%A8%D7%A4%D7%AA%D7%99)

*   
 אדמה ומצעי שתילה 

 אדמה ומצעי שתילה 
    *   [שקים ואריזות](https://decogarden.co.il/collections/%D7%A9%D7%A7%D7%99%D7%9D)
    *   [בלות בכמויות גדולות](https://decogarden.co.il/collections/%D7%91%D7%9C%D7%95%D7%AA)

*   
 דשא סינטטי וגדרות במבוק 

 דשא סינטטי וגדרות במבוק 
    *   [דשא סינטטי](https://decogarden.co.il/collections/%D7%93%D7%A9%D7%90-%D7%A1%D7%99%D7%A0%D7%98%D7%98%D7%99)
    *   [גדרות במבוק](https://decogarden.co.il/collections/%D7%92%D7%93%D7%A8%D7%95%D7%AA)

*   
 מוצרי נוי ואביזרי גינון 

 מוצרי נוי ואביזרי גינון 
    *   [מוצרי נוי](https://decogarden.co.il/collections/%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%A0%D7%95%D7%99-%D7%9C%D7%92%D7%99%D7%A0%D7%94)
    *   [אביזרי גינון](https://decogarden.co.il/collections/%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%92%D7%99%D7%A0%D7%95%D7%9F)
    *   [חלוקי נחל לגינה](https://decogarden.co.il/collections/%D7%97%D7%9C%D7%95%D7%A7%D7%99-%D7%A0%D7%97%D7%9C-%D7%9C%D7%92%D7%99%D7%A0%D7%94)

*   
 חומרי דישון והדברה 

 חומרי דישון והדברה 
    *   [חומרי דישון](https://decogarden.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%93%D7%99%D7%A9%D7%95%D7%9F)
    *   [חומרי הדברה](https://decogarden.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94)

*   [הקמת גינה](https://decogarden.co.il/pages/%D7%A2%D7%99%D7%A6%D7%95%D7%91-%D7%92%D7%99%D7%A0%D7%95%D7%AA-%D7%A2%D7%9D-%D7%92%D7%A0%D7%9F-%D7%9E%D7%A7%D7%A6%D7%95%D7%A2%D7%99-%D7%91%D7%9E%D7%97%D7%99%D7%A8-%D7%A9%D7%9C-%D7%9E%D7%A9%D7%AA%D7%9C%D7%94)
*   [מערכות השקיה אוטומטיות ללא צורך בחיבור לנקודת מים](https://decogarden.co.il/collections/%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%94%D7%A9%D7%A7%D7%99%D7%94-%D7%90%D7%95%D7%98%D7%95%D7%9E%D7%98%D7%99%D7%95%D7%AA)

[התחברות](https://shopify.com/91747975468/account?locale=he-IL&buyer_flags=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiI5amQzanAtZWQubXlzaG9waWZ5LmNvbSIsImZsYWdzIjpbXSwiZXhwIjoxNzg5Mzk2ODM3LCJuYmYiOjE3ODg3OTIwMzd9.fYiZ_R6-XND64MP8N-7PlU5t5lNHITkldANJPkeZ6Y8&region_country=IL)

## שפה

*   [עברית](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)
*   [English](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)
*   [Русский](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)

*   [Facebook](https://www.facebook.com/share/1CUQbcdhie/?mibextid=wwXIfr)
*   [Instagram](https://www.instagram.com/decogarden.co.il?igsh=MW12eXFidWh5em5tNQ==)
*   [TikTok](https://www.tiktok.com/@decogarden.co.il)

[![Image 1: Deco Garden logo with green and red text on a white background](https://decogarden.co.il/cdn/shop/files/2000_x_2000.png?v=1762899199&width=600) Deco garden](https://decogarden.co.il/)
*   [🏷️ כל הקטגוריות](https://decogarden.co.il/collections)
*   
🌿 צמחים

    *   [כל הצמחים](https://decogarden.co.il/collections/%D7%94%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A9%D7%9C%D7%A0%D7%95)
    *   [צמחים לבית](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9C%D7%91%D7%99%D7%AA)
        *   [צמחים שקשה להרוג](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%97%D7%96%D7%A7%D7%99%D7%9D-1)
        *   [צמחים נתלים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%AA%D7%9C%D7%99%D7%9D)
        *   [צמחים פורחים לבית](https://decogarden.co.il/collections/%D7%A4%D7%95%D7%A8%D7%97%D7%99%D7%9D-%D7%A2%D7%9D-%D7%A6%D7%91%D7%A2)
        *   [לאקי במבוק](https://decogarden.co.il/collections/%D7%9C%D7%90%D7%A7%D7%99-%D7%91%D7%9E%D7%91%D7%95%D7%A7)

    *   [צמחים לגינה](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9C%D7%92%D7%99%D7%A0%D7%94)
        *   [צמחים מטפסים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9E%D7%98%D7%A4%D7%A1%D7%99%D7%9D)
        *   [צמחי תבלין](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99-%D7%AA%D7%91%D7%9C%D7%99%D7%9F)
        *   [פורחים](https://decogarden.co.il/collections/%D7%A4%D7%95%D7%A8%D7%97%D7%99%D7%9D)
        *   [צמחים נשפכים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%A9%D7%A4%D7%9B%D7%99%D7%9D)
        *   [עצי פרי](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99-%D7%A4%D7%A8%D7%99)
        *   [שיחים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A9%D7%99%D7%97%D7%99%D7%99%D7%9D)
        *   [עונתיים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%95%D7%A0%D7%AA%D7%99%D7%99%D7%9D)

    *   [זרעים](https://decogarden.co.il/collections/%D7%96%D7%A8%D7%A2%D7%99%D7%9D)
        *   [גינת ירק](https://decogarden.co.il/collections/%D7%92%D7%99%D7%A0%D7%AA-%D7%99%D7%A8%D7%A7)
        *   [זרעי פרחים](https://decogarden.co.il/collections/%D7%96%D7%A8%D7%A2%D7%99-%D7%A4%D7%A8%D7%97%D7%99%D7%9D)

    *   [צמחים טרופיים\נדירים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%98%D7%A8%D7%95%D7%A4%D7%99%D7%99%D7%9D)
    *   [צמחים אקזוטיים ונדירים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%96%D7%95%D7%98%D7%99%D7%99%D7%9D-%D7%95%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D)
    *   [סוקולנטים וקקטוסים](https://decogarden.co.il/collections/%D7%A1%D7%95%D7%A7%D7%95%D7%9C%D7%A0%D7%98%D7%99%D7%9D-%D7%95%D7%A7%D7%A7%D7%98%D7%95%D7%A1%D7%99%D7%9D)

*   
🎁 עציצים לאירוע מארזים ומתנות

    *   [עציצים עטופים](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99%D7%9D%D7%9C%D7%90%D7%99%D7%A8%D7%95%D7%A2)
    *   [מארזים ומתנות](https://decogarden.co.il/collections/%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%9E%D7%95%D7%9B%D7%A0%D7%95%D7%AA)

*   
🪴 כדים ואדניות

    *   [עציצי פלסטיק](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99-%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%96%D7%95%D7%9C%D7%99%D7%9D)
    *   [כדים מקרמיקה לשולחן](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%9E%D7%A7%D7%A8%D7%9E%D7%99%D7%A7%D7%94-%D7%A2%D7%91%D7%95%D7%93%D7%AA-%D7%99%D7%93)
    *   [כדים גדולים](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%92%D7%93%D7%95%D7%9C%D7%99%D7%9D)
    *   [כדים מפלסטיק ברזילאי](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%9E%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%91%D7%A8%D7%96%D7%99%D7%9C%D7%90%D7%99)
    *   [אדניות גדולות](https://decogarden.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA-%D7%92%D7%93%D7%95%D7%9C%D7%95%D7%AA)
    *   [אדניות מפלסטיק צרפתי](https://decogarden.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA-%D7%9E%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%A6%D7%A8%D7%A4%D7%AA%D7%99)

*   
🌱 אדמה ומצעי שתילה

    *   [שקים ואריזות](https://decogarden.co.il/collections/%D7%A9%D7%A7%D7%99%D7%9D)
    *   [בלות בכמויות גדולות](https://decogarden.co.il/collections/%D7%91%D7%9C%D7%95%D7%AA)

*   
🌾 דשא סינטטי וגדרות במבוק

    *   [דשא סינטטי](https://decogarden.co.il/collections/%D7%93%D7%A9%D7%90-%D7%A1%D7%99%D7%A0%D7%98%D7%98%D7%99)
    *   [גדרות במבוק](https://decogarden.co.il/collections/%D7%92%D7%93%D7%A8%D7%95%D7%AA)

*   
✨ מוצרי נוי ואביזרי גינון

    *   [מוצרי נוי](https://decogarden.co.il/collections/%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%A0%D7%95%D7%99-%D7%9C%D7%92%D7%99%D7%A0%D7%94)
    *   [אביזרי גינון](https://decogarden.co.il/collections/%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%92%D7%99%D7%A0%D7%95%D7%9F)
    *   [חלוקי נחל לגינה](https://decogarden.co.il/collections/%D7%97%D7%9C%D7%95%D7%A7%D7%99-%D7%A0%D7%97%D7%9C-%D7%9C%D7%92%D7%99%D7%A0%D7%94)

*   
🧪 חומרי דישון והדברה

    *   [חומרי דישון](https://decogarden.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%93%D7%99%D7%A9%D7%95%D7%9F)
    *   [חומרי הדברה](https://decogarden.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94)

*   [🏡 הקמת גינה](https://decogarden.co.il/pages/%D7%A2%D7%99%D7%A6%D7%95%D7%91-%D7%92%D7%99%D7%A0%D7%95%D7%AA-%D7%A2%D7%9D-%D7%92%D7%A0%D7%9F-%D7%9E%D7%A7%D7%A6%D7%95%D7%A2%D7%99-%D7%91%D7%9E%D7%97%D7%99%D7%A8-%D7%A9%D7%9C-%D7%9E%D7%A9%D7%AA%D7%9C%D7%94)
*   [💧 מערכות השקיה אוטומטיות ללא צורך בחיבור לנקודת מים](https://decogarden.co.il/collections/%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%94%D7%A9%D7%A7%D7%99%D7%94-%D7%90%D7%95%D7%98%D7%95%D7%9E%D7%98%D7%99%D7%95%D7%AA)

## שפה

*   [עברית](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)
*   [English](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)
*   [Русский](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)

חיפוש[התחברות](https://decogarden.co.il/account)[עגלת קניות](https://decogarden.co.il/cart)

×

חפש מוצרים, קטגוריות...

### מוצרים קשורים

[ראה הכל](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)

### קטגוריות

[ראה הכל](https://decogarden.co.il/collections)

# תוצאות חיפוש

חיפוש 

## סינון:

מחיר

המחיר הגבוה ביותר הוא 55.00 ₪[איפוס](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1)

₪

מ 

₪

עד 

[הסר הכל](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&options%5Bprefix%5D=last&sort_by=relevance)

## מיון לפי:

## 4 תוצאות

סינון ומיון סינון 

## סינון ומיון

## סינון

4 תוצאות

מחיר

 מחיר 
המחיר הגבוה ביותר הוא 55.00 ₪

₪

מ 

₪

עד 

[ניקוי](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1) החל 

מיון לפי: 

[הסר הכל](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&options%5Bprefix%5D=last&sort_by=relevance) החל 

[הסר הכל](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&options%5Bprefix%5D=last&sort_by=relevance)

## 4 תוצאות

![Image 2](blob:http://localhost/c65e67a540d3852b679673b9993cc5ca)_טוען עוד צמחים 💚_

*   ![Image 3: פוטוס סקינדפסוס פיקטוס ברקע של משתלה](https://decogarden.co.il/cdn/shop/files/1b9d26e13d958e3602e079f15b2bf6ec.webp?v=1779021831&width=533)  ### [פוטוס תאילנדי - סקינדפסוס פיקטוס קוטר עציץ 12 ס"מ](https://decogarden.co.il/products/%D7%A4%D7%95%D7%98%D7%95%D7%A1-%D7%AA%D7%90%D7%99%D7%9C%D7%A0%D7%93%D7%99-%D7%A1%D7%A7%D7%99%D7%A0%D7%93%D7%A4%D7%A1%D7%95%D7%A1?_pos=1&_sid=53a51e4cb&_ss=r)    ### [פוטוס תאילנדי - סקינדפסוס פיקטוס קוטר עציץ 12 ס"מ](https://decogarden.co.il/products/%D7%A4%D7%95%D7%98%D7%95%D7%A1-%D7%AA%D7%90%D7%99%D7%9C%D7%A0%D7%93%D7%99-%D7%A1%D7%A7%D7%99%D7%A0%D7%93%D7%A4%D7%A1%D7%95%D7%A1?_pos=1&_sid=53a51e4cb&_ss=r)

מחיר רגיל 55.00 ₪  מחיר רגיל מחיר מבצע 55.00 ₪  מחיר יחידה/לכל          
*   ![Image 4: עציץ קרמיקה בגוון ורוד עתיק מט עם עיצוב פסים אנכיים ותחתית עגולה תואמת, קוטר 15 ס״מ — דקו גרדן](https://decogarden.co.il/cdn/shop/files/hf_20260710_225030_6a2b3731-3fcd-468e-8c8e-e2f482b57eaa.png?v=1783741386&width=533)  ### [עציץ קרמיקה ורוד פסים 15 ס״מ עם תחתית](https://decogarden.co.il/products/%D7%A2%D7%A6%D7%99%D7%A5-%D7%A7%D7%A8%D7%9E%D7%99%D7%A7%D7%94-%D7%95%D7%A8%D7%95%D7%93-%D7%A4%D7%A1%D7%99%D7%9D-15-%D7%A1-%D7%9E-%D7%A2%D7%9D-%D7%AA%D7%97%D7%AA%D7%99%D7%AA?_pos=2&_sid=53a51e4cb&_ss=r)    ### [עציץ קרמיקה ורוד פסים 15 ס״מ עם תחתית](https://decogarden.co.il/products/%D7%A2%D7%A6%D7%99%D7%A5-%D7%A7%D7%A8%D7%9E%D7%99%D7%A7%D7%94-%D7%95%D7%A8%D7%95%D7%93-%D7%A4%D7%A1%D7%99%D7%9D-15-%D7%A1-%D7%9E-%D7%A2%D7%9D-%D7%AA%D7%97%D7%AA%D7%99%D7%AA?_pos=2&_sid=53a51e4cb&_ss=r)

מחיר רגיל 45.00 ₪  מחיר רגיל מחיר מבצע 45.00 ₪  מחיר יחידה/לכל          
*   ![Image 5: עלי סקינדפסוס ירוקים עם הכתמה כסופה — מדריך טיפול | דקו גרדן](https://decogarden.co.il/cdn/shop/articles/scindapsus-hero.jpg?v=1784584956&width=533)  ### [🌿 סקינדפסוס פיקטוס (פותוס תאילנדי) | המדריך המל...](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%D7%A1%D7%A7%D7%99%D7%A0%D7%93%D7%A4%D7%A1%D7%95%D7%A1-%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%94%D7%9E%D7%9C%D7%90?_pos=3&_sid=53a51e4cb&_ss=r)

20 ביולי 2026  בלוג   ### [🌿 סקינדפסוס פיקטוס (פותוס תאילנדי) | המדריך המל...](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%D7%A1%D7%A7%D7%99%D7%A0%D7%93%D7%A4%D7%A1%D7%95%D7%A1-%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%94%D7%9E%D7%9C%D7%90?_pos=3&_sid=53a51e4cb&_ss=r)

20 ביולי 2026  בלוג    
*   ![Image 6: כדורי ליקה (LECA) שקופים עם צמחי בית בריאים בעציץ שקוף, גידול נקי בלי אדמה](https://decogarden.co.il/cdn/shop/articles/leca-hero-decogarden-2895526.png?v=1785398416&width=533)  ### [כדורי ליקה (LECA): המדריך המלא לגידול נקי בלי אדמה](https://decogarden.co.il/blogs/%D7%91%D7%9C%D7%95%D7%92/%D7%9B%D7%93%D7%95%D7%A8%D7%99-%D7%9C%D7%99%D7%A7%D7%94-%D7%9E%D7%93%D7%A8%D7%99%D7%9A?_pos=4&_sid=53a51e4cb&_ss=r)

29 ביולי 2026  בלוג   ### [כדורי ליקה (LECA): המדריך המלא לגידול נקי בלי אדמה](https://decogarden.co.il/blogs/%D7%91%D7%9C%D7%95%D7%92/%D7%9B%D7%93%D7%95%D7%A8%D7%99-%D7%9C%D7%99%D7%A7%D7%94-%D7%9E%D7%93%D7%A8%D7%99%D7%9A?_pos=4&_sid=53a51e4cb&_ss=r)

29 ביולי 2026  בלוג    
🚀

Load More

![Image 7](blob:http://localhost/c65e67a540d3852b679673b9993cc5ca)_טוען עוד צמחים 💚_

×
## 🎉 מגיעה לך מתנה!

תודה שקנית אצלנו

 לא תודה, אולי בפעם הבאה  הוסף מתנה לעגלה 

המתנה נוספה לעגלה! 🎁

🎁 יש לך מתנה!

יש לך מתנה חינם!

בחר עכשיו

## פרטי קשר

[050-529-8983](tel:0505298983)

[וואטסאפ — מענה מהיר](https://wa.me/972505298983)

[decogarden.co.il@gmail.com](mailto:decogarden.co.il@gmail.com)

שירות לקוחות: ימים א׳–ה׳ 10:00–17:00

רחוב יבנה פינת כנפי נשרים, הרצליה

הגעה למשתלה בתיאום מראש בלבד

## קטגוריות

*   [צמחים לבית](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9C%D7%91%D7%99%D7%AA)
*   [צמחים לגינה](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9C%D7%92%D7%99%D7%A0%D7%94)
*   [אדמה ומצעי שתילה](https://decogarden.co.il/collections/%D7%AA%D7%A2%D7%A8%D7%95%D7%91%D7%95%D7%AA-%D7%A9%D7%AA%D7%99%D7%9C%D7%94-%D7%95%D7%9E%D7%A6%D7%A2%D7%99-%D7%A9%D7%AA%D7%99%D7%9C%D7%94)
*   [אביזרי גינון](https://decogarden.co.il/collections/%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%92%D7%99%D7%A0%D7%95%D7%9F)
*   [מוצרי נוי לגינה](https://decogarden.co.il/collections/%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%A0%D7%95%D7%99-%D7%9C%D7%92%D7%99%D7%A0%D7%94)

## מידע ושירות

*   [חיפוש חופשי](https://decogarden.co.il/search)
*   [מדריכי טיפול בצמחים](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
*   [בלוג](https://decogarden.co.il/blogs/%D7%91%D7%9C%D7%95%D7%92)
*   [מדריכי צמחים](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
*   [צרו קשר](https://decogarden.co.il/pages/contact)
*   [מדיניות אספקת מוצרים](https://decogarden.co.il/policies/shipping-policy)
*   [מדיניות החזרים וביטולים](https://decogarden.co.il/policies/refund-policy)
*   [תקנון](https://decogarden.co.il/policies/terms-of-service)
*   [מדיניות פרטיות](https://decogarden.co.il/policies/privacy-policy)
*   [כל המוצרים](https://decogarden.co.il/collections/random)
*   [הצהרת נגישות](https://decogarden.co.il/pages/%D7%A0%D7%92%D7%99%D7%A9%D7%95%D7%AA)
*   [מועדון הנקודות](https://decogarden.co.il/pages/club)
*   [מנויים עונתיים לגינה](https://decogarden.co.il/pages/subscriptions)
*   [ביטול מנוי](https://decogarden.co.il/pages/subscriptions)

## מידע ומדיניות

*   [ביטול עסקה והחזרים](https://decogarden.co.il/policies/refund-policy)
*   [מדיניות משלוחים](https://decogarden.co.il/policies/shipping-policy)
*   [ביטול מנוי](https://decogarden.co.il/pages/subscriptions)
*   [תקנון האתר](https://decogarden.co.il/policies/terms-of-service)
*   [מדיניות פרטיות](https://decogarden.co.il/policies/privacy-policy)
*   [הצהרת נגישות](https://decogarden.co.il/pages/%D7%A0%D7%92%D7%99%D7%A9%D7%95%D7%AA)

## נרשמים ומקבלים ישר למייל קוד ל-10% הנחה על ההזמנה הראשונה 🎁

 כתובת מייל  

*   [Facebook](https://www.facebook.com/share/1CUQbcdhie/?mibextid=wwXIfr)
*   [Instagram](https://www.instagram.com/decogarden.co.il?igsh=MW12eXFidWh5em5tNQ==)
*   [TikTok](https://www.tiktok.com/@decogarden.co.il)

## דקו גרדן גם במקורות המועדפים של Google

עוד דרך פשוטה למצוא את המדריכים שלנו בזמן הנכון.

אמצעי תשלום

© 2026, [Deco garden](https://decogarden.co.il/)מופעל ע"י

*   בחירת תוצאות נבחרות בעמוד מלא חדש.
*   פותח בחלון חדש.

[](https://api.whatsapp.com/send?phone=972505298983&text=)

בדיקת זמינות משלוח

הכנס את שם העיר או הישוב שלך כדי לבדוק אם אנחנו מגיעים אליך

בדוק

מחפש את הכתובת...

מעולה! אנחנו מגיעים אליך

לביצוע הזמנה לכתובת שלך יש לפנות לשירות בטלפון או בווצאפ 0505298983 ניתן לאסוף מהמשתלה

לא הצלחנו למצוא את הכתובת, נסה שוב

✕

![Image 8: Product image](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1)

הוסף לסל 🛒[צפייה במוצר](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1)

✓ נוסף לסל הקניות!

💬

היי אני ארז 🌱 הגנן של דקו גרדן

אני כאן לענות על כל מה שתשאלו

✕

היי! 👋 אני ארז, הגנן של דקו גרדן. אני כאן לעזור לכם למצוא את הצמחים המושלמים לבית או לגינה, להרכיב חבילות בתקציב שלכם, ולעצב את הבית או הגינה שלכם, או סתם לענות על כל שאלה שקשורה לאתר או אלינו, שלחו לי תמונה של המקום ואמליץ אילו מוצרים מתאימים! 📸\n\nבמה נתחיל?

נסו לשאול

🌱 אילו צמחים מתאימים לי? (שאלון מהיר)💰 יש לי תקציב של ____ ש"ח🏡 תעזרו לי לעצב את הגינה/בית שלי🌿 אילו צמחים מתאימים לעונת הסתיו?

![Image 9: preview](https://decogarden.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1)

📸 תמונה מוכנה לשליחה

✕

📷↑

AI-powered assistant • Results may vary

אנו משתמשים בעוגיות (Cookies) לצורך שיפור חוויית הגלישה. המשך שימוש באתר מהווה הסכמה לשימוש בעוגיות ו[למדיניות הפרטיות](https://decogarden.co.il/policies/privacy-policy)