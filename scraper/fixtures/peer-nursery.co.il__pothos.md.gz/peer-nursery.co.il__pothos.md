[דילוג לתוכן](https://www.peer-nursery.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#content) [דלג לתוכן](https://www.peer-nursery.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#content)

החל מ500 ש"ח- משלוח חינם!

[₪00עגלת קניות](https://www.peer-nursery.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)

[050-533-9244](tel:0505339244)

[![](https://www.peer-nursery.co.il/wp-content/uploads/2023/05/peer-logo-300x169-1.png)](https://www.peer-nursery.co.il/)

לורם איפסום דולור סיט אמט, קונסקטורר אדיפיסינג אלית לפרומי בלוף קינץ תתיח לרעח. לת צשחמי צש בליא, מנסוטו צמלח לביקו ננבי, צמוקו בלוקריה.

[![](https://www.peer-nursery.co.il/wp-content/uploads/2023/05/peer-logo-300x169-1.png)](https://www.peer-nursery.co.il/)

[₪00עגלת קניות](https://www.peer-nursery.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)

[050-721-6856](https://www.peer-nursery.co.il/search?q=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)

404

אופס...

נראה שהדף שחיפשת לא נמצא.

ניתן לנווט חזרה לעמוד הבית בעזרת הכפתור:

[לעמוד הבית](https://www.peer-nursery.co.il/)

[![](https://www.peer-nursery.co.il/wp-content/uploads/2023/05/peer-logo-2-300x169-1.png)](https://www.peer-nursery.co.il/)

לעשות קניות במשתלה בלי לצאת מהבית

מפת אתר

קטגוריות

פרטי התקשרות

- [050-533-9244](tel:0505339244)

- [peerplant@gmail.com](mailto:peerplant@gmail.com)

- [שדרות מנחם בגין 112 הרצליה, \\
\\
מימין לתחנת הדלק סונול.](https://ul.waze.com/ul?preview_venue_id=22806850.228265106.130736&navigate=yes&utm_campaign=default&utm_source=waze_website&utm_medium=lm_share_location)

- 07:00-17:30 כל ימות השבוע

( שעון קיץ)

[Youtube](https://www.youtube.com/@peerplantnursery)

[Facebook-f](https://www.facebook.com/peerplants)

[Instagram](https://www.instagram.com/peer_nursery/)

[Tiktok](https://www.tiktok.com/@peer_nursery)

@ כל הזכויות שמורות למשתלת פאר

[האתר נבנה על ידי Simple Web](https://www.simple-web.co.il/)

[![](https://www.peer-nursery.co.il/wp-content/uploads/2023/05/SimpleWeb-logo-1024x576.png)](https://www.simple-web.co.il/)

סל קניות0

סל הקניות ריק!

A2A