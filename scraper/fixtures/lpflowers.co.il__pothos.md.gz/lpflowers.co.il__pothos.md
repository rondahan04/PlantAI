*   [03-5464522](tel:03-5464522)
*   [אודותינו](https://lpflowers.co.il/%d7%90%d7%95%d7%93%d7%95%d7%aa%d7%99%d7%a0%d7%95/)
*   [צור קשר](https://lpflowers.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)
*   [](https://www.instagram.com/thelittleprinceflowers/)

*   [0](https://lpflowers.co.il/cart/ "View your shopping cart") 

[![Image 1: הנסיך הקטן פרחים](https://lpflowers.co.il/wp-content/themes/GoFlower/images/logo.png)](https://lpflowers.co.il/)

*   [פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [הזרים שלנו](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%94%d7%96%d7%a8%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
    *   [חבילות פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%97%d7%91%d7%99%d7%9c%d7%95%d7%aa-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [זר כלה וזר לראש](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%96%d7%a8-%d7%9b%d7%9c%d7%94-%d7%95%d7%96%d7%a8-%d7%9c%d7%a8%d7%90%d7%a9/)

*   [צמחים וגינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
    *   [גינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
    *   [צמחים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/)

*   [כלים ומתנות](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [כלים](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%90%d7%92%d7%a8%d7%98%d7%9c%d7%99%d7%9d/)
    *   [יין ושוקולד](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a4%d7%99%d7%a0%d7%95%d7%a7%d7%99%d7%9d/)

*   [סדנאות](https://lpflowers.co.il/%d7%a1%d7%93%d7%a0%d7%90%d7%95%d7%aa/)
*   [נשפכים ומטפסים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a0%d7%a9%d7%a4%d7%9b%d7%99%d7%9d-%d7%95%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d/)
*   [נשפכים ומטפסים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a0%d7%a9%d7%a4%d7%9b%d7%99%d7%9d-%d7%95%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d/)
*   [צמחי בית](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%91%d7%99%d7%aa-%d7%95%d7%9c%d7%9e%d7%a8%d7%a4%d7%a1%d7%aa/)
*   [צמחים לגינה ולמרפסת](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%92%d7%99%d7%a0%d7%94-%d7%95%d7%9c%d7%97%d7%95%d7%a5/)
*   [קקטוסים וסקולנטים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)

[עמוד הבית](https://lpflowers.co.il/)>[מוצרים](https://lpflowers.co.il/shop/)> תוצאות חיפוש עבור “פותוס”
# תוצאות חיפוש: "פותוס"

 לא נמצאו מוצרים התואמים את בחירתך. 

פרחים - יהודה המכבי 60, ת"א 

[03-5464522](tel:03-5464522)

א'-ה' 8:00-20:00 ימי ו' וערבי חג 8:00-16:00

משתלה - יהודה המכבי 44, ת"א 

[03-5464522](tel:03-5464522)

א'-ה' 8:00-20:00 ימי ו' וערבי חג 8:00-16:00

סניף כוכב הצפון - מאיר יערי 19, ת"א 

[03-6455833](tel:03-6455833)

א'-ה' 8:00-20:00 ימי ו' וערבי חג 8:00-16:00

סניף ר"ג - מנחם בגין 11 

[03-5464522](tel:03-5464522)

א'-ה' 10:00-17:30 ימי ו' וערבי חג 8:00-15:00

*   [פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
*   [צמחים וגינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
*   [כלים ומתנות](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
*   [סדנאות 1](https://lpflowers.co.il/%d7%a1%d7%93%d7%a0%d7%90%d7%95%d7%aa/)
*   [יין ושוקולד](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a4%d7%99%d7%a0%d7%95%d7%a7%d7%99%d7%9d/)

*   [תקנון האתר](https://lpflowers.co.il/%d7%aa%d7%a7%d7%a0%d7%95%d7%9f-%d7%94%d7%90%d7%aa%d7%a8/)
*   [צור קשר](https://lpflowers.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)
*   [אודותינו](https://lpflowers.co.il/%d7%90%d7%95%d7%93%d7%95%d7%aa%d7%99%d7%a0%d7%95/)
*   [מפת אתר](https://lpflowers.co.il/%d7%9e%d7%a4%d7%aa-%d7%90%d7%aa%d7%a8/)

[lpflowers.mail@gmail.com](mailto:lpflowers.mail@gmail.com)

אנו מכבדים את סוגי הכרטיסים![Image 2: credit cards](https://lpflowers.co.il/wp-content/themes/GoFlower/images/cards.png)

מרכז הזמנות[03-5464522](tel:03-5464522)

[![Image 3: iZer](https://lpflowers.co.il/wp-content/themes/GoFlower/images/izer.png)iZer - מערכת לניהול עסקים](https://izer.co.il/ "iZer - מערכת לניהול עסקים")

![Image 4: toggle icon](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/admin/Original_Logo_Icon.svg)

![Image 5: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/english.png)![Image 6: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/german.png)![Image 7: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/spanish.png)![Image 8: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/french.png)![Image 9: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/italia.png)![Image 10: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/poland.png)![Image 11: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/swedish.png)![Image 12: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/finnland.png)![Image 13: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/portugal.png)![Image 14: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/rumania.png)![Image 15: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/slowakia.png)![Image 16: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/slowenien.png)![Image 17: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/netherland.png)![Image 18: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/danish.png)![Image 19: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/greece.png)![Image 20: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/czech.png)![Image 21: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/hungarian.png)![Image 22: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/lithuanian.png)![Image 23: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/latvian.png)![Image 24: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/estonian.png)![Image 25: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/croatia.png)![Image 26: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/ireland.png)![Image 27: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/bulgarian.png)![Image 28: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/norwegan.png)![Image 29: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/turkish.png)![Image 30: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/indonesian.png)![Image 31: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/brasilian.png)![Image 32: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/japanese.png)![Image 33: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/korean.png)![Image 34: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/chinese-simplified.png)![Image 35: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/arabic.png)![Image 36: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/russian.png)![Image 37: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/hindi.png)![Image 38: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/ukrainian.png)![Image 39: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/serbian.png)![Image 40: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/england.png)![Image 41: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/iran.png)![Image 42: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/israel.png)![Image 43: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/macedonia.png)![Image 44: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/thailand.png)![Image 45: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/vietnam.png)

עברית![Image 46: תפריט נפתח של סמל](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/icon-drop-down-menu.png)

*    אנגלית ![Image 47: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/english.png)
*    גרמנית ![Image 48: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/german.png)
*    ספרדית ![Image 49: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/spanish.png)
*    צרפתית ![Image 50: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/french.png)
*    איטלקית ![Image 51: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/italia.png)
*    פולנית ![Image 52: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/poland.png)
*    שוודית ![Image 53: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/swedish.png)
*    פינית ![Image 54: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/finnland.png)
*    פורטוגזית ![Image 55: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/portugal.png)
*    רומנית ![Image 56: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/rumania.png)
*    סלובנית ![Image 57: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/slowakia.png)
*    סלובקית ![Image 58: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/slowenien.png)
*    הולנדית ![Image 59: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/netherland.png)
*    דנית ![Image 60: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/danish.png)
*    יוונית ![Image 61: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/greece.png)
*    צ'כית ![Image 62: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/czech.png)
*    הונגרית ![Image 63: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/hungarian.png)
*    ליטאית ![Image 64: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/lithuanian.png)
*    לטבית ![Image 65: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/latvian.png)
*    אסטונית ![Image 66: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/estonian.png)
*    קרואטית ![Image 67: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/croatia.png)
*    אירית ![Image 68: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/ireland.png)
*    בולגרית ![Image 69: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/bulgarian.png)
*    נורווגית ![Image 70: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/norwegan.png)
*    טורקית ![Image 71: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/turkish.png)
*    אינדונזית ![Image 72: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/indonesian.png)
*    פורטוגזית (ברזיל) ![Image 73: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/brasilian.png)
*    יפנית ![Image 74: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/japanese.png)
*    קוריאנית ![Image 75: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/korean.png)
*    סינית מפושטת ![Image 76: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/chinese-simplified.png)
*    ערבית ![Image 77: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/arabic.png)
*    רוסית ![Image 78: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/russian.png)
*    הינדי ![Image 79: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/hindi.png)
*    אוקראינית ![Image 80: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/ukrainian.png)
*    סרבית ![Image 81: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/serbian.png)
*    Englisch (UK) ![Image 82: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/england.png)
*    איראן ![Image 83: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/iran.png)
*    ישראל ![Image 84: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/israel.png)
*    מקדוניה ![Image 85: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/macedonia.png)
*    תאילנד ![Image 86: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/thailand.png)
*    וייטנאם ![Image 87: flag](https://lpflowers.co.il/wp-content/plugins/accessibility-onetap/assets/images/vietnam.png)

התאמות נגישות

מופעל על ידי[OneTap](https://wponetap.com/?utm_source=frontend-link&utm_medium=link&utm_campaign=ref-link-toolbar)

הסתר סרגל כלים

חזרה

לכמה זמן תרצה להסתיר את סרגל הכלים לנגישות?משך הסתרת סרגל כלים רק עבור הפעלה זו 24 שעות שבוע 

לא עכשיו הסתר סרגל כלים

בחר את פרופיל הנגישות שלך

מצב ליקוי ראייה

משפר את האלמנטים הוויזואליים של האתר

- [x]  

פרופיל בטוח להתקפים

מפחית הבזקים ומשפר צבעים

- [x]  

מצב ידידותי ל-ADHD

גלישה ממוקדת ללא הסחות דעת

- [x]  

מצב עיוורון

מפחית הסחות דעת, משפר ריכוז

- [x]  

מצב בטוח לאפילפסיה

מעמעם צבעים ועוצר הבהוב

- [x]  

מודולי תוכן

גודל גופן

+
ברירת מחדל

-

גופן קריא

גובה שורה

+
ברירת מחדל

-

סמן גדול

מרווח אותיות

יישור טקסט

עובי גופן

מודולי צבע

ניגודיות בהירה

ניגודיות גבוהה

מונוכרום

מודולי כיוון

קו קריאה

מסכת קריאה

הסתר תמונות

הדגש תוכן

עצור אנימציות

הדגש קישורים

דלג לתוכן 

איפוס הגדרות

[](https://lpflowers.co.il/)

*   [פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [הזרים שלנו](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%94%d7%96%d7%a8%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
    *   [חבילות פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%97%d7%91%d7%99%d7%9c%d7%95%d7%aa-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [זר כלה וזר לראש](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%96%d7%a8-%d7%9b%d7%9c%d7%94-%d7%95%d7%96%d7%a8-%d7%9c%d7%a8%d7%90%d7%a9/)

*   [צמחים וגינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
    *   [גינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
    *   [צמחים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/)

*   [כלים ומתנות](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
    *   [כלים](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%90%d7%92%d7%a8%d7%98%d7%9c%d7%99%d7%9d/)
    *   [יין ושוקולד](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a4%d7%99%d7%a0%d7%95%d7%a7%d7%99%d7%9d/)

*   [סדנאות](https://lpflowers.co.il/%d7%a1%d7%93%d7%a0%d7%90%d7%95%d7%aa/)
*   [נשפכים ומטפסים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a0%d7%a9%d7%a4%d7%9b%d7%99%d7%9d-%d7%95%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d/)
*   [נשפכים ומטפסים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a0%d7%a9%d7%a4%d7%9b%d7%99%d7%9d-%d7%95%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d/)
*   [צמחי בית](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%91%d7%99%d7%aa-%d7%95%d7%9c%d7%9e%d7%a8%d7%a4%d7%a1%d7%aa/)
*   [צמחים לגינה ולמרפסת](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%92%d7%99%d7%a0%d7%94-%d7%95%d7%9c%d7%97%d7%95%d7%a5/)
*   [קקטוסים וסקולנטים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)

[![Image 88: WhatsApp chat](https://lpflowers.co.il/wp-content/plugins/click-to-chat-for-whatsapp/new/inc/assets/img/whatsapp-logo.svg)](https://web.whatsapp.com/send?phone=+972-58-4226623&text=)