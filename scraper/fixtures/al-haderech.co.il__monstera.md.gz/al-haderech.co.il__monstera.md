 [דילוג לתוכן](#content)

הקדימו הזמנותיכם לראש השנה - מתנות מושלמות מחכות לכם באתר🌸 משלוחים מאשדוד עד נתניה🌸

[![משתלת על הדרך](https://al-haderech.co.il/wp-content/uploads/2020/03/73e7f50e58afe362bd4383dec364a3db.png)](https://al-haderech.co.il)

* [החשבון שלי](https://al-haderech.co.il/my-account/)

[להזמנות **03-9550043**](tel:03-9550043)

[יעקב פריימן, **ראשון לציון**](https://waze.com/ul?q=משתלת%20על%20הדרך%20-%20סניף%20פריימן&z=10&navigate=yes)

[₪0.00  0 עגלת קניות](#)

* + [**ראש השנה 2026**](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-2026/)
  + [מתנות קטנות](https://al-haderech.co.il/product-category/gifts/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a7%d7%98%d7%a0%d7%95%d7%aa/)
  + [בלונים, דובים ושוקולדים](https://al-haderech.co.il/product-category/gifts/%d7%91%d7%9c%d7%95%d7%a0%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
  + [עציצים ארוזים](https://al-haderech.co.il/product-category/gifts/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%90%d7%a8%d7%95%d7%96%d7%99%d7%9d/)
  + [מתנות לתינוק וליולדת](https://al-haderech.co.il/product-category/gifts/baby/)
  + [ט”ו בשבט](https://al-haderech.co.il/product-category/gifts/%d7%98%d7%95-%d7%91%d7%a9%d7%91%d7%98/)
* [פרחים טריים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)

  + [![ראש השנה 2026](https://al-haderech.co.il/wp-content/uploads/2021/02/love400.jpg)

    ## ראש השנה 202634 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-2026/)
  + [![זרי פרחים](https://al-haderech.co.il/wp-content/uploads/2020/07/alvin-matthews-AMd-OdlpPs0-unsplash.jpg)

    ## זרי פרחים28 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [![סידורי פרחים](https://al-haderech.co.il/wp-content/uploads/2020/07/bianca-ackermann-4suxZjeCpYk-unsplash.jpg)

    ## סידורי פרחים6 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%99%d7%93%d7%95%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [![סחלבים](https://al-haderech.co.il/wp-content/uploads/2020/07/orchid.jpg)

    ## סחלבים2 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)
  + [![זרי כלה](https://al-haderech.co.il/wp-content/uploads/2020/08/bride.jpg)

    ## זרי כלה10 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
  + [![זרים לראש](https://al-haderech.co.il/wp-content/uploads/2022/03/unnamed-400x400.jpg)

    ## זרים לראש6 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%a8%d7%90%d7%a9/)
  + [![קישוטי רכב](https://al-haderech.co.il/wp-content/uploads/2020/07/CAR.jpg)

    ## קישוטי רכב3 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a7%d7%99%d7%a9%d7%95%d7%98%d7%99-%d7%a8%d7%9b%d7%91/)
  + [![גלגלי אבל](https://al-haderech.co.il/wp-content/uploads/2025/05/גלגל-אבל-1.jpg)

    ## גלגלי אבל2 מוצרים](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%92%d7%9c%d7%92%d7%9c%d7%99-%d7%90%d7%91%d7%9c/)
* [צמחים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)

  + [![עצים, מטפסים ושיחים](https://al-haderech.co.il/wp-content/uploads/2021/02/trees.jpg)

    ## עצים, מטפסים ושיחים36 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%9d-%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d-%d7%95%d7%a9%d7%99%d7%97%d7%99%d7%9d/)
  + [![צמחי תבלין וירקות](https://al-haderech.co.il/wp-content/uploads/2020/07/basil-932079_1920.jpg)

    ## צמחי תבלין וירקות28 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%aa%d7%91%d7%9c%d7%99%d7%a0%d7%99%d7%9d/)
  + [![צמחי גן - שמש](https://al-haderech.co.il/wp-content/uploads/2020/07/verbena.jpg)

    ## צמחי גן - שמש55 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-12-%d7%a1%d7%9e/)
  + [![צמחי גן - צל](https://al-haderech.co.il/wp-content/uploads/2020/07/begonia400.jpg)

    ## צמחי גן - צל36 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%97%d7%95%d7%a5-%d7%a2%d7%a6%d7%99%d7%a6%d7%99-15-%d7%a1%d7%9e/)
  + [![שישיות פורחים](https://al-haderech.co.il/wp-content/uploads/2020/07/geranium.jpg)

    ## שישיות פורחים16 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/130262-%d7%a9%d7%99%d7%a9%d7%99%d7%95%d7%aa-%d7%a4%d7%95%d7%a8%d7%97%d7%99%d7%9d/)
  + [![צמחי בית ומשרד](https://al-haderech.co.il/wp-content/uploads/2020/07/office.jpg)

    ## צמחי בית ומשרד173 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa/)
  + [![צמחי תלייה לבית](https://al-haderech.co.il/wp-content/uploads/2020/08/hang.jpg)

    ## צמחי תלייה לבית36 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9c%d7%91%d7%99%d7%aa/)
  + [![צמחי בית קטנים](https://al-haderech.co.il/wp-content/uploads/2020/07/8d49cfd73a1973a1c32f3abfaed079d6.jpg)

    ## צמחי בית קטנים104 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa-%d7%a7%d7%98%d7%a0%d7%99%d7%9d/)
  + [![סחלבים](https://al-haderech.co.il/wp-content/uploads/2020/07/orchid.jpg)

    ## סחלבים3 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
  + [![צמחים ומוצרים לטרריום](https://al-haderech.co.il/wp-content/uploads/2020/07/b065effa9f2f6cdeb055d19e5374da41.jpg)

    ## צמחים ומוצרים לטרריום75 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%98%d7%a8%d7%a8%d7%99%d7%95%d7%9e%d7%99%d7%9d/)
  + [![קקטוסים וסוקולנטים](https://al-haderech.co.il/wp-content/uploads/2020/08/cactus.jpg)

    ## קקטוסים וסוקולנטים102 מוצרים](https://al-haderech.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d/105322-%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)
* [המיוחדים שלנו](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)

  + [![טורפים](https://al-haderech.co.il/wp-content/uploads/2025/06/כדנית-גאיה-199.9-400x400.jpg)

    ## טורפים13 מוצרים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%98%d7%95%d7%a8%d7%a4%d7%99%d7%9d/)
  + [![המיניאטורים](https://al-haderech.co.il/wp-content/uploads/2020/12/image_6483441-2.jpg)

    ## המיניאטורים69 מוצרים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%9e%d7%99%d7%a7%d7%a8%d7%95/)
  + [![המיוחדים](https://al-haderech.co.il/wp-content/uploads/2020/12/special.jpg)

    ## המיוחדים405 מוצרים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d/)
  + [![הויות מיוחדות](https://al-haderech.co.il/wp-content/uploads/2024/02/IMG_2319-400x400.jpg)

    ## הויות מיוחדות117 מוצרים](https://al-haderech.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/%d7%94%d7%95%d7%99%d7%95%d7%aa-%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%95%d7%aa/)
* [ירקות מהשדה](https://al-haderech.co.il/product-category/%d7%99%d7%a8%d7%a7%d7%95%d7%aa-%d7%98%d7%a8%d7%99%d7%99%d7%9d/)
* [כלי שתילה ואדניות](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)

  + [![עציצי תלייה מפלסטיק](https://al-haderech.co.il/wp-content/uploads/2020/04/be17786170ffd9022909382eec6ef95b-400x400.jpg)

    ## עציצי תלייה מפלסטיקמוצר 1](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%aa%d7%9c%d7%99%d7%99%d7%94-%d7%9e%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
  + [![עציצי פלסטיק](https://al-haderech.co.il/wp-content/uploads/2020/04/aea29b155c207f99a54d0c84e00ccd8f-400x400.jpg)

    ## עציצי פלסטיק19 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%a2%d7%a6%d7%99%d7%a6%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
  + [![אדניות פלסטיק](https://al-haderech.co.il/wp-content/uploads/2020/04/077769dace9aa3260fdfbc0dcbd17ffc-400x400.jpg)

    ## אדניות פלסטיק12 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
  + [![אדניות למעקה](https://al-haderech.co.il/wp-content/uploads/2020/04/f54d2c347458d3dd28cd5d6f2ce79c0c-400x400.jpg)

    ## אדניות למעקה6 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%9c%d7%9e%d7%a2%d7%a7%d7%94/)
* [אביזרי גינון](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/)

  + [![מוצרי השקייה](https://al-haderech.co.il/wp-content/uploads/2020/07/water-jet-3611518_1920.jpg)

    ## מוצרי השקייה81 מוצרים](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)
  + [![כלי עבודה](https://al-haderech.co.il/wp-content/uploads/2020/07/planting-4226838_1920.jpg)

    ## כלי עבודה37 מוצרים](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%9b%d7%9c%d7%99-%d7%a2%d7%91%d7%95%d7%93%d7%94/)
  + [![אביזרים למערכות השקייה](https://al-haderech.co.il/wp-content/uploads/2022/11/gardening-tools.jpg)

    ## אביזרים למערכות השקייה67 מוצרים](https://al-haderech.co.il/product-category/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%9e%d7%a2%d7%a8%d7%9b%d7%95%d7%aa-%d7%94%d7%a9%d7%a7%d7%99%d7%99%d7%94/)
* [כדים ודקורציה לבית](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)

  + [![כדי פלסטיק מעוצבים](https://al-haderech.co.il/wp-content/uploads/2024/10/ספרה-אפור-400x400.jpg)

    ## כדי פלסטיק מעוצבים9 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d/)
  + [![צמחייה מיובשת ומלאכותית](https://al-haderech.co.il/wp-content/uploads/2020/03/5caafdb9e1ecd3c8661ad3c6c390aa9f-400x315.jpg)

    ## צמחייה מיובשת ומלאכותית7 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a6%d7%9e%d7%97%d7%99%d7%94-%d7%9e%d7%99%d7%95%d7%91%d7%a9%d7%aa-%d7%95%d7%9e%d7%9c%d7%90%d7%9b%d7%95%d7%aa%d7%99%d7%aa/)
  + [![כדי קרמיקה](https://al-haderech.co.il/wp-content/uploads/2020/09/ceramic-mug-4797733_640.jpg)

    ## כדי קרמיקה33 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
  + [![כדי טרקוטה](https://al-haderech.co.il/wp-content/uploads/2020/09/bouquet-3874595_640.jpg)

    ## כדי טרקוטה6 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%98%d7%a8%d7%a7%d7%95%d7%98%d7%94/)
  + [![כדי מתכת](https://al-haderech.co.il/wp-content/uploads/2020/09/cactus-1842260_640.jpg)

    ## כדי מתכתמוצר 1](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%a4%d7%99%d7%91%d7%a8/)
  + [![עיצוב הבית](https://al-haderech.co.il/wp-content/uploads/2020/09/summer-2448878_640.jpg)

    ## עיצוב הבית47 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/)
  + [![כדים על רגליים](https://al-haderech.co.il/wp-content/uploads/2020/09/laged.jpg)

    ## כדים על רגליים4 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99%d7%9d-%d7%a2%d7%9c-%d7%a8%d7%92%d7%9c%d7%99%d7%99%d7%9d/)
  + [![סלים](https://al-haderech.co.il/wp-content/uploads/2020/09/tulips-708410_640.jpg)

    ## סלים9 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%a1%d7%9c%d7%99%d7%9d/)
  + [![כדי בטון](https://al-haderech.co.il/wp-content/uploads/2020/09/concrit.jpg)

    ## כדי בטון10 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%93%d7%99-%d7%91%d7%98%d7%95%d7%9f/)
  + [![כלי זכוכית](https://al-haderech.co.il/wp-content/uploads/2020/09/tulip-1230390_640.jpg)

    ## כלי זכוכית18 מוצרים](https://al-haderech.co.il/product-category/%d7%9b%d7%93%d7%99%d7%9d-%d7%95%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%94%d7%91%d7%99%d7%aa/%d7%9b%d7%9c%d7%99-%d7%96%d7%9b%d7%95%d7%9b%d7%99%d7%aa/)
* [דשנים הדברה ותערובות](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/)

  + [![תערובות וחיפויים](https://al-haderech.co.il/wp-content/uploads/2020/07/gardening-690940_1920.jpg)

    ## תערובות וחיפויים34 מוצרים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa-%d7%95%d7%97%d7%99%d7%a4%d7%95%d7%99%d7%99%d7%9d/)
  + [![חומרי הדברה](https://al-haderech.co.il/wp-content/uploads/2020/07/snail.jpg)

    ## חומרי הדברה39 מוצרים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%97%d7%95%d7%9e%d7%a8%d7%99-%d7%94%d7%93%d7%91%d7%a8%d7%94/)
  + [![דשנים](https://al-haderech.co.il/wp-content/uploads/2020/07/4ca35181bb83b46f46486b751d128d7b.jpg)

    ## דשנים51 מוצרים](https://al-haderech.co.il/product-category/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%94%d7%93%d7%91%d7%a8%d7%94-%d7%95%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%95%d7%aa/%d7%93%d7%a9%d7%a0%d7%99%d7%9d/)

[![משתלת על הדרך](https://al-haderech.co.il/wp-content/uploads/2020/03/73e7f50e58afe362bd4383dec364a3db.png)](https://al-haderech.co.il)

[להזמנות **03-9550043**](tel:03-9550043)

[₪0.00  0 עגלת קניות](#)

* מבצע! [![מבצע מונסטרה סילטפיקנה אוראה ע' 9](https://al-haderech.co.il/wp-content/uploads/2026/08/פרסטטטט-מונסטרה-סיטלפיקנה-אוראה-499.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a1%d7%99%d7%9c%d7%98%d7%a4%d7%99%d7%a7%d7%a0%d7%94-%d7%90%d7%95%d7%a8%d7%90%d7%94-%d7%a2-9/)

  [## מבצע מונסטרה סילטפיקנה אוראה ע’ 9](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a1%d7%99%d7%9c%d7%98%d7%a4%d7%99%d7%a7%d7%a0%d7%94-%d7%90%d7%95%d7%a8%d7%90%d7%94-%d7%a2-9/) ~~₪699.00~~ המחיר המקורי היה: ₪699.00.₪499.90המחיר הנוכחי הוא: ₪499.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=53018)
* [![מונסטרה אוסי דרים ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/08/פרסטטטט-מונסטרה-אוסי-דרים-349-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%95%d7%a1%d7%99-%d7%93%d7%a8%d7%99%d7%9d-%d7%a2-12/)

  [## מונסטרה אוסי דרים ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%95%d7%a1%d7%99-%d7%93%d7%a8%d7%99%d7%9d-%d7%a2-12/) ₪349.00 [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=53014)
* מבצע! [![מבצע מונסטרה דוויל ע' 6](https://al-haderech.co.il/wp-content/uploads/2026/07/מונסטרה-דוויל-1499.9-חזרה-400x400.png)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%93%d7%95%d7%95%d7%99%d7%9c-%d7%a2-6/)

  [## מבצע מונסטרה דוויל ע’ 6](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%93%d7%95%d7%95%d7%99%d7%9c-%d7%a2-6/) ~~₪1,799.00~~ המחיר המקורי היה: ₪1,799.00.₪1,499.90המחיר הנוכחי הוא: ₪1,499.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=52257)
* מבצע! [![מבצע מונסטרה וויט מונסטר ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/08/מונסטרה-וויט-מונסטר-299.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%95%d7%95%d7%99%d7%98-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8-%d7%a2-12/)

  [## מבצע מונסטרה וויט מונסטר ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%95%d7%95%d7%99%d7%98-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8-%d7%a2-12/) ~~₪499.00~~ המחיר המקורי היה: ₪499.00.₪299.90המחיר הנוכחי הוא: ₪299.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51876)
* מבצע! [![מבצע מונסטרה פילמנטוס ע' 11](https://al-haderech.co.il/wp-content/uploads/2026/06/מונסטרה-פילמנטוס-599.9פרסטטטטטט-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a4%d7%99%d7%9c%d7%9e%d7%a0%d7%98%d7%95%d7%a1-%d7%a2-11/)

  [## מבצע מונסטרה פילמנטוס ע’ 11](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a4%d7%99%d7%9c%d7%9e%d7%a0%d7%98%d7%95%d7%a1-%d7%a2-11/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪599.90המחיר הנוכחי הוא: ₪599.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51651)
* מבצע! [![מבצע מונסטרה דיסקטה ע' 11](https://al-haderech.co.il/wp-content/uploads/2026/06/מונסטרה-דיסקטה-499.9-פרסטטטטטט-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%93%d7%99%d7%a1%d7%a7%d7%98%d7%94-%d7%a2-11/)

  [## מבצע מונסטרה דיסקטה ע’ 11](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%93%d7%99%d7%a1%d7%a7%d7%98%d7%94-%d7%a2-11/) ~~₪699.00~~ המחיר המקורי היה: ₪699.00.₪499.90המחיר הנוכחי הוא: ₪499.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51649)
* מבצע! [![מבצע מונסטרה גמבנסיס ע' 11](https://al-haderech.co.il/wp-content/uploads/2026/06/מונסטרה-גמבנסיס-599.9-פרסטטטטטט-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%92%d7%9e%d7%91%d7%a0%d7%a1%d7%99%d7%a1-%d7%a2-11/)

  [## מבצע מונסטרה גמבנסיס ע’ 11](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%92%d7%9e%d7%91%d7%a0%d7%a1%d7%99%d7%a1-%d7%a2-11/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪599.90המחיר הנוכחי הוא: ₪599.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51647)
* מבצע! [![מבצע מונסטרה SP נאפו ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/06/מונסטרה-SP-נאפו-599.9-פרסטטטטט-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-sp-%d7%a0%d7%90%d7%a4%d7%95-%d7%a2-12/)

  [## מבצע מונסטרה SP נאפו ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-sp-%d7%a0%d7%90%d7%a4%d7%95-%d7%a2-12/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪599.90המחיר הנוכחי הוא: ₪599.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51645)
* מבצע! [![מבצע מונסטרה אלקטרולייט ע' 6](https://al-haderech.co.il/wp-content/uploads/2026/06/פרסטטטטט-מונסטה-אלקטרולייט-799.9-ע-6-4יח-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%9c%d7%a7%d7%98%d7%a8%d7%95%d7%9c%d7%99%d7%99%d7%98-%d7%a2-6/)

  [## מבצע מונסטרה אלקטרולייט ע’ 6](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%9c%d7%a7%d7%98%d7%a8%d7%95%d7%9c%d7%99%d7%99%d7%98-%d7%a2-6/) ~~₪799.90~~ המחיר המקורי היה: ₪799.90.₪599.90המחיר הנוכחי הוא: ₪599.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51360)
* מבצע! [![מבצע מונסטרה גולדן/למון ליים ע' 6](https://al-haderech.co.il/wp-content/uploads/2026/06/שבירת-מחיררר-מונסטרה-למון-ליים-119.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%92%d7%95%d7%9c%d7%93%d7%9f-%d7%9c%d7%9e%d7%95%d7%9f-%d7%9c%d7%99%d7%99%d7%9d-%d7%a2-6/)

  [## מבצע מונסטרה גולדן/למון ליים ע’ 6](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%92%d7%95%d7%9c%d7%93%d7%9f-%d7%9c%d7%9e%d7%95%d7%9f-%d7%9c%d7%99%d7%99%d7%9d-%d7%a2-6/) ~~₪399.00~~ המחיר המקורי היה: ₪399.00.₪119.90המחיר הנוכחי הוא: ₪119.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51359)
* מבצע! [![מבצע מונסטרה קסנטוספטאה ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/06/פרסטטטטט-מונסטרה-קסנטוספטאה-499.9-3יח-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a7%d7%a1%d7%a0%d7%98%d7%95%d7%a1%d7%a4%d7%98%d7%90%d7%94-%d7%a2-12/)

  [## מבצע מונסטרה קסנטוספטאה ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a7%d7%a1%d7%a0%d7%98%d7%95%d7%a1%d7%a4%d7%98%d7%90%d7%94-%d7%a2-12/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪499.90המחיר הנוכחי הוא: ₪499.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51347)
* מבצע! [![מבצע מונסטרה טווינזה נארו ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/06/פרסטטט-ולסט-וואן-מונסטרה-טווינזה-נארו-499.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%98%d7%95%d7%95%d7%99%d7%a0%d7%96%d7%94-%d7%a0%d7%90%d7%a8%d7%95-%d7%a2-12/)

  [## מבצע מונסטרה טווינזה נארו ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%98%d7%95%d7%95%d7%99%d7%a0%d7%96%d7%94-%d7%a0%d7%90%d7%a8%d7%95-%d7%a2-12/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪499.90המחיר הנוכחי הוא: ₪499.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51346)
* מבצע! [![מבצע מונסטרה אוראו פינאטה ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/06/פרסטטט-מונסטרה-אוראו-פינאטה-499.9-4יח-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%95%d7%a8%d7%90%d7%95-%d7%a4%d7%99%d7%a0%d7%90%d7%98%d7%94-%d7%a2-12/)

  [## מבצע מונסטרה אוראו פינאטה ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%95%d7%a8%d7%90%d7%95-%d7%a4%d7%99%d7%a0%d7%90%d7%98%d7%94-%d7%a2-12/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪499.90המחיר הנוכחי הוא: ₪499.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=51342)
* [![מונסטרה סטדליאנה סטאר דסט ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/08/חזר-למלאייי-מונסטרה-סטדליאנה-סטאר-דסט-399-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a1%d7%98%d7%93%d7%9c%d7%99%d7%90%d7%a0%d7%94-%d7%a1%d7%98%d7%90%d7%a8-%d7%93%d7%a1%d7%98-%d7%a2-12/)

  [## מונסטרה סטדליאנה סטאר דסט ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a1%d7%98%d7%93%d7%9c%d7%99%d7%90%d7%a0%d7%94-%d7%a1%d7%98%d7%90%d7%a8-%d7%93%d7%a1%d7%98-%d7%a2-12/) ₪399.00 [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=50479)
* מבצע! [![מונסטרה סיראנה הוואי ע' 14](https://al-haderech.co.il/wp-content/uploads/2026/05/פרסטטטט-מונסטרה-סיראנה-הוואי-599.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a1%d7%99%d7%a8%d7%90%d7%a0%d7%94-%d7%94%d7%95%d7%95%d7%90%d7%99-%d7%a2-13/)

  [## מונסטרה סיראנה הוואי ע’ 14](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a1%d7%99%d7%a8%d7%90%d7%a0%d7%94-%d7%94%d7%95%d7%95%d7%90%d7%99-%d7%a2-13/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪599.90המחיר הנוכחי הוא: ₪599.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=50478)
* מבצע! [![מבצע מונסטרה אובליקה אמזונס ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/05/מונסטרה-אמזונס-599.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%95%d7%91%d7%9c%d7%99%d7%a7%d7%94-%d7%90%d7%9e%d7%96%d7%95%d7%a0%d7%a1-%d7%a2-12/)

  [## מבצע מונסטרה אובליקה אמזונס ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%95%d7%91%d7%9c%d7%99%d7%a7%d7%94-%d7%90%d7%9e%d7%96%d7%95%d7%a0%d7%a1-%d7%a2-12/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪599.90המחיר הנוכחי הוא: ₪599.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=49971)
* מבצע! [![מבצע מונסטרה SP קולומביה ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/04/מונסטרה-SP-קולומביה-599.9-מבצע-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-sp-%d7%a7%d7%95%d7%9c%d7%95%d7%9e%d7%91%d7%99%d7%94-%d7%a2-12-2/)

  [## מבצע מונסטרה SP קולומביה ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-sp-%d7%a7%d7%95%d7%9c%d7%95%d7%9e%d7%91%d7%99%d7%94-%d7%a2-12-2/) ~~₪799.00~~ המחיר המקורי היה: ₪799.00.₪599.90המחיר הנוכחי הוא: ₪599.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=49969)
* [![מבצע מונסטרה אדנסוני אוראה ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/03/מונסטרה-אדנסוני-אוראה-249-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%93%d7%a0%d7%a1%d7%95%d7%a0%d7%99-%d7%90%d7%95%d7%a8%d7%90%d7%94-%d7%a2-12/)

  [## מבצע מונסטרה אדנסוני אוראה ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%93%d7%a0%d7%a1%d7%95%d7%a0%d7%99-%d7%90%d7%95%d7%a8%d7%90%d7%94-%d7%a2-12/) ₪249.00 [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=49376)
* מבצע! [![מבצע מונסטרה מינט ע' 7](https://al-haderech.co.il/wp-content/uploads/2026/05/מונסטרה-מינט-249.9-בק-אין-סטוק-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%99%d7%a0%d7%98-%d7%a2-7/)

  [## מבצע מונסטרה מינט ע’ 7](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%99%d7%a0%d7%98-%d7%a2-7/) ~~₪599.00~~ המחיר המקורי היה: ₪599.00.₪249.90המחיר הנוכחי הוא: ₪249.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=48330)
* [![מונסטרה סילטפיקנה לתלייה](https://al-haderech.co.il/wp-content/uploads/2026/01/מונסטרה-סילטפיקנה-בתלייה-149-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a1%d7%99%d7%9c%d7%98%d7%a4%d7%99%d7%a7%d7%a0%d7%94-%d7%9c%d7%aa%d7%9c%d7%99%d7%99%d7%94/)

  [## מונסטרה סילטפיקנה לתלייה](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a1%d7%99%d7%9c%d7%98%d7%a4%d7%99%d7%a7%d7%a0%d7%94-%d7%9c%d7%aa%d7%9c%d7%99%d7%99%d7%94/) ₪149.00 [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=48027)
* מבצע! [![מבצע מונסטרה בלבזור ע' 7](https://al-haderech.co.il/wp-content/uploads/2026/08/מונסטרה-בלאבזור-299.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%9c%d7%91%d7%96%d7%95%d7%a8-%d7%a2-7/)

  [## מבצע מונסטרה בלבזור ע’ 7](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%9c%d7%91%d7%96%d7%95%d7%a8-%d7%a2-7/) ~~₪499.00~~ המחיר המקורי היה: ₪499.00.₪299.90המחיר הנוכחי הוא: ₪299.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=47751)
* [![מונסטרה אדנסוני מגוונת ע׳ 6](https://al-haderech.co.il/wp-content/uploads/2026/08/מונסטרה-אדנסוני-אלבו-149-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%93%d7%a0%d7%a1%d7%95%d7%a0%d7%99%d7%99-%d7%9e%d7%92%d7%95%d7%95%d7%a0%d7%aa-%d7%a2%d7%b3-6/)

  [## מונסטרה אדנסוני מגוונת ע׳ 6](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%93%d7%a0%d7%a1%d7%95%d7%a0%d7%99%d7%99-%d7%9e%d7%92%d7%95%d7%95%d7%a0%d7%aa-%d7%a2%d7%b3-6/) ₪149.00 [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=47265)
* [![מונסטרה אובליקה יסוני ע' 10](https://al-haderech.co.il/wp-content/uploads/2025/12/חזר-למלאי-מונסטרה-אובליקה-יסוני-189-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%95%d7%91%d7%9c%d7%99%d7%a7%d7%94-%d7%99%d7%a1%d7%95%d7%a0%d7%99-%d7%a2-10/)

  [## מונסטרה אובליקה יסוני ע’ 10](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%95%d7%91%d7%9c%d7%99%d7%a7%d7%94-%d7%99%d7%a1%d7%95%d7%a0%d7%99-%d7%a2-10/) ₪189.00 [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=46966)
* מבצע! [![מבצע מונסטרה מינט ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/08/מונסטרה-מינט-249.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%99%d7%a0%d7%98-%d7%a2-12/)

  [## מבצע מונסטרה מינט ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%91%d7%a6%d7%a2-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%99%d7%a0%d7%98-%d7%a2-12/) ~~₪499.00~~ המחיר המקורי היה: ₪499.00.₪249.90המחיר הנוכחי הוא: ₪249.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=46550)
* מבצע! [![מונסטרה אלבו בכד](https://al-haderech.co.il/wp-content/uploads/2025/09/מונסטרה-אלבו-בכד-349.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%9c%d7%91%d7%95-%d7%91%d7%9b%d7%93/)

  [## מונסטרה אלבו בכד](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%90%d7%9c%d7%91%d7%95-%d7%91%d7%9b%d7%93/) ~~₪445.00~~ המחיר המקורי היה: ₪445.00.₪349.90המחיר הנוכחי הוא: ₪349.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=45414)
* מבצע! [![מונסטרה בורל מרקס פליים בכד](https://al-haderech.co.il/wp-content/uploads/2025/09/מונס-בורל-מרקס-299.9-מבצע-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%95%d7%a8%d7%9c-%d7%9e%d7%a8%d7%a7%d7%a1-%d7%a4%d7%9c%d7%99%d7%99%d7%9d-%d7%91%d7%9b%d7%93/)

  [## מונסטרה בורל מרקס פליים בכד](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%95%d7%a8%d7%9c-%d7%9e%d7%a8%d7%a7%d7%a1-%d7%a4%d7%9c%d7%99%d7%99%d7%9d-%d7%91%d7%9b%d7%93/) ~~₪395.00~~ המחיר המקורי היה: ₪395.00.₪299.90המחיר הנוכחי הוא: ₪299.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=45413)
* מבצע! [![מונסטרה בורל מרקס פליים ע' 15](https://al-haderech.co.il/wp-content/uploads/2025/09/בורל-מרקס-פליים-249.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%95%d7%a8%d7%9c-%d7%9e%d7%a8%d7%a7%d7%a1-%d7%a4%d7%9c%d7%99%d7%99%d7%9d-%d7%a2-15/)

  [## מונסטרה בורל מרקס פליים ע’ 15](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%95%d7%a8%d7%9c-%d7%9e%d7%a8%d7%a7%d7%a1-%d7%a4%d7%9c%d7%99%d7%99%d7%9d-%d7%a2-15/) ~~₪599.00~~ המחיר המקורי היה: ₪599.00.₪249.90המחיר הנוכחי הוא: ₪249.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=45309)
* מבצע! [![מבצע מונסטרה פרוזן פרקלס ע' 12](https://al-haderech.co.il/wp-content/uploads/2026/06/ירידת-מחיררררר-מונסטרה-פרוזן-פרקלס-99.9-400x400.jpg)](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a4%d7%a8%d7%95%d7%96%d7%9f-%d7%a4%d7%a8%d7%a7%d7%9c%d7%a1-%d7%a2-12/)

  [## מבצע מונסטרה פרוזן פרקלס ע’ 12](https://al-haderech.co.il/items/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%a4%d7%a8%d7%95%d7%96%d7%9f-%d7%a4%d7%a8%d7%a7%d7%9c%d7%a1-%d7%a2-12/) ~~₪199.00~~ המחיר המקורי היה: ₪199.00.₪99.90המחיר הנוכחי הוא: ₪99.90. [הוספה לסל](/?s=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&post_type=product&add-to-cart=42403)

נגישות

* + *visibility\_off*השבת את ההבזקים
  + *title*סמן כותרות
  + *settings*צבע רקע
* + *zoom\_out*זום (הקטנה)
  + *zoom\_in*זום (הגדלה)
* + *remove\_circle\_outline*הקטנת גופן
  + *add\_circle\_outline*הגדלת גופן
  + *spellcheck*גופן קריא
* + *brightness\_high*ניגודיות בהירה
  + *brightness\_low*ניגודיות כהה
* + *format\_underlined*הוסף קו תחתון לקישורים
  + *font\_download*סמן קישורים
* + לאפס את כל האפשרויות*cached*

Scroll to Top

## 🍎🍯 שנה טובה ומתוקה 🍎🍯

ראש השנה 2026 התחלנו! הקדימו הזמנותיכם לחג ושריינו לאהובים שלכם את המתנות הכי יפות שאפשר לקבל :)

## [לחצו כאן!](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a4%d7%a1%d7%97-2026/)

[SHOP NOW](https://al-haderech.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%a4%d7%a1%d7%97-2026/)

 