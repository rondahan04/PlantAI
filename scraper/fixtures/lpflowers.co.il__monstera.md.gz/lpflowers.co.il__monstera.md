* [03-5464522](tel:03-5464522)
* [אודותינו](https://lpflowers.co.il/%d7%90%d7%95%d7%93%d7%95%d7%aa%d7%99%d7%a0%d7%95/)
* [צור קשר](https://lpflowers.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)

[![הנסיך הקטן פרחים](https://lpflowers.co.il/wp-content/themes/GoFlower/images/logo.png)](https://lpflowers.co.il)

* [פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [הזרים שלנו](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%94%d7%96%d7%a8%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
  + [חבילות פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%97%d7%91%d7%99%d7%9c%d7%95%d7%aa-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [זר כלה וזר לראש](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%96%d7%a8-%d7%9b%d7%9c%d7%94-%d7%95%d7%96%d7%a8-%d7%9c%d7%a8%d7%90%d7%a9/)
* [צמחים וגינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
  + [גינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
  + [צמחים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/)
* [כלים ומתנות](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
  + [כלים](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%90%d7%92%d7%a8%d7%98%d7%9c%d7%99%d7%9d/)
  + [יין ושוקולד](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a4%d7%99%d7%a0%d7%95%d7%a7%d7%99%d7%9d/)
* [סדנאות](https://lpflowers.co.il/%d7%a1%d7%93%d7%a0%d7%90%d7%95%d7%aa/)
* [נשפכים ומטפסים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a0%d7%a9%d7%a4%d7%9b%d7%99%d7%9d-%d7%95%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d/)
* [נשפכים ומטפסים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a0%d7%a9%d7%a4%d7%9b%d7%99%d7%9d-%d7%95%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d/)
* [צמחי בית](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%91%d7%99%d7%aa-%d7%95%d7%9c%d7%9e%d7%a8%d7%a4%d7%a1%d7%aa/)
* [צמחים לגינה ולמרפסת](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%92%d7%99%d7%a0%d7%94-%d7%95%d7%9c%d7%97%d7%95%d7%a5/)
* [קקטוסים וסקולנטים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)

# תוצאות חיפוש: "מונסטרה"

[![](https://lpflowers.co.il/wp-content/uploads/2022/11/84aba_1SPLIT202211SPLIT16153301-255x143.jpg)](https://lpflowers.co.il/product/%d7%a2%d7%a6%d7%99%d7%a5-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%90%d7%a0%d7%a7%d7%99/)

[מונסטרה מאנקי](https://lpflowers.co.il/product/%d7%a2%d7%a6%d7%99%d7%a5-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%90%d7%a0%d7%a7%d7%99/)

₪69

[![](https://lpflowers.co.il/wp-content/uploads/2021/01/d964a_1SPLIT202101SPLIT12230836-255x339.jpeg)](https://lpflowers.co.il/product/%d7%a2%d7%a6%d7%99%d7%a5-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94/)

[עציץ מונסטרה](https://lpflowers.co.il/product/%d7%a2%d7%a6%d7%99%d7%a5-%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94/)

₪120

פרחים - יהודה המכבי 60, ת"א

[03-5464522](tel:03-5464522)

א'-ה' 8:00-20:00 ימי ו' וערבי חג 8:00-16:00

משתלה - יהודה המכבי 44, ת"א

[03-5464522](tel:03-5464522)

א'-ה' 8:00-20:00 ימי ו' וערבי חג 8:00-16:00

סניף כוכב הצפון - מאיר יערי 19, ת"א

[03-6455833](tel:03-6455833)

א'-ה' 8:00-20:00 ימי ו' וערבי חג 8:00-16:00

סניף ר"ג - מנחם בגין 11

[03-5464522](tel:03-5464522)

א'-ה' 10:00-17:30 ימי ו' וערבי חג 8:00-15:00

* [פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
* [צמחים וגינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
* [כלים ומתנות](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
* [סדנאות 1](https://lpflowers.co.il/%d7%a1%d7%93%d7%a0%d7%90%d7%95%d7%aa/)
* [יין ושוקולד](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a4%d7%99%d7%a0%d7%95%d7%a7%d7%99%d7%9d/)

* [תקנון האתר](https://lpflowers.co.il/%d7%aa%d7%a7%d7%a0%d7%95%d7%9f-%d7%94%d7%90%d7%aa%d7%a8/)
* [צור קשר](https://lpflowers.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)
* [אודותינו](https://lpflowers.co.il/%d7%90%d7%95%d7%93%d7%95%d7%aa%d7%99%d7%a0%d7%95/)
* [מפת אתר](https://lpflowers.co.il/%d7%9e%d7%a4%d7%aa-%d7%90%d7%aa%d7%a8/)

[[email protected]](/cdn-cgi/l/email-protection#f39f83959f9c84968180dd9e929a9fb3949e929a9fdd909c9e)

אנו מכבדים את סוגי הכרטיסים ![credit cards](https://lpflowers.co.il/wp-content/themes/GoFlower/images/cards.png)

מרכז הזמנות  [03-5464522](tel:03-5464522)

[![iZer](https://lpflowers.co.il/wp-content/themes/GoFlower/images/izer.png) iZer - מערכת לניהול עסקים](https://izer.co.il "iZer - מערכת לניהול עסקים")

* [פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [הזרים שלנו](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%94%d7%96%d7%a8%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
  + [חבילות פרחים](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%97%d7%91%d7%99%d7%9c%d7%95%d7%aa-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [זר כלה וזר לראש](https://lpflowers.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%96%d7%a8-%d7%9b%d7%9c%d7%94-%d7%95%d7%96%d7%a8-%d7%9c%d7%a8%d7%90%d7%a9/)
* [צמחים וגינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
  + [גינון](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%92%d7%99%d7%a0%d7%95%d7%9f/)
  + [צמחים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/)
* [כלים ומתנות](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/)
  + [כלים](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%90%d7%92%d7%a8%d7%98%d7%9c%d7%99%d7%9d/)
  + [יין ושוקולד](https://lpflowers.co.il/product-category/%d7%9b%d7%9c%d7%99%d7%9d-%d7%95%d7%9e%d7%aa%d7%a0%d7%95%d7%aa/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a4%d7%99%d7%a0%d7%95%d7%a7%d7%99%d7%9d/)
* [סדנאות](https://lpflowers.co.il/%d7%a1%d7%93%d7%a0%d7%90%d7%95%d7%aa/)
* [נשפכים ומטפסים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a0%d7%a9%d7%a4%d7%9b%d7%99%d7%9d-%d7%95%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d/)
* [נשפכים ומטפסים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a0%d7%a9%d7%a4%d7%9b%d7%99%d7%9d-%d7%95%d7%9e%d7%98%d7%a4%d7%a1%d7%99%d7%9d/)
* [צמחי בית](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%91%d7%99%d7%aa-%d7%95%d7%9c%d7%9e%d7%a8%d7%a4%d7%a1%d7%aa/)
* [צמחים לגינה ולמרפסת](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%92%d7%99%d7%a0%d7%94-%d7%95%d7%9c%d7%97%d7%95%d7%a5/)
* [קקטוסים וסקולנטים](https://lpflowers.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%95%d7%92%d7%99%d7%a0%d7%95%d7%9f/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d/%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d-%d7%95%d7%a1%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)

[![WhatsApp chat](https://lpflowers.co.il/wp-content/plugins/click-to-chat-for-whatsapp/./new/inc/assets/img/whatsapp-logo.svg)](https://web.whatsapp.com/send?phone=+972-58-4226623&text=)

 