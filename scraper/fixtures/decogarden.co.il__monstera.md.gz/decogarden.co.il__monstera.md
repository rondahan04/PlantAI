[דילוג לתוכן](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#MainContent)

## העגלה שלך ריקה

 המשיכו לקנות 
יש לכם משתמש?

[התחברו](https://shopify.com/91747975468/account?locale=he-IL&buyer_flags=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiI5amQzanAtZWQubXlzaG9waWZ5LmNvbSIsImZsYWdzIjpbXSwiZXhwIjoxNzg5Mzk2ODIwLCJuYmYiOjE3ODg3OTIwMjB9.Yzf1UIAMvLmtVGOC7271YsTgmPaTSFa_bT3J3zTUlVw&region_country=IL) כדי לשלם מהר יותר.

העגלה שלי

טוען...

 הערות מיוחדות להזמנה הערות מיוחדות להזמנה 

## סכום משוער

0.00 ₪

[המשך לתשלום](https://decogarden.co.il/cart)

הצמחים היפים ביותר מהמשתלה ישירות אליכם הביתה!

מבצעים ומחירים שווים!

משלוחים עד הבית

*   [כל הקטגוריות](https://decogarden.co.il/collections)
*   
 צמחים 

 צמחים 
    *   [כל הצמחים](https://decogarden.co.il/collections/%D7%94%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A9%D7%9C%D7%A0%D7%95)
    *   
 צמחים לבית 

 צמחים לבית 
        *   [צמחים שקשה להרוג](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%97%D7%96%D7%A7%D7%99%D7%9D-1)
        *   [צמחים נתלים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%AA%D7%9C%D7%99%D7%9D)
        *   [צמחים פורחים לבית](https://decogarden.co.il/collections/%D7%A4%D7%95%D7%A8%D7%97%D7%99%D7%9D-%D7%A2%D7%9D-%D7%A6%D7%91%D7%A2)
        *   [לאקי במבוק](https://decogarden.co.il/collections/%D7%9C%D7%90%D7%A7%D7%99-%D7%91%D7%9E%D7%91%D7%95%D7%A7)

    *   
 צמחים לגינה 

 צמחים לגינה 
        *   [צמחים מטפסים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9E%D7%98%D7%A4%D7%A1%D7%99%D7%9D)
        *   [צמחי תבלין](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99-%D7%AA%D7%91%D7%9C%D7%99%D7%9F)
        *   [פורחים](https://decogarden.co.il/collections/%D7%A4%D7%95%D7%A8%D7%97%D7%99%D7%9D)
        *   [צמחים נשפכים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%A9%D7%A4%D7%9B%D7%99%D7%9D)
        *   [עצי פרי](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99-%D7%A4%D7%A8%D7%99)
        *   [שיחים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A9%D7%99%D7%97%D7%99%D7%99%D7%9D)
        *   [עונתיים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%95%D7%A0%D7%AA%D7%99%D7%99%D7%9D)

    *   
 זרעים 

 זרעים 
        *   [גינת ירק](https://decogarden.co.il/collections/%D7%92%D7%99%D7%A0%D7%AA-%D7%99%D7%A8%D7%A7)
        *   [זרעי פרחים](https://decogarden.co.il/collections/%D7%96%D7%A8%D7%A2%D7%99-%D7%A4%D7%A8%D7%97%D7%99%D7%9D)

    *   [צמחים טרופיים\נדירים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%98%D7%A8%D7%95%D7%A4%D7%99%D7%99%D7%9D)
    *   [צמחים אקזוטיים ונדירים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%96%D7%95%D7%98%D7%99%D7%99%D7%9D-%D7%95%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D)
    *   [סוקולנטים וקקטוסים](https://decogarden.co.il/collections/%D7%A1%D7%95%D7%A7%D7%95%D7%9C%D7%A0%D7%98%D7%99%D7%9D-%D7%95%D7%A7%D7%A7%D7%98%D7%95%D7%A1%D7%99%D7%9D)

*   
 עציצים לאירוע מארזים ומתנות 

 עציצים לאירוע מארזים ומתנות 
    *   [עציצים עטופים](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99%D7%9D%D7%9C%D7%90%D7%99%D7%A8%D7%95%D7%A2)
    *   [מארזים ומתנות](https://decogarden.co.il/collections/%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%9E%D7%95%D7%9B%D7%A0%D7%95%D7%AA)

*   
 כדים ואדניות 

 כדים ואדניות 
    *   [עציצי פלסטיק](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99-%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%96%D7%95%D7%9C%D7%99%D7%9D)
    *   [כדים מקרמיקה לשולחן](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%9E%D7%A7%D7%A8%D7%9E%D7%99%D7%A7%D7%94-%D7%A2%D7%91%D7%95%D7%93%D7%AA-%D7%99%D7%93)
    *   [כדים גדולים](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%92%D7%93%D7%95%D7%9C%D7%99%D7%9D)
    *   [כדים מפלסטיק ברזילאי](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%9E%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%91%D7%A8%D7%96%D7%99%D7%9C%D7%90%D7%99)
    *   [אדניות גדולות](https://decogarden.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA-%D7%92%D7%93%D7%95%D7%9C%D7%95%D7%AA)
    *   [אדניות מפלסטיק צרפתי](https://decogarden.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA-%D7%9E%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%A6%D7%A8%D7%A4%D7%AA%D7%99)

*   
 אדמה ומצעי שתילה 

 אדמה ומצעי שתילה 
    *   [שקים ואריזות](https://decogarden.co.il/collections/%D7%A9%D7%A7%D7%99%D7%9D)
    *   [בלות בכמויות גדולות](https://decogarden.co.il/collections/%D7%91%D7%9C%D7%95%D7%AA)

*   
 דשא סינטטי וגדרות במבוק 

 דשא סינטטי וגדרות במבוק 
    *   [דשא סינטטי](https://decogarden.co.il/collections/%D7%93%D7%A9%D7%90-%D7%A1%D7%99%D7%A0%D7%98%D7%98%D7%99)
    *   [גדרות במבוק](https://decogarden.co.il/collections/%D7%92%D7%93%D7%A8%D7%95%D7%AA)

*   
 מוצרי נוי ואביזרי גינון 

 מוצרי נוי ואביזרי גינון 
    *   [מוצרי נוי](https://decogarden.co.il/collections/%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%A0%D7%95%D7%99-%D7%9C%D7%92%D7%99%D7%A0%D7%94)
    *   [אביזרי גינון](https://decogarden.co.il/collections/%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%92%D7%99%D7%A0%D7%95%D7%9F)
    *   [חלוקי נחל לגינה](https://decogarden.co.il/collections/%D7%97%D7%9C%D7%95%D7%A7%D7%99-%D7%A0%D7%97%D7%9C-%D7%9C%D7%92%D7%99%D7%A0%D7%94)

*   
 חומרי דישון והדברה 

 חומרי דישון והדברה 
    *   [חומרי דישון](https://decogarden.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%93%D7%99%D7%A9%D7%95%D7%9F)
    *   [חומרי הדברה](https://decogarden.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94)

*   [הקמת גינה](https://decogarden.co.il/pages/%D7%A2%D7%99%D7%A6%D7%95%D7%91-%D7%92%D7%99%D7%A0%D7%95%D7%AA-%D7%A2%D7%9D-%D7%92%D7%A0%D7%9F-%D7%9E%D7%A7%D7%A6%D7%95%D7%A2%D7%99-%D7%91%D7%9E%D7%97%D7%99%D7%A8-%D7%A9%D7%9C-%D7%9E%D7%A9%D7%AA%D7%9C%D7%94)
*   [מערכות השקיה אוטומטיות ללא צורך בחיבור לנקודת מים](https://decogarden.co.il/collections/%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%94%D7%A9%D7%A7%D7%99%D7%94-%D7%90%D7%95%D7%98%D7%95%D7%9E%D7%98%D7%99%D7%95%D7%AA)

[התחברות](https://shopify.com/91747975468/account?locale=he-IL&buyer_flags=eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiI5amQzanAtZWQubXlzaG9waWZ5LmNvbSIsImZsYWdzIjpbXSwiZXhwIjoxNzg5Mzk2ODIwLCJuYmYiOjE3ODg3OTIwMjB9.Yzf1UIAMvLmtVGOC7271YsTgmPaTSFa_bT3J3zTUlVw&region_country=IL)

## שפה

*   [עברית](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)
*   [English](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)
*   [Русский](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)

*   [Facebook](https://www.facebook.com/share/1CUQbcdhie/?mibextid=wwXIfr)
*   [Instagram](https://www.instagram.com/decogarden.co.il?igsh=MW12eXFidWh5em5tNQ==)
*   [TikTok](https://www.tiktok.com/@decogarden.co.il)

[![Image 1: Deco Garden logo with green and red text on a white background](https://decogarden.co.il/cdn/shop/files/2000_x_2000.png?v=1762899199&width=600) Deco garden](https://decogarden.co.il/)
*   [🏷️ כל הקטגוריות](https://decogarden.co.il/collections)
*   
🌿 צמחים

    *   [כל הצמחים](https://decogarden.co.il/collections/%D7%94%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A9%D7%9C%D7%A0%D7%95)
    *   [צמחים לבית](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9C%D7%91%D7%99%D7%AA)
        *   [צמחים שקשה להרוג](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%97%D7%96%D7%A7%D7%99%D7%9D-1)
        *   [צמחים נתלים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%AA%D7%9C%D7%99%D7%9D)
        *   [צמחים פורחים לבית](https://decogarden.co.il/collections/%D7%A4%D7%95%D7%A8%D7%97%D7%99%D7%9D-%D7%A2%D7%9D-%D7%A6%D7%91%D7%A2)
        *   [לאקי במבוק](https://decogarden.co.il/collections/%D7%9C%D7%90%D7%A7%D7%99-%D7%91%D7%9E%D7%91%D7%95%D7%A7)

    *   [צמחים לגינה](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9C%D7%92%D7%99%D7%A0%D7%94)
        *   [צמחים מטפסים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9E%D7%98%D7%A4%D7%A1%D7%99%D7%9D)
        *   [צמחי תבלין](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99-%D7%AA%D7%91%D7%9C%D7%99%D7%9F)
        *   [פורחים](https://decogarden.co.il/collections/%D7%A4%D7%95%D7%A8%D7%97%D7%99%D7%9D)
        *   [צמחים נשפכים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A0%D7%A9%D7%A4%D7%9B%D7%99%D7%9D)
        *   [עצי פרי](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99-%D7%A4%D7%A8%D7%99)
        *   [שיחים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A9%D7%99%D7%97%D7%99%D7%99%D7%9D)
        *   [עונתיים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%A2%D7%95%D7%A0%D7%AA%D7%99%D7%99%D7%9D)

    *   [זרעים](https://decogarden.co.il/collections/%D7%96%D7%A8%D7%A2%D7%99%D7%9D)
        *   [גינת ירק](https://decogarden.co.il/collections/%D7%92%D7%99%D7%A0%D7%AA-%D7%99%D7%A8%D7%A7)
        *   [זרעי פרחים](https://decogarden.co.il/collections/%D7%96%D7%A8%D7%A2%D7%99-%D7%A4%D7%A8%D7%97%D7%99%D7%9D)

    *   [צמחים טרופיים\נדירים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%98%D7%A8%D7%95%D7%A4%D7%99%D7%99%D7%9D)
    *   [צמחים אקזוטיים ונדירים](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%96%D7%95%D7%98%D7%99%D7%99%D7%9D-%D7%95%D7%A0%D7%93%D7%99%D7%A8%D7%99%D7%9D)
    *   [סוקולנטים וקקטוסים](https://decogarden.co.il/collections/%D7%A1%D7%95%D7%A7%D7%95%D7%9C%D7%A0%D7%98%D7%99%D7%9D-%D7%95%D7%A7%D7%A7%D7%98%D7%95%D7%A1%D7%99%D7%9D)

*   
🎁 עציצים לאירוע מארזים ומתנות

    *   [עציצים עטופים](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99%D7%9D%D7%9C%D7%90%D7%99%D7%A8%D7%95%D7%A2)
    *   [מארזים ומתנות](https://decogarden.co.il/collections/%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%9E%D7%95%D7%9B%D7%A0%D7%95%D7%AA)

*   
🪴 כדים ואדניות

    *   [עציצי פלסטיק](https://decogarden.co.il/collections/%D7%A2%D7%A6%D7%99%D7%A6%D7%99-%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%96%D7%95%D7%9C%D7%99%D7%9D)
    *   [כדים מקרמיקה לשולחן](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%9E%D7%A7%D7%A8%D7%9E%D7%99%D7%A7%D7%94-%D7%A2%D7%91%D7%95%D7%93%D7%AA-%D7%99%D7%93)
    *   [כדים גדולים](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%92%D7%93%D7%95%D7%9C%D7%99%D7%9D)
    *   [כדים מפלסטיק ברזילאי](https://decogarden.co.il/collections/%D7%9B%D7%93%D7%99%D7%9D-%D7%9E%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%91%D7%A8%D7%96%D7%99%D7%9C%D7%90%D7%99)
    *   [אדניות גדולות](https://decogarden.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA-%D7%92%D7%93%D7%95%D7%9C%D7%95%D7%AA)
    *   [אדניות מפלסטיק צרפתי](https://decogarden.co.il/collections/%D7%90%D7%93%D7%A0%D7%99%D7%95%D7%AA-%D7%9E%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%A6%D7%A8%D7%A4%D7%AA%D7%99)

*   
🌱 אדמה ומצעי שתילה

    *   [שקים ואריזות](https://decogarden.co.il/collections/%D7%A9%D7%A7%D7%99%D7%9D)
    *   [בלות בכמויות גדולות](https://decogarden.co.il/collections/%D7%91%D7%9C%D7%95%D7%AA)

*   
🌾 דשא סינטטי וגדרות במבוק

    *   [דשא סינטטי](https://decogarden.co.il/collections/%D7%93%D7%A9%D7%90-%D7%A1%D7%99%D7%A0%D7%98%D7%98%D7%99)
    *   [גדרות במבוק](https://decogarden.co.il/collections/%D7%92%D7%93%D7%A8%D7%95%D7%AA)

*   
✨ מוצרי נוי ואביזרי גינון

    *   [מוצרי נוי](https://decogarden.co.il/collections/%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%A0%D7%95%D7%99-%D7%9C%D7%92%D7%99%D7%A0%D7%94)
    *   [אביזרי גינון](https://decogarden.co.il/collections/%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%92%D7%99%D7%A0%D7%95%D7%9F)
    *   [חלוקי נחל לגינה](https://decogarden.co.il/collections/%D7%97%D7%9C%D7%95%D7%A7%D7%99-%D7%A0%D7%97%D7%9C-%D7%9C%D7%92%D7%99%D7%A0%D7%94)

*   
🧪 חומרי דישון והדברה

    *   [חומרי דישון](https://decogarden.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%93%D7%99%D7%A9%D7%95%D7%9F)
    *   [חומרי הדברה](https://decogarden.co.il/collections/%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94)

*   [🏡 הקמת גינה](https://decogarden.co.il/pages/%D7%A2%D7%99%D7%A6%D7%95%D7%91-%D7%92%D7%99%D7%A0%D7%95%D7%AA-%D7%A2%D7%9D-%D7%92%D7%A0%D7%9F-%D7%9E%D7%A7%D7%A6%D7%95%D7%A2%D7%99-%D7%91%D7%9E%D7%97%D7%99%D7%A8-%D7%A9%D7%9C-%D7%9E%D7%A9%D7%AA%D7%9C%D7%94)
*   [💧 מערכות השקיה אוטומטיות ללא צורך בחיבור לנקודת מים](https://decogarden.co.il/collections/%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%94%D7%A9%D7%A7%D7%99%D7%94-%D7%90%D7%95%D7%98%D7%95%D7%9E%D7%98%D7%99%D7%95%D7%AA)

## שפה

*   [עברית](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)
*   [English](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)
*   [Русский](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)

חיפוש[התחברות](https://decogarden.co.il/account)[עגלת קניות](https://decogarden.co.il/cart)

×

חפש מוצרים, קטגוריות...

### מוצרים קשורים

[ראה הכל](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94#)

### קטגוריות

[ראה הכל](https://decogarden.co.il/collections)

# תוצאות חיפוש

חיפוש 

## סינון:

מחיר

המחיר הגבוה ביותר הוא 440.00 ₪[איפוס](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

₪

מ 

₪

עד 

[הסר הכל](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&options%5Bprefix%5D=last&sort_by=relevance)

## מיון לפי:

## 29 תוצאות

סינון ומיון סינון 

## סינון ומיון

## סינון

29 תוצאות

מחיר

 מחיר 
המחיר הגבוה ביותר הוא 440.00 ₪

₪

מ 

₪

עד 

[ניקוי](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94) החל 

מיון לפי: 

[הסר הכל](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&options%5Bprefix%5D=last&sort_by=relevance) החל 

[הסר הכל](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94&options%5Bprefix%5D=last&sort_by=relevance)

## 29 תוצאות

![Image 2](blob:http://localhost/c65e67a540d3852b679673b9993cc5ca)_טוען עוד צמחים 💚_

*   ![Image 3: צמח מונסטרה עם עלים ירוקים גדולים ברקע של משתלה](https://decogarden.co.il/cdn/shop/files/ee3542ef78998db2a281260d51e27fe1.webp?v=1774117563&width=533)  ### [מונסטרה קוטר עציץ 24 ס"מ (10 ליטר) (רב שנתי לבית)](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A7%D7%95%D7%98%D7%A8-%D7%A2%D7%A6%D7%99%D7%A5-24-%D7%A1%D7%9E-10-%D7%9C%D7%99%D7%98%D7%A8-%D7%A8%D7%91-%D7%A9%D7%A0%D7%AA%D7%99-%D7%9C%D7%91%D7%99%D7%AA?_pos=1&_sid=c5d54f60d&_ss=r)    ### [מונסטרה קוטר עציץ 24 ס"מ (10 ליטר) (רב שנתי לבית)](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%A7%D7%95%D7%98%D7%A8-%D7%A2%D7%A6%D7%99%D7%A5-24-%D7%A1%D7%9E-10-%D7%9C%D7%99%D7%98%D7%A8-%D7%A8%D7%91-%D7%A9%D7%A0%D7%AA%D7%99-%D7%9C%D7%91%D7%99%D7%AA?_pos=1&_sid=c5d54f60d&_ss=r)

מחיר רגיל 175.00 ₪  מחיר רגיל מחיר מבצע 175.00 ₪  מחיר יחידה/לכל          
*   ![Image 4: מונסטרה מאנקי ](https://decogarden.co.il/cdn/shop/files/abe232b27317f0a0045b37a40beaf3c8.webp?v=1777904399&width=533)  ### [מונסטרה מאנקי עציץ 3 ליטר](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%95%D7%A0%D7%A7%D7%99-%D7%A8%D7%91-%D7%A9%D7%A0%D7%AA%D7%99-%D7%9C%D7%91%D7%99%D7%AA?_pos=2&_sid=c5d54f60d&_ss=r)    ### [מונסטרה מאנקי עציץ 3 ליטר](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%95%D7%A0%D7%A7%D7%99-%D7%A8%D7%91-%D7%A9%D7%A0%D7%AA%D7%99-%D7%9C%D7%91%D7%99%D7%AA?_pos=2&_sid=c5d54f60d&_ss=r)

מחיר רגיל 105.00 ₪  מחיר רגיל מחיר מבצע 105.00 ₪  מחיר יחידה/לכל          
*   ![Image 5: מונסטרה דוביה על מקל קוקוס](https://decogarden.co.il/cdn/shop/files/afb5079acfbfc7ed4fdbce554f87468c.webp?v=1779452699&width=533)  ### [מונסטרה דוביה קוטר עציץ 20 ס"מ (6 ליטר)](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%93%D7%95%D7%91%D7%99%D7%94?_pos=3&_sid=c5d54f60d&_ss=r)    ### [מונסטרה דוביה קוטר עציץ 20 ס"מ (6 ליטר)](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%93%D7%95%D7%91%D7%99%D7%94?_pos=3&_sid=c5d54f60d&_ss=r)

מחיר רגיל 200.00 ₪  מחיר רגיל מחיר מבצע 200.00 ₪  מחיר יחידה/לכל          
*   ![Image 6: מונסטרה מינימה קוטר עציץ 18 ס"מ](https://decogarden.co.il/cdn/shop/files/47f882e3e0c8466846f402e5d8a5c80c.webp?v=1781445445&width=533)  ### [מונסטרה מינימה קוטר עציץ 18 ס"מ](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%99%D7%A0%D7%99%D7%9E%D7%94?_pos=4&_sid=c5d54f60d&_ss=r)    ### [מונסטרה מינימה קוטר עציץ 18 ס"מ](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%99%D7%A0%D7%99%D7%9E%D7%94?_pos=4&_sid=c5d54f60d&_ss=r)

מחיר רגיל 159.00 ₪  מחיר רגיל מחיר מבצע 159.00 ₪  מחיר יחידה/לכל          
*   ![Image 7: מונסטרה תאי על רקע של משתלה](https://decogarden.co.il/cdn/shop/files/809dda5532a4cdb971232138be4023a5.webp?v=1778580964&width=533)  ### [מונסטרה תאי קוטר עציץ 12 ס"מ](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%AA%D7%90%D7%99?_pos=5&_sid=c5d54f60d&_ss=r)    ### [מונסטרה תאי קוטר עציץ 12 ס"מ](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%AA%D7%90%D7%99?_pos=5&_sid=c5d54f60d&_ss=r)

מחיר רגיל 140.00 ₪  מחיר רגיל מחיר מבצע 140.00 ₪  מחיר יחידה/לכל          
*   ![Image 8: מונסטרה אלבו גדולה עם עלים ירוקים ועלים לבנים ברקע של משתלה](https://decogarden.co.il/cdn/shop/files/4_45d9226c-01c3-4d47-8c5f-8b812df0d371.webp?v=1781438927&width=533)  ### [מונסטרה אלבו עציץ 4 ליטר](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%9C%D7%91%D7%95-%D7%92%D7%93%D7%95%D7%9C%D7%94?_pos=6&_sid=c5d54f60d&_ss=r)    ### [מונסטרה אלבו עציץ 4 ליטר](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%90%D7%9C%D7%91%D7%95-%D7%92%D7%93%D7%95%D7%9C%D7%94?_pos=6&_sid=c5d54f60d&_ss=r)

מחיר רגיל 339.00 ₪  מחיר רגיל מחיר מבצע 339.00 ₪  מחיר יחידה/לכל          
*   ![Image 9: מקל מוס](https://decogarden.co.il/cdn/shop/files/D7_9E_D7_95_D7_A1-min-scaled.jpg?v=1750325818&width=533)  ### [מקל קוקוס](https://decogarden.co.il/products/%D7%9E%D7%A7%D7%9C-%D7%9E%D7%95%D7%A1-1?_pos=7&_sid=c5d54f60d&_ss=r)    ### [מקל קוקוס](https://decogarden.co.il/products/%D7%9E%D7%A7%D7%9C-%D7%9E%D7%95%D7%A1-1?_pos=7&_sid=c5d54f60d&_ss=r)

מחיר רגיל 21.00 ₪  מחיר רגיל מחיר מבצע 21.00 ₪  מחיר יחידה/לכל          
*   ![Image 10: תערובת לארואידים בשק 30 ליטר של מותג דשנית](https://decogarden.co.il/cdn/shop/files/proffesional_aroidim-mix-30L-copy-Photoroom.webp?v=1771229464&width=533)  ### [תערובת לארואידים 30 ליטר דשנית](https://decogarden.co.il/products/%D7%AA%D7%A2%D7%A8%D7%95%D7%91%D7%AA-%D7%9C%D7%90%D7%A8%D7%95%D7%90%D7%99%D7%93%D7%99%D7%9D?_pos=8&_sid=c5d54f60d&_ss=r)    ### [תערובת לארואידים 30 ליטר דשנית](https://decogarden.co.il/products/%D7%AA%D7%A2%D7%A8%D7%95%D7%91%D7%AA-%D7%9C%D7%90%D7%A8%D7%95%D7%90%D7%99%D7%93%D7%99%D7%9D?_pos=8&_sid=c5d54f60d&_ss=r)

מחיר רגיל 70.00 ₪  מחיר רגיל מחיר מבצע 70.00 ₪  מחיר יחידה/לכל          
*   ![Image 11: פרלייט](https://decogarden.co.il/cdn/shop/files/4_3620a5f3-fcc1-40dc-9c3e-ec7d5abc6725.png?v=1778687106&width=533)  ### [פרלייט](https://decogarden.co.il/products/%D7%A4%D7%A8%D7%9C%D7%99%D7%99%D7%98-100-%D7%9C%D7%99%D7%98%D7%A8?_pos=9&_sid=c5d54f60d&_ss=r)    ### [פרלייט](https://decogarden.co.il/products/%D7%A4%D7%A8%D7%9C%D7%99%D7%99%D7%98-100-%D7%9C%D7%99%D7%98%D7%A8?_pos=9&_sid=c5d54f60d&_ss=r)

מחיר רגיל החל מ-12.90 ₪  מחיר רגיל מחיר מבצע החל מ-12.90 ₪  מחיר יחידה/לכל          
*   ![Image 12: מורן החורש](https://decogarden.co.il/cdn/shop/files/D7_9E_D7_95_D7_A8_D7_9F-_D7_94_D7_97_D7_95_D7_A8_D7_A9_53e87001-32bb-4750-bdc1-300f0320f01c.jpg?v=1750325145&width=533)  ### [מורן החורש רב שנתי לגינה](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A8%D7%9F-%D7%94%D7%97%D7%95%D7%A8%D7%A9-%D7%A7%D7%95%D7%98%D7%A8-%D7%A2%D7%A6%D7%99%D7%A5-24-%D7%A1%D7%9E-10-%D7%9C%D7%99%D7%98%D7%A8-%D7%A8%D7%91-%D7%A9%D7%A0%D7%AA%D7%99-%D7%9C%D7%92%D7%99%D7%A0%D7%94?_pos=10&_sid=c5d54f60d&_ss=r)    ### [מורן החורש רב שנתי לגינה](https://decogarden.co.il/products/%D7%9E%D7%95%D7%A8%D7%9F-%D7%94%D7%97%D7%95%D7%A8%D7%A9-%D7%A7%D7%95%D7%98%D7%A8-%D7%A2%D7%A6%D7%99%D7%A5-24-%D7%A1%D7%9E-10-%D7%9C%D7%99%D7%98%D7%A8-%D7%A8%D7%91-%D7%A9%D7%A0%D7%AA%D7%99-%D7%9C%D7%92%D7%99%D7%A0%D7%94?_pos=10&_sid=c5d54f60d&_ss=r)

מחיר רגיל החל מ-26.00 ₪  מחיר רגיל מחיר מבצע החל מ-26.00 ₪  מחיר יחידה/לכל          
*   ![Image 13: אוסמוקוט דשן לגינה ולבית פעיל 6 חודשים](https://decogarden.co.il/cdn/shop/files/p101_new.png?v=1785730151&width=533)  ### [אוסמוקוט דשן לגינה ולבית פעיל 6 חודשים](https://decogarden.co.il/products/%D7%90%D7%95%D7%A1%D7%9E%D7%95%D7%A7%D7%95%D7%98-%D7%93%D7%A9%D7%9F-%D7%9C%D7%92%D7%99%D7%A0%D7%94-%D7%95%D7%9C%D7%91%D7%99%D7%AA-%D7%A4%D7%A2%D7%99%D7%9C-6-%D7%97%D7%95%D7%93%D7%A9%D7%99%D7%9D-1-%D7%A7-%D7%92?_pos=11&_sid=c5d54f60d&_ss=r)    ### [אוסמוקוט דשן לגינה ולבית פעיל 6 חודשים](https://decogarden.co.il/products/%D7%90%D7%95%D7%A1%D7%9E%D7%95%D7%A7%D7%95%D7%98-%D7%93%D7%A9%D7%9F-%D7%9C%D7%92%D7%99%D7%A0%D7%94-%D7%95%D7%9C%D7%91%D7%99%D7%AA-%D7%A4%D7%A2%D7%99%D7%9C-6-%D7%97%D7%95%D7%93%D7%A9%D7%99%D7%9D-1-%D7%A7-%D7%92?_pos=11&_sid=c5d54f60d&_ss=r)

מחיר רגיל החל מ-65.00 ₪  מחיר רגיל מחיר מבצע החל מ-65.00 ₪  מחיר יחידה/לכל          
*   ![Image 14: שקית ורמיקוליט 3](https://decogarden.co.il/cdn/shop/files/1_568af716-bd74-4cbc-83f0-ea25497022ca.png?v=1779432683&width=533)  ### [ורמיקוליט 3 - 10 ליטר](https://decogarden.co.il/products/%D7%95%D7%A8%D7%9E%D7%99%D7%A7%D7%95%D7%9C%D7%99%D7%98-3?_pos=12&_sid=c5d54f60d&_ss=r)    ### [ורמיקוליט 3 - 10 ליטר](https://decogarden.co.il/products/%D7%95%D7%A8%D7%9E%D7%99%D7%A7%D7%95%D7%9C%D7%99%D7%98-3?_pos=12&_sid=c5d54f60d&_ss=r)

מחיר רגיל 36.00 ₪  מחיר רגיל מחיר מבצע 36.00 ₪  מחיר יחידה/לכל          
*   ![Image 15: דשן תולעים אדומות ביו הומוס דשן אורגני 25 ליטר](https://decogarden.co.il/cdn/shop/files/bio-humus_25L-copy-convert.io_-1200x1200.jpg?v=1772722755&width=533)  ### [דשן תולעים אדומות ביו הומוס דשן אורגני 25 ליטר](https://decogarden.co.il/products/%D7%91%D7%99%D7%95-%D7%94%D7%95%D7%9E%D7%95%D7%A1-%D7%93%D7%A9%D7%9F-%D7%90%D7%95%D7%A8%D7%92%D7%A0%D7%99-25-%D7%9C%D7%99%D7%98%D7%A8?_pos=13&_sid=c5d54f60d&_ss=r)    ### [דשן תולעים אדומות ביו הומוס דשן אורגני 25 ליטר](https://decogarden.co.il/products/%D7%91%D7%99%D7%95-%D7%94%D7%95%D7%9E%D7%95%D7%A1-%D7%93%D7%A9%D7%9F-%D7%90%D7%95%D7%A8%D7%92%D7%A0%D7%99-25-%D7%9C%D7%99%D7%98%D7%A8?_pos=13&_sid=c5d54f60d&_ss=r)

מחיר רגיל 48.00 ₪  מחיר רגיל מחיר מבצע 48.00 ₪  מחיר יחידה/לכל          
*   ![Image 16: כד צילינדר אפור](https://decogarden.co.il/cdn/shop/files/IMG_2130-1-e1684336530855_bc076d54-3427-4f81-9130-afb2e1f95b39.jpg?v=1750324917&width=533)  ### [כד צילינדר חלק](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%A6%D7%99%D7%9C%D7%99%D7%A0%D7%93%D7%A8-%D7%A7%D7%95%D7%98%D7%A8-24-%D7%A1-%D7%9E-%D7%90%D7%A4%D7%95%D7%A8-10-%D7%9C%D7%99%D7%98%D7%A8?_pos=14&_sid=c5d54f60d&_ss=r)    ### [כד צילינדר חלק](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%A6%D7%99%D7%9C%D7%99%D7%A0%D7%93%D7%A8-%D7%A7%D7%95%D7%98%D7%A8-24-%D7%A1-%D7%9E-%D7%90%D7%A4%D7%95%D7%A8-10-%D7%9C%D7%99%D7%98%D7%A8?_pos=14&_sid=c5d54f60d&_ss=r)

מחיר רגיל החל מ-18.00 ₪  מחיר רגיל מחיר מבצע החל מ-18.00 ₪  מחיר יחידה/לכל          
*   ![Image 17: כד יהלום אפור](https://decogarden.co.il/cdn/shop/files/D7_9B_D7_93-_D7_99_D7_94_D7_9C_D7_95_D7_9D-_D7_90_D7_A4_D7_95_D7_A8-e1684335953724_1b6fdb85-bbb0-4df6-8a55-7637a2002eb0.jpg?v=1750324909&width=533)  ### [💎כד פסי יהלום](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%99%D7%94%D7%9C%D7%95%D7%9D-%D7%A7%D7%98%D7%A0%D7%98%D7%9F-%D7%9C%D7%91%D7%9F?_pos=15&_sid=c5d54f60d&_ss=r)    ### [💎כד פסי יהלום](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%99%D7%94%D7%9C%D7%95%D7%9D-%D7%A7%D7%98%D7%A0%D7%98%D7%9F-%D7%9C%D7%91%D7%9F?_pos=15&_sid=c5d54f60d&_ss=r)

מחיר רגיל החל מ-17.00 ₪  מחיר רגיל מחיר מבצע החל מ-17.00 ₪  מחיר יחידה/לכל          
*   ![Image 18: JAPI עציץ עגול עינב](https://decogarden.co.il/cdn/shop/files/ChatGPT_Image_May_22_2026_05_26_12_PM.png?v=1779515466&width=533)  ### [JAPI עציץ עגול עינב](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%91%D7%A8%D7%96%D7%99%D7%9C%D7%99%D7%90%D7%99-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=16&_sid=c5d54f60d&_ss=r)    ### [JAPI עציץ עגול עינב](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%A4%D7%9C%D7%A1%D7%98%D7%99%D7%A7-%D7%91%D7%A8%D7%96%D7%99%D7%9C%D7%99%D7%90%D7%99-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99?_pos=16&_sid=c5d54f60d&_ss=r)

מחיר רגיל החל מ-110.00 ₪  מחיר רגיל מחיר מבצע החל מ-110.00 ₪  מחיר יחידה/לכל          
*   ![Image 19: ביו ג'ל דשן אצות ים בבקבוק](https://decogarden.co.il/cdn/shop/files/24.png?v=1772721562&width=533)  ### [ביו ג'ל דשן אצות](https://decogarden.co.il/products/%D7%91%D7%99%D7%95-%D7%92%D7%9C-%D7%93%D7%A9%D7%9F-%D7%90%D7%A6%D7%95%D7%AA?_pos=17&_sid=c5d54f60d&_ss=r)    ### [ביו ג'ל דשן אצות](https://decogarden.co.il/products/%D7%91%D7%99%D7%95-%D7%92%D7%9C-%D7%93%D7%A9%D7%9F-%D7%90%D7%A6%D7%95%D7%AA?_pos=17&_sid=c5d54f60d&_ss=r)

מחיר רגיל 48.00 ₪  מחיר רגיל מחיר מבצע 48.00 ₪  מחיר יחידה/לכל          
*   ![Image 20: כד שיש](https://decogarden.co.il/cdn/shop/files/D7_A9_D7_99_D7_A9-e1684336281188.jpg?v=1750324910&width=533)  ### [כד שיש](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%A9%D7%99%D7%A9-%D7%A7%D7%95%D7%98%D7%A8-%D7%A2%D7%A6%D7%99%D7%A5-12-%D7%A1%D7%9E?_pos=18&_sid=c5d54f60d&_ss=r)    ### [כד שיש](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%A9%D7%99%D7%A9-%D7%A7%D7%95%D7%98%D7%A8-%D7%A2%D7%A6%D7%99%D7%A5-12-%D7%A1%D7%9E?_pos=18&_sid=c5d54f60d&_ss=r)

מחיר רגיל החל מ-17.00 ₪  מחיר רגיל מחיר מבצע החל מ-17.00 ₪  מחיר יחידה/לכל          
*   ![Image 21: שפריצר לצמחים](https://decogarden.co.il/cdn/shop/files/p431_new.jpg?v=1785729966&width=533)  ### [שפריצר](https://decogarden.co.il/products/%D7%A9%D7%A4%D7%A8%D7%99%D7%A6%D7%A8-%D7%9C%D7%A6%D7%9E%D7%97%D7%99%D7%9D?_pos=19&_sid=c5d54f60d&_ss=r)    ### [שפריצר](https://decogarden.co.il/products/%D7%A9%D7%A4%D7%A8%D7%99%D7%A6%D7%A8-%D7%9C%D7%A6%D7%9E%D7%97%D7%99%D7%9D?_pos=19&_sid=c5d54f60d&_ss=r)

מחיר רגיל 15.00 ₪  מחיר רגיל מחיר מבצע 15.00 ₪  מחיר יחידה/לכל          
*   ![Image 22: כד "מיוחד" אפור](https://decogarden.co.il/cdn/shop/files/D7_9B_D7_93-_D7_9E_D7_99_D7_95_D7_97_D7_93-_D7_90_D7_A4_D7_95_D7_A8-e1684336073935_9e94ba11-0ee0-42b0-a154-6d6c688391e9.jpg?v=1750324917&width=533)  ### [כד יהלום הפוך קרמיקה כפולה](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%99%D7%94%D7%9C%D7%95%D7%9D-%D7%94%D7%A4%D7%95%D7%9A-%D7%A7%D7%A8%D7%9E%D7%99%D7%A7%D7%94-%D7%9B%D7%A4%D7%95%D7%9C%D7%94-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99-%D7%9C%D7%91%D7%9F?_pos=20&_sid=c5d54f60d&_ss=r)    ### [כד יהלום הפוך קרמיקה כפולה](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%99%D7%94%D7%9C%D7%95%D7%9D-%D7%94%D7%A4%D7%95%D7%9A-%D7%A7%D7%A8%D7%9E%D7%99%D7%A7%D7%94-%D7%9B%D7%A4%D7%95%D7%9C%D7%94-%D7%91%D7%99%D7%A0%D7%95%D7%A0%D7%99-%D7%9C%D7%91%D7%9F?_pos=20&_sid=c5d54f60d&_ss=r)

מחיר רגיל החל מ-28.00 ₪  מחיר רגיל מחיר מבצע החל מ-28.00 ₪  מחיר יחידה/לכל          
*   ![Image 23: כד משושה עם צמח](https://decogarden.co.il/cdn/shop/files/D7_9B_D7_93-_D7_9E_D7_A9_D7_95_D7_A9_D7_94-_D7_A2_D7_9D-_D7_A6_D7_9E_D7_97-scaled_17291422-1dc1-48df-a5d1-694ad50b5124.webp?v=1735941241&width=533)  ### [כד משושה לבן קוטר 38 גובה 55 ס״מ](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%9E%D7%A9%D7%95%D7%A9%D7%94-%D7%9C%D7%91%D7%9F-%D7%A7%D7%95%D7%98%D7%A8-38-%D7%92%D7%95%D7%91%D7%94-55-%D7%A1-%D7%9E?_pos=21&_sid=c5d54f60d&_ss=r)    ### [כד משושה לבן קוטר 38 גובה 55 ס״מ](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%9E%D7%A9%D7%95%D7%A9%D7%94-%D7%9C%D7%91%D7%9F-%D7%A7%D7%95%D7%98%D7%A8-38-%D7%92%D7%95%D7%91%D7%94-55-%D7%A1-%D7%9E?_pos=21&_sid=c5d54f60d&_ss=r)

מחיר רגיל 180.00 ₪  מחיר רגיל מחיר מבצע 180.00 ₪  מחיר יחידה/לכל          
*   ![Image 24: כד משושה עם צמח](https://decogarden.co.il/cdn/shop/files/D7_9B_D7_93-_D7_9E_D7_A9_D7_95_D7_A9_D7_94-_D7_A2_D7_9D-_D7_A6_D7_9E_D7_97-scaled.webp?v=1735941244&width=533)  ### [כד משושה לבן קוטר 28 גובה 53 ס״מ](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%9E%D7%A9%D7%95%D7%A9%D7%94-%D7%9C%D7%91%D7%9F-%D7%A7%D7%95%D7%98%D7%A8-28-%D7%92%D7%95%D7%91%D7%94-53-%D7%A1-%D7%9E?_pos=22&_sid=c5d54f60d&_ss=r)    ### [כד משושה לבן קוטר 28 גובה 53 ס״מ](https://decogarden.co.il/products/%D7%9B%D7%93-%D7%9E%D7%A9%D7%95%D7%A9%D7%94-%D7%9C%D7%91%D7%9F-%D7%A7%D7%95%D7%98%D7%A8-28-%D7%92%D7%95%D7%91%D7%94-53-%D7%A1-%D7%9E?_pos=22&_sid=c5d54f60d&_ss=r)

מחיר רגיל 99.00 ₪  מחיר רגיל מחיר מבצע 99.00 ₪  מחיר יחידה/לכל          
*   ![Image 25: המדריך המלא לטיפול במונסטרה מינימה](https://decogarden.co.il/cdn/shop/articles/ChatGPT_Image_Jun_14_2026_05_05_00_PM-6427625.png?v=1781503995&width=533)  ### [המדריך המלא לטיפול במונסטרה מינימה](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%9C%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%99%D7%A0%D7%99%D7%9E%D7%94?_pos=23&_sid=c5d54f60d&_ss=r)

14 ביוני 2026  בלוג   ### [המדריך המלא לטיפול במונסטרה מינימה](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%9C%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%99%D7%A0%D7%99%D7%9E%D7%94?_pos=23&_sid=c5d54f60d&_ss=r)

14 ביוני 2026  בלוג    
*   ![Image 26: 🌿 המדריך לטיפול במונסטרה – מה המחיר ואיפה קונים?](https://decogarden.co.il/cdn/shop/articles/u1974784376_Close-up_of_Monstera_leaves_on_a_dark_green_backgro_1375040c-752d-46a3-b07b-f050ad6b213f-622133.png?v=1750323904&width=533)  ### [🌿 המדריך לטיפול במונסטרה – מה המחיר ואיפה קונים?](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%F0%9F%8C%BF-%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%9C%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%94-%D7%94%D7%9E%D7%97%D7%99%D7%A8-%D7%95%D7%90%D7%99%D7%A4%D7%94-%D7%A7%D7%95%D7%A0%D7%99%D7%9D?_pos=24&_sid=c5d54f60d&_ss=r)

31 במאי 2025  בלוג   ### [🌿 המדריך לטיפול במונסטרה – מה המחיר ואיפה קונים?](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D/%F0%9F%8C%BF-%D7%94%D7%9E%D7%93%D7%A8%D7%99%D7%9A-%D7%9C%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94-%D7%9E%D7%94-%D7%94%D7%9E%D7%97%D7%99%D7%A8-%D7%95%D7%90%D7%99%D7%A4%D7%94-%D7%A7%D7%95%D7%A0%D7%99%D7%9D?_pos=24&_sid=c5d54f60d&_ss=r)

31 במאי 2025  בלוג    
🚀

Load More

![Image 27](blob:http://localhost/c65e67a540d3852b679673b9993cc5ca)_טוען עוד צמחים 💚_

*   [1](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)
*   [2](https://decogarden.co.il/search?page=2&q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)
*   [](https://decogarden.co.il/search?page=2&q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

×
## 🎉 מגיעה לך מתנה!

תודה שקנית אצלנו

 לא תודה, אולי בפעם הבאה  הוסף מתנה לעגלה 

המתנה נוספה לעגלה! 🎁

🎁 יש לך מתנה!

יש לך מתנה חינם!

בחר עכשיו

## פרטי קשר

[050-529-8983](tel:0505298983)

[וואטסאפ — מענה מהיר](https://wa.me/972505298983)

[decogarden.co.il@gmail.com](mailto:decogarden.co.il@gmail.com)

שירות לקוחות: ימים א׳–ה׳ 10:00–17:00

רחוב יבנה פינת כנפי נשרים, הרצליה

הגעה למשתלה בתיאום מראש בלבד

## קטגוריות

*   [צמחים לבית](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9C%D7%91%D7%99%D7%AA)
*   [צמחים לגינה](https://decogarden.co.il/collections/%D7%A6%D7%9E%D7%97%D7%99%D7%9D-%D7%9C%D7%92%D7%99%D7%A0%D7%94)
*   [אדמה ומצעי שתילה](https://decogarden.co.il/collections/%D7%AA%D7%A2%D7%A8%D7%95%D7%91%D7%95%D7%AA-%D7%A9%D7%AA%D7%99%D7%9C%D7%94-%D7%95%D7%9E%D7%A6%D7%A2%D7%99-%D7%A9%D7%AA%D7%99%D7%9C%D7%94)
*   [אביזרי גינון](https://decogarden.co.il/collections/%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%92%D7%99%D7%A0%D7%95%D7%9F)
*   [מוצרי נוי לגינה](https://decogarden.co.il/collections/%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%A0%D7%95%D7%99-%D7%9C%D7%92%D7%99%D7%A0%D7%94)

## מידע ושירות

*   [חיפוש חופשי](https://decogarden.co.il/search)
*   [מדריכי טיפול בצמחים](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
*   [בלוג](https://decogarden.co.il/blogs/%D7%91%D7%9C%D7%95%D7%92)
*   [מדריכי צמחים](https://decogarden.co.il/blogs/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%9C-%D7%91%D7%A6%D7%9E%D7%97%D7%99%D7%9D)
*   [צרו קשר](https://decogarden.co.il/pages/contact)
*   [מדיניות אספקת מוצרים](https://decogarden.co.il/policies/shipping-policy)
*   [מדיניות החזרים וביטולים](https://decogarden.co.il/policies/refund-policy)
*   [תקנון](https://decogarden.co.il/policies/terms-of-service)
*   [מדיניות פרטיות](https://decogarden.co.il/policies/privacy-policy)
*   [כל המוצרים](https://decogarden.co.il/collections/random)
*   [הצהרת נגישות](https://decogarden.co.il/pages/%D7%A0%D7%92%D7%99%D7%A9%D7%95%D7%AA)
*   [מועדון הנקודות](https://decogarden.co.il/pages/club)
*   [מנויים עונתיים לגינה](https://decogarden.co.il/pages/subscriptions)
*   [ביטול מנוי](https://decogarden.co.il/pages/subscriptions)

## מידע ומדיניות

*   [ביטול עסקה והחזרים](https://decogarden.co.il/policies/refund-policy)
*   [מדיניות משלוחים](https://decogarden.co.il/policies/shipping-policy)
*   [ביטול מנוי](https://decogarden.co.il/pages/subscriptions)
*   [תקנון האתר](https://decogarden.co.il/policies/terms-of-service)
*   [מדיניות פרטיות](https://decogarden.co.il/policies/privacy-policy)
*   [הצהרת נגישות](https://decogarden.co.il/pages/%D7%A0%D7%92%D7%99%D7%A9%D7%95%D7%AA)

## נרשמים ומקבלים ישר למייל קוד ל-10% הנחה על ההזמנה הראשונה 🎁

 כתובת מייל  

*   [Facebook](https://www.facebook.com/share/1CUQbcdhie/?mibextid=wwXIfr)
*   [Instagram](https://www.instagram.com/decogarden.co.il?igsh=MW12eXFidWh5em5tNQ==)
*   [TikTok](https://www.tiktok.com/@decogarden.co.il)

## דקו גרדן גם במקורות המועדפים של Google

עוד דרך פשוטה למצוא את המדריכים שלנו בזמן הנכון.

אמצעי תשלום

© 2026, [Deco garden](https://decogarden.co.il/)מופעל ע"י

*   בחירת תוצאות נבחרות בעמוד מלא חדש.
*   פותח בחלון חדש.

[](https://api.whatsapp.com/send?phone=972505298983&text=)

בדיקת זמינות משלוח

הכנס את שם העיר או הישוב שלך כדי לבדוק אם אנחנו מגיעים אליך

בדוק

מחפש את הכתובת...

מעולה! אנחנו מגיעים אליך

לביצוע הזמנה לכתובת שלך יש לפנות לשירות בטלפון או בווצאפ 0505298983 ניתן לאסוף מהמשתלה

לא הצלחנו למצוא את הכתובת, נסה שוב

✕

![Image 28: Product image](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

הוסף לסל 🛒[צפייה במוצר](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

✓ נוסף לסל הקניות!

💬

היי אני ארז 🌱 הגנן של דקו גרדן

אני כאן לענות על כל מה שתשאלו

✕

היי! 👋 אני ארז, הגנן של דקו גרדן. אני כאן לעזור לכם למצוא את הצמחים המושלמים לבית או לגינה, להרכיב חבילות בתקציב שלכם, ולעצב את הבית או הגינה שלכם, או סתם לענות על כל שאלה שקשורה לאתר או אלינו, שלחו לי תמונה של המקום ואמליץ אילו מוצרים מתאימים! 📸\n\nבמה נתחיל?

נסו לשאול

🌱 אילו צמחים מתאימים לי? (שאלון מהיר)💰 יש לי תקציב של ____ ש"ח🏡 תעזרו לי לעצב את הגינה/בית שלי🌿 אילו צמחים מתאימים לעונת הסתיו?

![Image 29: preview](https://decogarden.co.il/search?q=%D7%9E%D7%95%D7%A0%D7%A1%D7%98%D7%A8%D7%94)

📸 תמונה מוכנה לשליחה

✕

📷↑

AI-powered assistant • Results may vary

אנו משתמשים בעוגיות (Cookies) לצורך שיפור חוויית הגלישה. המשך שימוש באתר מהווה הסכמה לשימוש בעוגיות ו[למדיניות הפרטיות](https://decogarden.co.il/policies/privacy-policy)