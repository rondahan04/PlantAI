[דלג לתוכן](#content)


[₪0.00  0 עגלת קניות](#)

# תוצאות חיפוש עבור: פותוס

רשימת המינים המלאה

[אבטיח (3)](https://www.ecolution.co.il/species/%d7%90%d7%91%d7%98%d7%99%d7%97/)

[אוסקה חרדל יפני (2)](https://www.ecolution.co.il/species/%d7%90%d7%95%d7%a1%d7%a7%d7%94-%d7%97%d7%a8%d7%93%d7%9c-%d7%99%d7%a4%d7%a0%d7%99/)

[אורגנו (1)](https://www.ecolution.co.il/species/%d7%90%d7%95%d7%a8%d7%92%d7%a0%d7%95/)

[אורוגולה (2)](https://www.ecolution.co.il/species/%d7%90%d7%95%d7%a8%d7%95%d7%92%d7%95%d7%9c%d7%94/)

[אזוב - זעתר (1)](https://www.ecolution.co.il/species/%d7%90%d7%96%d7%95%d7%91-%d7%96%d7%a2%d7%aa%d7%a8/)

[אלפלפא (2)](https://www.ecolution.co.il/species/%d7%90%d7%9c%d7%a4%d7%9c%d7%a4%d7%90/)

[אמנון ותמר (1)](https://www.ecolution.co.il/species/%d7%90%d7%9e%d7%a0%d7%95%d7%9f-%d7%95%d7%aa%d7%9e%d7%a8/)

[אספרגוס (1)](https://www.ecolution.co.il/species/%d7%90%d7%a1%d7%a4%d7%a8%d7%92%d7%95%d7%a1/)

[אפונה (5)](https://www.ecolution.co.il/species/%d7%90%d7%a4%d7%95%d7%a0%d7%94/)

[אפונה ריחנית (1)](https://www.ecolution.co.il/species/%d7%90%d7%a4%d7%95%d7%a0%d7%94-%d7%a8%d7%99%d7%97%d7%a0%d7%99%d7%aa/)

[ארטישוק (1)](https://www.ecolution.co.il/species/%d7%90%d7%a8%d7%98%d7%99%d7%a9%d7%95%d7%a7/)

[בזיליקום (5)](https://www.ecolution.co.il/species/%d7%91%d7%96%d7%99%d7%9c%d7%99%d7%a7%d7%95%d7%9d/)

[במיה (1)](https://www.ecolution.co.il/species/%d7%91%d7%9e%d7%99%d7%94/)

[בצל (3)](https://www.ecolution.co.il/species/%d7%91%d7%a6%d7%9c/)

[ברוקולי (4)](https://www.ecolution.co.il/species/%d7%91%d7%a8%d7%95%d7%a7%d7%95%d7%9c%d7%99/)

[גזר (6)](https://www.ecolution.co.il/species/%d7%92%d7%96%d7%a8/)

[גרגיר הנחלים (1)](https://www.ecolution.co.il/species/%d7%92%d7%a8%d7%92%d7%99%d7%a8-%d7%94%d7%a0%d7%97%d7%9c%d7%99%d7%9d/)

[דלעת (7)](https://www.ecolution.co.il/species/%d7%93%d7%9c%d7%a2%d7%aa/)

[חמניה (4)](https://www.ecolution.co.il/species/%d7%97%d7%9e%d7%a0%d7%99%d7%94/)

[חסה (16)](https://www.ecolution.co.il/species/%d7%97%d7%a1%d7%94/)

[חציל (9)](https://www.ecolution.co.il/species/%d7%97%d7%a6%d7%99%d7%9c/)

[טאט סוי (2)](https://www.ecolution.co.il/species/%d7%98%d7%90%d7%98-%d7%a1%d7%95%d7%99/)

[טראגון מקסיקני (1)](https://www.ecolution.co.il/species/%d7%98%d7%a8%d7%90%d7%92%d7%95%d7%9f-%d7%9e%d7%a7%d7%a1%d7%99%d7%a7%d7%a0%d7%99/)

[כובע הנזיר (1)](https://www.ecolution.co.il/species/%d7%9b%d7%95%d7%91%d7%a2-%d7%94%d7%a0%d7%96%d7%99%d7%a8/)

[כוסברה / גד השדה (2)](https://www.ecolution.co.il/species/%d7%9b%d7%95%d7%a1%d7%91%d7%a8%d7%94-%d7%92%d7%93-%d7%94%d7%a9%d7%93%d7%94/)

[כרוב (7)](https://www.ecolution.co.il/species/%d7%9b%d7%a8%d7%95%d7%91/)

[כרובית (4)](https://www.ecolution.co.il/species/%d7%9b%d7%a8%d7%95%d7%91%d7%99%d7%aa/)

[כרישה / לוף / פרסה (1)](https://www.ecolution.co.il/species/%d7%9b%d7%a8%d7%99%d7%a9%d7%94-%d7%9c%d7%95%d7%a3-%d7%a4%d7%a8%d7%a1%d7%94/)

[לאושטיאן (1)](https://www.ecolution.co.il/species/%d7%9c%d7%90%d7%95%d7%a9%d7%98%d7%99%d7%90%d7%9f/)

[לובליה (1)](https://www.ecolution.co.il/species/%d7%9c%d7%95%d7%91%d7%9c%d7%99%d7%94/)

[לוע הארי (1)](https://www.ecolution.co.il/species/%d7%9c%d7%95%d7%a2-%d7%94%d7%90%d7%a8%d7%99/)

[ליפה (1)](https://www.ecolution.co.il/species/%d7%9c%d7%99%d7%a4%d7%94/)

[לפת (1)](https://www.ecolution.co.il/species/%d7%9c%d7%a4%d7%aa/)

[מיורם (1)](https://www.ecolution.co.il/species/%d7%9e%d7%99%d7%95%d7%a8%d7%9d/)

[מיזונה אדומה (2)](https://www.ecolution.co.il/species/%d7%9e%d7%99%d7%96%d7%95%d7%a0%d7%94-%d7%90%d7%93%d7%95%d7%9e%d7%94/)

[מיזונה ירוקה (2)](https://www.ecolution.co.il/species/%d7%9e%d7%99%d7%96%d7%95%d7%a0%d7%94-%d7%99%d7%a8%d7%95%d7%a7%d7%94/)

[מלוח'יה (1)](https://www.ecolution.co.il/species/%d7%9e%d7%9c%d7%95%d7%97%d7%99%d7%94/)

[מלון (3)](https://www.ecolution.co.il/species/%d7%9e%d7%9c%d7%95%d7%9f/)

[מליסה (1)](https://www.ecolution.co.il/species/%d7%9e%d7%9c%d7%99%d7%a1%d7%94/)

[מלפפון (6)](https://www.ecolution.co.il/species/%d7%9e%d7%9c%d7%a4%d7%a4%d7%95%d7%9f/)

[מנגולד (1)](https://www.ecolution.co.il/species/%d7%9e%d7%a0%d7%92%d7%95%d7%9c%d7%93/)

[מרווה רפואית (1)](https://www.ecolution.co.il/species/%d7%9e%d7%a8%d7%95%d7%95%d7%94-%d7%a8%d7%a4%d7%95%d7%90%d7%99%d7%aa/)

[סויה אדממה (1)](https://www.ecolution.co.il/species/%d7%a1%d7%95%d7%99%d7%94-%d7%90%d7%93%d7%9e%d7%9e%d7%94/)

[סורל (2)](https://www.ecolution.co.il/species/%d7%a1%d7%95%d7%a8%d7%9c/)

[סלסלי כסף (1)](https://www.ecolution.co.il/species/%d7%a1%d7%9c%d7%a1%d7%9c%d7%99-%d7%9b%d7%a1%d7%a3/)

[סלק עלים (2)](https://www.ecolution.co.il/species/%d7%a1%d7%9c%d7%a7-%d7%a2%d7%9c%d7%99%d7%9d/)

[סלק שורש (4)](https://www.ecolution.co.il/species/%d7%a1%d7%9c%d7%a7-%d7%a9%d7%95%d7%a8%d7%a9/)

[סלרי עלים (1)](https://www.ecolution.co.il/species/%d7%a1%d7%9c%d7%a8%d7%99-%d7%a2%d7%9c%d7%99%d7%9d/)

[סלרי שורש (1)](https://www.ecolution.co.il/species/%d7%a1%d7%9c%d7%a8%d7%99-%d7%a9%d7%95%d7%a8%d7%a9/)

[עגבנייה (18)](https://www.ecolution.co.il/species/%d7%a2%d7%92%d7%91%d7%a0%d7%99%d7%99%d7%94/)

[עולש - אנדיב (1)](https://www.ecolution.co.il/species/%d7%a2%d7%95%d7%9c%d7%a9-%d7%90%d7%a0%d7%93%d7%99%d7%91/)

[עירית (2)](https://www.ecolution.co.il/species/%d7%a2%d7%99%d7%a8%d7%99%d7%aa/)

[פאק צ'וי (3)](https://www.ecolution.co.il/species/%d7%a4%d7%90%d7%a7-%d7%a6%d7%95%d7%99/)

[פול (2)](https://www.ecolution.co.il/species/%d7%a4%d7%95%d7%9c/)

[פטרוזיליה עלים (3)](https://www.ecolution.co.il/species/%d7%a4%d7%98%d7%a8%d7%95%d7%96%d7%99%d7%9c%d7%99%d7%94-%d7%a2%d7%9c%d7%99%d7%9d/)

[פטרוזיליה שורש (1)](https://www.ecolution.co.il/species/%d7%a4%d7%98%d7%a8%d7%95%d7%96%d7%99%d7%9c%d7%99%d7%94-%d7%a9%d7%95%d7%a8%d7%a9/)

[פיגם הודי (1)](https://www.ecolution.co.il/species/%d7%a4%d7%99%d7%92%d7%9d-%d7%94%d7%95%d7%93%d7%99/)

[פלפל חריף (9)](https://www.ecolution.co.il/species/%d7%a4%d7%9c%d7%a4%d7%9c-%d7%97%d7%a8%d7%99%d7%a3/)

[פלפל מתוק (11)](https://www.ecolution.co.il/species/%d7%a4%d7%9c%d7%a4%d7%9c-%d7%9e%d7%aa%d7%95%d7%a7/)

[פרחי בר - לקט (1)](https://www.ecolution.co.il/species/%d7%a4%d7%a8%d7%97%d7%99-%d7%91%d7%a8-%d7%9c%d7%a7%d7%98/)

[פרחי חורף (9)](https://www.ecolution.co.il/species/%d7%a4%d7%a8%d7%97%d7%99-%d7%97%d7%95%d7%a8%d7%a3/)

[פרחי קיץ (7)](https://www.ecolution.co.il/species/%d7%a4%d7%a8%d7%97%d7%99-%d7%a7%d7%99%d7%a5/)

[צנון וצנונית (12)](https://www.ecolution.co.il/species/%d7%a6%d7%a0%d7%95%d7%9f-%d7%95%d7%a6%d7%a0%d7%95%d7%a0%d7%99%d7%aa/)

[קולורבי (2)](https://www.ecolution.co.il/species/%d7%a7%d7%95%d7%9c%d7%95%d7%a8%d7%91%d7%99/)

[קייל (4)](https://www.ecolution.co.il/species/%d7%a7%d7%99%d7%99%d7%9c/)

[קישוא (7)](https://www.ecolution.co.il/species/%d7%a7%d7%99%d7%a9%d7%95%d7%90/)

[קלנדולה (1)](https://www.ecolution.co.il/species/%d7%a7%d7%9c%d7%a0%d7%93%d7%95%d7%9c%d7%94/)

[קמומיל (1)](https://www.ecolution.co.il/species/%d7%a7%d7%9e%d7%95%d7%9e%d7%99%d7%9c/)

[רדיצ'יו (1)](https://www.ecolution.co.il/species/%d7%a8%d7%93%d7%99%d7%a6%d7%99%d7%95/)

[רוברב (1)](https://www.ecolution.co.il/species/%d7%a8%d7%95%d7%91%d7%a8%d7%91/)

[רוקט (2)](https://www.ecolution.co.il/species/%d7%a8%d7%95%d7%a7%d7%98/)

[רשד (4)](https://www.ecolution.co.il/species/%d7%a8%d7%a9%d7%93/)

[שומר (2)](https://www.ecolution.co.il/species/%d7%a9%d7%95%d7%9e%d7%a8/)

[שמיר (2)](https://www.ecolution.co.il/species/%d7%a9%d7%9e%d7%99%d7%a8/)

[שעועית (5)](https://www.ecolution.co.il/species/%d7%a9%d7%a2%d7%95%d7%a2%d7%99%d7%aa/)

[תימין - קורנית (1)](https://www.ecolution.co.il/species/%d7%aa%d7%99%d7%9e%d7%99%d7%9f-%d7%a7%d7%95%d7%a8%d7%a0%d7%99%d7%aa/)

[תירס (3)](https://www.ecolution.co.il/species/%d7%aa%d7%99%d7%a8%d7%a1/)

[תרד (3)](https://www.ecolution.co.il/species/%d7%aa%d7%a8%d7%93/)

[סינון](#elementor-action%3Aaction%3Doff_canvas%3Aopen%26settings%3DeyJpZCI6ImJiMGNjNjciLCJkaXNwbGF5TW9kZSI6Im9wZW4ifQ%3D%3D)

[כל המוצרים](https://www.ecolution.co.il/shop/)

[זרעי קיץ](https://www.ecolution.co.il/product-group/summer-seeds/)

[זרעי חורף](https://www.ecolution.co.il/product-group/winter-seeds/)

סוגי צמחים

[זרעים לנבטים](https://www.ecolution.co.il/product-group/sprouting-seeds/)

[עלי סלט בייבי](https://www.ecolution.co.il/product-group/baby-salad/)

[עשבי תיבול](https://www.ecolution.co.il/product-group/herb-seeds/)

[קטניות](https://www.ecolution.co.il/product-group/legume-seeds/)

[זרעי ירקות פרי](https://www.ecolution.co.il/seed-type/fruit-seeds/)

[זרעי ירקות שורש](https://www.ecolution.co.il/seed-type/root-seeds/)

[זרעי פרחים](https://www.ecolution.co.il/seed-type/flower-seeds/)

טיפול ומקור הזרעים

[זרעי האבקה פתוחה \ הרלום \ מורשת](https://www.ecolution.co.il/seed-type/heirloom-seeds/)

[זרעי מכלוא מקצועיים](https://www.ecolution.co.il/seed-type/breeder-seeds/)

[זרעי פרימיום](https://www.ecolution.co.il/seed-type/premium-seeds/)

[זרעים אורגניים](https://www.ecolution.co.il/seed-type/organic-seeds/)

אמצעי גידול

[דשן אורגני](https://www.ecolution.co.il/product-group/organic-fertilizer/)

[הדברה אורגנית](https://www.ecolution.co.il/product-group/organic-pesticide/)

[מוצרים משלימים](https://www.ecolution.co.il/product-group/complementary-products/)

[מצעי גידול](https://www.ecolution.co.il/product-group/growing-media/)

 