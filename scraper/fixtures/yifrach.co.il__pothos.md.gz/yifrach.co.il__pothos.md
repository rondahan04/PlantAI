לכל צמח מחכה בית אוהב

נשמח להתאים בניכם

‏

מכאן תוכלו להזמין צמחים,

עציצים, אדמה, חומרי הדברה ודישון

‏

חדש!

אנחנו בוחרים באופן אישי

את הצמחים הכי רעננים

‏

![](https://www.yifrach.co.il/images/generalSlideshow_image1_id104_rnderfg.jpg?1788792501756)

![](https://www.yifrach.co.il/images/generalSlideshow_image1_id106_rndanOL.jpg?1788792501798)

ברוכים הבאים למשתלה

הכי אופטימית בישראל

‏

- 0
- 1
- 2
- 3

לכל צמח מחכה בית אוהב

נשמח להתאים בניכם

‏

מכאן תוכלו להזמין צמחים,

עציצים, אדמה, חומרי הדברה ודישון

‏

חדש!

אנחנו בוחרים באופן אישי

את הצמחים הכי רעננים

‏

![](https://www.yifrach.co.il/images/generalSlideshow_image2_id104_rndvnan.jpg?1788792501761)

![](https://www.yifrach.co.il/images/generalSlideshow_image2_id106_rndYrTp.jpg?1788792501810)

ברוכים הבאים למשתלה

הכי אופטימית בישראל

‏

- 0
- 1
- 2
- 3

קלתיאה טריו סטארצמח יפיפייה בעל שלושה צבעים בשילוב יוצא דופן.

![](https://www.yifrach.co.il/images/banners_categories_items_image1_id101_rndslgn.jpg?1788792501764)

![](https://www.yifrach.co.il/images/banners_categories_items_image1_id100_rndhail.jpg?1788792501814)

מארז צמחים חזקים במיוחד למתחיליםחמישיית צמחים בטוחה להצלחה

- 0
- 1

[כל בית צריך צמחי בית](https://www.yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=339)

[![](https://www.yifrach.co.il/images/banners_categories_items_image1_id79_rndsbyS.jpg)\\
\\
כל הצמחים שלנו\\
\\
![](https://www.yifrach.co.il/images/System/icons/slide_banners_arrow_left.png)](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5) [![](https://www.yifrach.co.il/images/banners_categories_items_image1_id73_rndsqCK.jpg)\\
\\
צמחים לבית ולמשרד\\
\\
![](https://www.yifrach.co.il/images/System/icons/slide_banners_arrow_left.png)](https://www.yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=339) [![](https://www.yifrach.co.il/images/banners_categories_items_image1_id74_rndkthf.jpg)\\
\\
מארזים מתנות\\
\\
![](https://www.yifrach.co.il/images/System/icons/slide_banners_arrow_left.png)](https://www.yifrach.co.il/store-products.aspx?StoreCategoryId=13&StoreSubCategoryId=374) [![](https://www.yifrach.co.il/images/banners_categories_items_image1_id75_rnd4EbC.jpg)\\
\\
צמחים מיוחדים\\
\\
![](https://www.yifrach.co.il/images/System/icons/slide_banners_arrow_left.png)](https://www.yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=362)

הצמחים המומלצים שלנו

[![אפובליס פרפל סוורד](https://www.yifrach.co.il/images/storeProducts_image1_id1687_rndpkoy_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1687&storeSubCategoryId=339) [אפובליס פרפל סוורד\\
\\
85](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1687&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1687&storeSubCategoryId=339)

[![פילדנדרון וואיט פרינסס](https://www.yifrach.co.il/images/storeProducts_image1_id1622_rndUTbS_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1622&storeSubCategoryId=339) [פילדנדרון וואיט פרינסס\\
\\
95](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1622&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1622&storeSubCategoryId=339)

[![יוקה על גזע](https://www.yifrach.co.il/images/storeProducts_image1_id1656_rndiuau_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1656&storeSubCategoryId=339) [יוקה על גזע\\
\\
60](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1656&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1656&storeSubCategoryId=339)

[![יקינטון ](https://www.yifrach.co.il/images/storeProducts_image1_id102_rnd5XfR_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=102&storeSubCategoryId=364) [יקינטון \\
\\
35](https://www.yifrach.co.il/product-id.aspx?StoreProductId=102&storeSubCategoryId=364)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=102&storeSubCategoryId=364)

[![שפלרה עצית](https://www.yifrach.co.il/images/storeProducts_image1_id63_rnd3n5P_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=63&storeSubCategoryId=339) [שפלרה עצית\\
\\
95](https://www.yifrach.co.il/product-id.aspx?StoreProductId=63&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=63&storeSubCategoryId=339)

[![אגלונמה פלמנגו](https://www.yifrach.co.il/images/storeProducts_image1_id1454_rndG7fx_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1454&storeSubCategoryId=339) [אגלונמה פלמנגו\\
\\
140](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1454&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1454&storeSubCategoryId=339)

[![זמיה קוקוס ירוקה ](https://www.yifrach.co.il/images/storeProducts_image1_id41_rnd0Lz1_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=41&storeSubCategoryId=339) [זמיה קוקוס ירוקה \\
\\
60](https://www.yifrach.co.il/product-id.aspx?StoreProductId=41&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=41&storeSubCategoryId=339)

[![אגלונמה סילבר](https://www.yifrach.co.il/images/storeProducts_image1_id1542_rndJk2W_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1542&storeSubCategoryId=339) [אגלונמה סילבר\\
\\
55](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1542&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1542&storeSubCategoryId=339)

[![דרצנה טורנדו](https://www.yifrach.co.il/images/storeProducts_image1_id1627_rndhU89_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1627&storeSubCategoryId=339) [דרצנה טורנדו\\
\\
55](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1627&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1627&storeSubCategoryId=339)

[![פיקוס בנגאלי](https://www.yifrach.co.il/images/storeProducts_image1_id1650_rndymye_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1650&storeSubCategoryId=339) [פיקוס בנגאלי\\
\\
135](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1650&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1650&storeSubCategoryId=339)

[לעוד צמחים שווים](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5)

[![](https://www.yifrach.co.il/images/storeCategories_image1_id5_rnd0DW2.jpg)צמחים](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=5) [![](https://www.yifrach.co.il/images/storeCategories_image1_id3_rnduSsq.jpg)כלי שתילה](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=3) [![](https://www.yifrach.co.il/images/storeCategories_image1_id14_rnd7Mxa.jpg)דישון הדברה ואביזרים](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=14) [![](https://www.yifrach.co.il/images/storeCategories_image1_id15_rndcTG4.jpg)תערובת שתילה ותוספים](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=15) [![](https://www.yifrach.co.il/images/storeCategories_image1_id13_rndLan4.jpg)מארזים ומתנות](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=13)

[ימים\\
\\
שעות\\
\\
דקות\\
\\
שניות\\
\\
252](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=3)

טעימה מהעציצים שלנו

[![בית עציץ מתכת ](https://www.yifrach.co.il/images/storeProducts_image1_id1562_rndjnEg_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1562&storeSubCategoryId=333) [בית עציץ מתכת \\
\\
65](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1562&storeSubCategoryId=333)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1562&storeSubCategoryId=333)

[![עציץ טרקוטה ](https://www.yifrach.co.il/images/storeProducts_image1_id1620_rndEixf_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1620&storeSubCategoryId=330) [עציץ טרקוטה \\
\\
9](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1620&storeSubCategoryId=330)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1620&storeSubCategoryId=330)

[![עציץ קרמי דור ](https://www.yifrach.co.il/images/storeProducts_image1_id1673_rndccze_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1673&storeSubCategoryId=330) [עציץ קרמי דור \\
\\
35](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1673&storeSubCategoryId=330)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1673&storeSubCategoryId=330)

[![צילנדר פסים ](https://www.yifrach.co.il/images/storeProducts_image1_id1371_rndOlOn_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1371&storeSubCategoryId=330) [צילנדר פסים \\
\\
40](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1371&storeSubCategoryId=330)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1371&storeSubCategoryId=330)

[![ארטסטון קונוס](https://www.yifrach.co.il/images/storeProducts_image1_id1409_rndoICO_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1409&storeSubCategoryId=333) [ארטסטון קונוס\\
\\
35](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1409&storeSubCategoryId=333)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1409&storeSubCategoryId=333)

[![עציץ בטון עגול](https://www.yifrach.co.il/images/storeProducts_image1_id156_rndZ9jm_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=156&storeSubCategoryId=366) [עציץ בטון עגול\\
\\
45](https://www.yifrach.co.il/product-id.aspx?StoreProductId=156&storeSubCategoryId=366)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=156&storeSubCategoryId=366)

[![עציץ בטון נרי](https://www.yifrach.co.il/images/storeProducts_image1_id153_rndtrqp_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=153&storeSubCategoryId=330) [עציץ בטון נרי\\
\\
45](https://www.yifrach.co.il/product-id.aspx?StoreProductId=153&storeSubCategoryId=330)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=153&storeSubCategoryId=330)

[![עציץ קרמי גליל](https://www.yifrach.co.il/images/storeProducts_image1_id67_rndnyea_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=67&storeSubCategoryId=330) [עציץ קרמי גליל\\
\\
285](https://www.yifrach.co.il/product-id.aspx?StoreProductId=67&storeSubCategoryId=330)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=67&storeSubCategoryId=330)

[![צילנדר עם סטנד](https://www.yifrach.co.il/images/storeProducts_image1_id68_rnda0MA_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=68&storeSubCategoryId=330) [צילנדר עם סטנד\\
\\
55](https://www.yifrach.co.il/product-id.aspx?StoreProductId=68&storeSubCategoryId=330)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=68&storeSubCategoryId=330)

[![עציץ קרמי רותם ](https://www.yifrach.co.il/images/storeProducts_image1_id1531_rndbtgw_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1531&storeSubCategoryId=330) [עציץ קרמי רותם \\
\\
95](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1531&storeSubCategoryId=330)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1531&storeSubCategoryId=330)

[לכל כלי השתילה](https://www.yifrach.co.il/store-categories.aspx?StoreCategoryId=3)

![](https://www.yifrach.co.il/images/System/header_sep.png)דף הבית מתחת למומלצים![](https://www.yifrach.co.il/images/System/header_sep.png)

[![](https://www.yifrach.co.il/images/banners_categories_items_image1_id83_rnd2ETy.jpg)עסקים צומחים איתנובואו להכיר את כל הדרכים לצמוחלרעיונות לחצו כאן](https://www.yifrach.co.il/pid.aspx?P_pageId=10&P_catId=1) [![](https://www.yifrach.co.il/images/banners_categories_items_image1_id71_rndIh4G.jpg)מתי אלמד לגדל נכון?עצות ותמיכה בעציצים שמתקשים לפרוחהתיעצו איתנו כאן](https://www.yifrach.co.il/contact.aspx)

מעניינים

הבלוג המלא של יפרח

[01-12-2024\\
\\
**3 מקומות סודיים ברובע הנגרים**\\
\\
חדש!](https://www.yifrach.co.il/blog-post-id.aspx?BlogPostId=157)

הכי פופולריים שלנו

[![הומלמנה קומפלג'](https://www.yifrach.co.il/images/storeProducts_image1_id1688_rndbinp_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1688&storeSubCategoryId=339) [הומלמנה קומפלג'\\
\\
85](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1688&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1688&storeSubCategoryId=339)

[![עציץ תבלין עטוף ביוטה לאירועים](https://www.yifrach.co.il/images/storeProducts_image1_id1675_rndijun_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1675&storeSubCategoryId=372) [עציץ תבלין עטוף ביוטה לאירועים\\
\\
15](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1675&storeSubCategoryId=372)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1675&storeSubCategoryId=372)

[![ריפסליס קסותא](https://www.yifrach.co.il/images/storeProducts_image1_id115_rndTDIu_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=115&storeSubCategoryId=339) [ריפסליס קסותא\\
\\
65](https://www.yifrach.co.il/product-id.aspx?StoreProductId=115&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=115&storeSubCategoryId=339)

[![גינורה פרפל פשן](https://www.yifrach.co.il/images/storeProducts_image1_id1661_rndbslv_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1661&storeSubCategoryId=339) [גינורה פרפל פשן\\
\\
55](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1661&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1661&storeSubCategoryId=339)

[![קלתיאה רופיברבה](https://www.yifrach.co.il/images/storeProducts_image1_id1710_rndknix_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1710&storeSubCategoryId=339) [קלתיאה רופיברבה\\
\\
105](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1710&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1710&storeSubCategoryId=339)

[![דרצנה ג'מייקה](https://www.yifrach.co.il/images/storeProducts_image1_id1712_rndtabo_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1712&storeSubCategoryId=339) [דרצנה ג'מייקה\\
\\
150](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1712&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1712&storeSubCategoryId=339)

[![שלישיית סנסיווריות מעוצבת מזנים מיוחדים שתולים בעציצי בטון ](https://www.yifrach.co.il/images/storeProducts_image1_id1677_rndisge_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1677&storeSubCategoryId=374) [שלישיית סנסיווריות מעוצבת מזנים מיוחדים שתולים בעציצי בטון \\
\\
280](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1677&storeSubCategoryId=374)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1677&storeSubCategoryId=374)

[![זית בונסאי בקערת ארטסטון](https://www.yifrach.co.il/images/storeProducts_image1_id1566_rndw41Y_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1566&storeSubCategoryId=374) [זית בונסאי בקערת ארטסטון\\
\\
140](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1566&storeSubCategoryId=374)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1566&storeSubCategoryId=374)

[![מונסטרה מינימה](https://www.yifrach.co.il/images/storeProducts_image1_id1486_rndzObn_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1486&storeSubCategoryId=339) [מונסטרה מינימה\\
\\
75](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1486&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=1486&storeSubCategoryId=339)

[![פוטוס מוס](https://www.yifrach.co.il/images/storeProducts_image1_id185_rnd1Y2D_R1.jpg)\\
\\
המוצר אזל](https://www.yifrach.co.il/product-id.aspx?StoreProductId=185&storeSubCategoryId=339) [פוטוס מוס\\
\\
160](https://www.yifrach.co.il/product-id.aspx?StoreProductId=185&storeSubCategoryId=339)

[צפו במוצר](https://www.yifrach.co.il/product-id.aspx?StoreProductId=185&storeSubCategoryId=339)

[לכל הממלצות שלנו](https://www.yifrach.co.il/store-products.aspx?StoreCategoryId=5&StoreSubCategoryId=339)

עדה

יפרח, משתלה אופטימית, כשמה כן היא! הצמחים יפהפיים ובאיכות גבוהה! והיחס \- אין לי מילים, עדי עזר לי בסבלנות, אהבה ואכפתיות אמיתית! עכשיו, שמצאתי אותם, זו המשתלה אליה אחזור תמיד!

עדי גלבוע

שירות משלוחים מעולה! ביצעתי הזמנה דרך האתר ואחד השתילים שהזמנתי היה חסר אז התקשרו לעדכן אותי בעיכוב ויום אחרי המשלוח כבר הגיע, כל השתילים במצב מעולה ופינקו עם אקסטרה אדמת שתילה :) בטוח אזמין שוב!

דנה ווינטר

משתלה מהממת במיקום עוד יותר מהמם! מבחר גדול מאוד של עציצים וכל מה שצריך לגינה. קיבלתי יחס אדיב מאוד מהבעלים והרבה עזרה, מקצועי וכיפי.

טובי רמות

בא לי ללקט צמחים קצת אחרת ..און ליין לשם שינו , ענה לי עדי מיפרח משתלה אורבנית אופטימית .תיתקנו הזמנה עם הסבר והכוונה ,יום שישי ב15.00, ב17.00 הבחור החתיך הזה( לא קשור אבל מה זה משנה🙂) עמד אל מול הדלת עם כל מה שהזמנתי ויותר! אין דברים כאלה!! תודה על שירות מדהים !!

שרון אריאל

חפשתי לקנות מהיום למחר שתילים לבית, הגעתי במקרה למשתלה יפרח באינטרנט ואני מאושרת שמצאתי אותכם :-) תודה רבה על השירות האדיב והמהיר, הטיפול והצמחים המקסימים שקבלתי

מאיה ידין

משתלה מהממת מהממת בפלורנטין, עם צמחים ממש מיוחדים, ועדי המהמם שעזר עם בחירה מדויקת של עציצים לבית, וכלים מתאימים, משלוח מהיר וזמין תמיד להתייעצות לגבי הטיפול בעציצים בהמשך והרגעה שעדיין לא הרגתי אותם והם גדלים יפה :)

עפרה שני

אין מילים להביע את הערכתי בכל פרמטר אפשרי! הזמנתי בונסאי זית.קיבלתי הסבר מדויק והמלצות שהוכחו כנכונות.השתיל והעציץ היגיעו בדיוק בזמן לשביעות רצוננו המלאה.היחס והשירות מעולים! מומלץ בחום ויותר.והמחירים מעולים! תודה רבה לכם ולעדי.

שרה פלאש

זה כבר המקום הקבוע שלנו בעבודה בשביל מתנות יומולדת לחברי צוות. אחלה צמחים באחלה מחירים, והצמחים באמת נראים כמו בתמונות באתר. עדי הלך מעל ומעבר כדי להתאים לי את ההזמנה לבול מה שרציתי\- איזה שירות מעולה! אקנה עוד הרבה מכם :)

אביבה סינואני

חווית קנייה מאוד נעימה עם שירות יוצא דופן וברמה גבוהה מעל המצופה, היה לי חסר 2 פריטים בהזמנה והקפיצו לי באופן מיוחד, כמו כן קבלתי ללא תמורה צמח סינגוניום, עקב אי הבנה בזמן ההזמנה, לסיכום יחס אדיב שירות מהיר וזריז, מאוד ממליצה לרכוש ממשתלה זו כי אין ספק שאמשיך להיות לקוחה שלהם.

אילן אדרי

עציצים זו התמכרות וכולנו בחיפוש מתמיד אחרי המשתלה הכי טובה בעיר, אז אתם יכולים לעצור, כי מצאתם אותה. המשתלה של עדי קטנה ונסתרת, מלאה בסחורה וצמחים מדהימים, איכותיים, מיוחדים ויחודיים, השירות סבלני, אדיב, מלמד, מסביר ותמיד בא לקראת העציץ שהלקוח הכי יהנה ויפיק ממנו. המחיר זול והוגן, המשלוח בחינם(!) ואם יהיה לכם מזל \- עדי יהיה גם זה שיביא לכם את הילדים החדשים הביתה. בקיצור, זו המשתלה החדשה שלכם בעיר, תתחדשו

adiya imri Orr

שירות מעולה, עציצים במצב מצוין. תמיד הלכתי למשתלות ועקב עומס מתמשך החלטתי בחשש מסוים להזמין. זו פעם ראשונה שאני מזמינה צמחים במשלוח ויצאתי סופר מרוצה. עדי יצר קשר לברר אם הצמח שהזמנתי אכן מתאים לתנאים, גילינו שאפשר לדייק את ההזמנה יותר, הוא שלח לי למחרת בבוקר מה הגיע, בחרתי ואפילו פינק בדשן שרציתי להוסיף מבלי לחייב אותי על ההפרש. מאחר שהצמחים הגיעו כשהייתי בעבודה הוא בירר איתי פעמיים \- כשהגיעו ובערב כשחזרתי הביתה שהכל לשביעות רצוני. ואני כאמור סופר שבעת רצון. עשר מעשר, תודה!

הגר אייל

וואווו משתלה מדהימה! הגעתי אחרי שקראתי את החוות דעת פה ובאמת, התגשמות החלומות של כל חובב צמחים :) הצמחים בחנות מהממים ביופיים, בריאים ושמחים. השירות של עדי מכל הלב והכי חשוב מקצועי מאוד. הוא אפילו הסכים להגיע אלינו הביתה ולעזור לנו בבחירת הצמחים. מאז כבר חזרנו כמה פעמים וממשיכים להגיע קבוע. התמכרות מובטחת! איזה כיף שיש משתלב כזאת בעיר.

תומר שוורץ

שירות מדהים! ביצעתי הזמנה טלפונית \- היו ממש סבלניים ועזרו בהרכבת עציץ עד שיצא טוב, גם עזרו להוציא את זה למשלוח בהפתעה (למרות הקשיים שהיו, הם לא וויתרו), וכל זה באחלה מחיר. מומלץ בחום.

צור לוין

למרות שאני חשדנית הזמנתי בהמלצת חבר צמחים ממשתלת יפרח, הצמחים הגיעו יום למחרת! עדי היה חמוד וסבלני\- צילם לי את הצמחים לראות שאני מרוצה והגדיל להתקשר יום אחרי לבדוק שהכל הגיע בסדר. בקיצור עופו לקנות!

אנסטסיה בן דוד

הזמנתי קקטוסים במשלוח וכולם הגיעו במצב מעולה, יפים מאוד ואפילו שדרגו לנו לגודל גדול יותר בחינם!! שירות מעולה, גם עונים מהר מאוד בווטסאפ לבירורים. ממליצה בחום!

הדר סטפני

משתלה חדשה בת"א עם צוות מקסים. הזמנתי מהאינטרנט ונעזרתי בהם בוואטסאפ לבירור על צמח ושמחו לבדוק עבורי. שירות סופר מהיר \- הגיע תוך מספר שעות מרגע ההזמנה מה שהפתיע אותי ממש. הפתעה טובה שנייה הייתה שאפילו הביאו לי צמחים גדולים יותר ממה שהזמנתי וגם אמרו שלכל שאלה על הצמחים הם זמינים. ממליצה :)

ענבר כהן לרנר

משתלה מתוקה ומקסימה בדרום תל אביב. חיפשתי את הטרריום המושלם והגעתי לאתר של משתלת יפרח. קיבלתי מענה מהיר ונעים וכבר באותו יום המשלוח היה מוכן והגיע אלי למחרת.

עדי המקסים זמין לכל שאלה ואני סופר סופר מרוצה 🌞 ואכן הטרריום מושלם. חוץ מזה המשתלה מהממת ויש בה הכל! מגוון עציצים מעלפים והמון סוגי צמחים. מומלץ מאוד!

עדה

יפרח, משתלה אופטימית, כשמה כן היא! הצמחים יפהפיים ובאיכות גבוהה! והיחס \- אין לי מילים, עדי עזר לי בסבלנות, אהבה ואכפתיות אמיתית! עכשיו, שמצאתי אותם, זו המשתלה אליה אחזור תמיד!

עדי גלבוע

שירות משלוחים מעולה! ביצעתי הזמנה דרך האתר ואחד השתילים שהזמנתי היה חסר אז התקשרו לעדכן אותי בעיכוב ויום אחרי המשלוח כבר הגיע, כל השתילים במצב מעולה ופינקו עם אקסטרה אדמת שתילה :) בטוח אזמין שוב!

דנה ווינטר

משתלה מהממת במיקום עוד יותר מהמם! מבחר גדול מאוד של עציצים וכל מה שצריך לגינה. קיבלתי יחס אדיב מאוד מהבעלים והרבה עזרה, מקצועי וכיפי.

טובי רמות

בא לי ללקט צמחים קצת אחרת ..און ליין לשם שינו , ענה לי עדי מיפרח משתלה אורבנית אופטימית .תיתקנו הזמנה עם הסבר והכוונה ,יום שישי ב15.00, ב17.00 הבחור החתיך הזה( לא קשור אבל מה זה משנה🙂) עמד אל מול הדלת עם כל מה שהזמנתי ויותר! אין דברים כאלה!! תודה על שירות מדהים !!

שרון אריאל

חפשתי לקנות מהיום למחר שתילים לבית, הגעתי במקרה למשתלה יפרח באינטרנט ואני מאושרת שמצאתי אותכם :-) תודה רבה על השירות האדיב והמהיר, הטיפול והצמחים המקסימים שקבלתי

מאיה ידין

משתלה מהממת מהממת בפלורנטין, עם צמחים ממש מיוחדים, ועדי המהמם שעזר עם בחירה מדויקת של עציצים לבית, וכלים מתאימים, משלוח מהיר וזמין תמיד להתייעצות לגבי הטיפול בעציצים בהמשך והרגעה שעדיין לא הרגתי אותם והם גדלים יפה :)

עפרה שני

אין מילים להביע את הערכתי בכל פרמטר אפשרי! הזמנתי בונסאי זית.קיבלתי הסבר מדויק והמלצות שהוכחו כנכונות.השתיל והעציץ היגיעו בדיוק בזמן לשביעות רצוננו המלאה.היחס והשירות מעולים! מומלץ בחום ויותר.והמחירים מעולים! תודה רבה לכם ולעדי.

שרה פלאש

זה כבר המקום הקבוע שלנו בעבודה בשביל מתנות יומולדת לחברי צוות. אחלה צמחים באחלה מחירים, והצמחים באמת נראים כמו בתמונות באתר. עדי הלך מעל ומעבר כדי להתאים לי את ההזמנה לבול מה שרציתי\- איזה שירות מעולה! אקנה עוד הרבה מכם :)

אביבה סינואני

חווית קנייה מאוד נעימה עם שירות יוצא דופן וברמה גבוהה מעל המצופה, היה לי חסר 2 פריטים בהזמנה והקפיצו לי באופן מיוחד, כמו כן קבלתי ללא תמורה צמח סינגוניום, עקב אי הבנה בזמן ההזמנה, לסיכום יחס אדיב שירות מהיר וזריז, מאוד ממליצה לרכוש ממשתלה זו כי אין ספק שאמשיך להיות לקוחה שלהם.

אילן אדרי

עציצים זו התמכרות וכולנו בחיפוש מתמיד אחרי המשתלה הכי טובה בעיר, אז אתם יכולים לעצור, כי מצאתם אותה. המשתלה של עדי קטנה ונסתרת, מלאה בסחורה וצמחים מדהימים, איכותיים, מיוחדים ויחודיים, השירות סבלני, אדיב, מלמד, מסביר ותמיד בא לקראת העציץ שהלקוח הכי יהנה ויפיק ממנו. המחיר זול והוגן, המשלוח בחינם(!) ואם יהיה לכם מזל \- עדי יהיה גם זה שיביא לכם את הילדים החדשים הביתה. בקיצור, זו המשתלה החדשה שלכם בעיר, תתחדשו

adiya imri Orr

שירות מעולה, עציצים במצב מצוין. תמיד הלכתי למשתלות ועקב עומס מתמשך החלטתי בחשש מסוים להזמין. זו פעם ראשונה שאני מזמינה צמחים במשלוח ויצאתי סופר מרוצה. עדי יצר קשר לברר אם הצמח שהזמנתי אכן מתאים לתנאים, גילינו שאפשר לדייק את ההזמנה יותר, הוא שלח לי למחרת בבוקר מה הגיע, בחרתי ואפילו פינק בדשן שרציתי להוסיף מבלי לחייב אותי על ההפרש. מאחר שהצמחים הגיעו כשהייתי בעבודה הוא בירר איתי פעמיים \- כשהגיעו ובערב כשחזרתי הביתה שהכל לשביעות רצוני. ואני כאמור סופר שבעת רצון. עשר מעשר, תודה!

הגר אייל

וואווו משתלה מדהימה! הגעתי אחרי שקראתי את החוות דעת פה ובאמת, התגשמות החלומות של כל חובב צמחים :) הצמחים בחנות מהממים ביופיים, בריאים ושמחים. השירות של עדי מכל הלב והכי חשוב מקצועי מאוד. הוא אפילו הסכים להגיע אלינו הביתה ולעזור לנו בבחירת הצמחים. מאז כבר חזרנו כמה פעמים וממשיכים להגיע קבוע. התמכרות מובטחת! איזה כיף שיש משתלב כזאת בעיר.

תומר שוורץ

שירות מדהים! ביצעתי הזמנה טלפונית \- היו ממש סבלניים ועזרו בהרכבת עציץ עד שיצא טוב, גם עזרו להוציא את זה למשלוח בהפתעה (למרות הקשיים שהיו, הם לא וויתרו), וכל זה באחלה מחיר. מומלץ בחום.

צור לוין

למרות שאני חשדנית הזמנתי בהמלצת חבר צמחים ממשתלת יפרח, הצמחים הגיעו יום למחרת! עדי היה חמוד וסבלני\- צילם לי את הצמחים לראות שאני מרוצה והגדיל להתקשר יום אחרי לבדוק שהכל הגיע בסדר. בקיצור עופו לקנות!

אנסטסיה בן דוד

הזמנתי קקטוסים במשלוח וכולם הגיעו במצב מעולה, יפים מאוד ואפילו שדרגו לנו לגודל גדול יותר בחינם!! שירות מעולה, גם עונים מהר מאוד בווטסאפ לבירורים. ממליצה בחום!

הדר סטפני

משתלה חדשה בת"א עם צוות מקסים. הזמנתי מהאינטרנט ונעזרתי בהם בוואטסאפ לבירור על צמח ושמחו לבדוק עבורי. שירות סופר מהיר \- הגיע תוך מספר שעות מרגע ההזמנה מה שהפתיע אותי ממש. הפתעה טובה שנייה הייתה שאפילו הביאו לי צמחים גדולים יותר ממה שהזמנתי וגם אמרו שלכל שאלה על הצמחים הם זמינים. ממליצה :)

ענבר כהן לרנר

משתלה מתוקה ומקסימה בדרום תל אביב. חיפשתי את הטרריום המושלם והגעתי לאתר של משתלת יפרח. קיבלתי מענה מהיר ונעים וכבר באותו יום המשלוח היה מוכן והגיע אלי למחרת.

עדי המקסים זמין לכל שאלה ואני סופר סופר מרוצה 🌞 ואכן הטרריום מושלם. חוץ מזה המשתלה מהממת ויש בה הכל! מגוון עציצים מעלפים והמון סוגי צמחים. מומלץ מאוד!

עדה

יפרח, משתלה אופטימית, כשמה כן היא! הצמחים יפהפיים ובאיכות גבוהה! והיחס \- אין לי מילים, עדי עזר לי בסבלנות, אהבה ואכפתיות אמיתית! עכשיו, שמצאתי אותם, זו המשתלה אליה אחזור תמיד!

‹›

[לכל ההמלצות](https://www.google.com/search?gs_ssp=eJwBTQCy_woNL2cvMTFydmN2eHFzbjABOiUweDE1MWQ0ZGFiYjA5NmM4ZWQ6MHgzNzc2NWY2ZGY1YWEzY2RjShPXmdek16jXlyDXntep16rXnNeUqiseDg&q=%D7%99%D7%A4%D7%A8%D7%97+%D7%9E%D7%A9%D7%AA%D7%9C%D7%94&oq=%D7%99%D7%A4%D7%A8%D7%97&aqs=chrome.1.69i57j46i39i175i199j46i175i199i512j0i512l3j46i175i199i512j0i512j46i175i199i512l2.2100j0j15&sourceid=chrome&ie=UTF-8#lrd=0x151d4dabb096c8ed:0x37765f6df5aa3cdc,1,,,)

# יפרח משתלה בתל אביב

## משתלה בתל אביב שיש בה הכל, מכאן תוכלו להזמין משלוחי צמחים כלים, אדמה דשנים ומתנות עד הבית. או שפשוט תקפצו להגיד שלום, בכל מקרה כדאי לכם להיות חברי מועדון ולקבל מבצעים והטבות לפני כולם.

[הרשמה לאתר](https://www.yifrach.co.il/Registration.aspx)

מאשר/ת קבלת דיוור בהתאם למדיניות הפרטיות

![](https://www.yifrach.co.il/GenerateCaptcha.ashx)

![](https://www.yifrach.co.il/images/System/loading-page.gif)

![](https://www.yifrach.co.il/images/System/toy.png)

[![](https://www.yifrach.co.il/images/web_links_items_image1_id1_rndlGnx.jpg)\\
\\
**איזורי חלוקה** \\
\\
תל אביב, ערי המרכז והשרון](https://www.yifrach.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#a) [![](https://www.yifrach.co.il/images/web_links_items_image1_id2_rndYiwy.jpg)\\
\\
**מוקד הצמחים** \\
\\
צריכים תמיכה או יעוץ בנוגע לצמחים שלכם?\\
\\
אנחנו זמינים\- 03-7320173](https://www.yifrach.co.il/contact.aspx) [![](https://www.yifrach.co.il/images/web_links_items_image1_id3_rnd2F8R.jpg)\\
\\
**רכישה בטוחה** \\
\\
האתר מאובטח לרכישה און ליין בתקני אבטחה מחמירים](https://www.yifrach.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#a) [![](https://www.yifrach.co.il/images/web_links_items_image1_id4_rndd8xk.jpg)\\
\\
**המשתלה שלנו** \\
\\
בואו לבקר אותנו, צריפין 35 תל אביב](https://www.yifrach.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#a)

יפרח \- משתלה אופטימית

משתלה בפלורנטין שיש בה צמחי בית וחוץ, תערובות שתילה, תבלינים, כלי שתילה מסודים שונים, דשנים והדברה ועוד\- כדי שתוכלו לחיות ולעבוד בסביבה ירוקה!

שעות פתיחה

[![](https://www.yifrach.co.il/images/footer_website_image2_rndD7FM.png)](https://www.yifrach.co.il/Registration.aspx)

ראשון עד חמישי: 10:00-18:00

שישי: 16:00- 9:00

מקבלים הזמנות באתר בוואצאפ ובטלפון

רכישה מאובטחת

![](https://www.yifrach.co.il/images/web_links_items_image1_id53_rndVeof.png)

![](https://www.yifrach.co.il/images/web_links_items_image1_16_rnd_1570.png)

![](https://www.yifrach.co.il/images/web_links_items_image1_17_rnd_6026.png)

האתר מאובטח לרכישה באמצעות טכנולוגיית ssl מהמובילות בעולם. הסליקה מתבצעת עם חברת טרנזילה ועומדת בתקן - pci

זמינים לשירותכם

[מייל: YifrachTlv@gmail.com](mailto:info@fusion-shop.co.il) [טלפון: 03-7320173](tel:03-7320173) [כתובת: צריפין 35, תל אביב](https://www.yifrach.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#a) [ווצאפ: 0549380028](https://api.whatsapp.com/send?phone=9720549380028)

איך מגיעים

מידע נוסף

[הצהרת נגישות](https://www.yifrach.co.il/pid.aspx?P_pageId=8&P_catId=0) [תקנון ומדיניות אתר](https://www.yifrach.co.il/pid.aspx?P_pageId=6&P_catId=1)

תשארו מחוברים

כל הזכויות שמורות © ל\- יפרח משתלה אופטימית 2022

[![פיוז'ן סטודיו](https://www.yifrach.co.il/images/System/icon-good-small-white.png)](https://very-good.co.il/)

התחברות לאתר

[שכחתם סיסמה?](https://www.yifrach.co.il/password_Recovery.aspx)

השאירו אותי מחובר

עדיין לא מחוברים? [צרו חשבון חדש](https://www.yifrach.co.il/Registration.aspx)

[המשך כאורח](https://www.yifrach.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#a)

![](https://www.yifrach.co.il/images/System/loading-page.gif)

רוצים להוסיף את המוצר למועדפים? היכנסו לחשבונכם או הרשמו לאתר ותהנו מהטבות ומבצעים כל השנה, נשמח לראותכם :)

[התחברו/הרשמו](https://www.yifrach.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#customer_login)

[![](https://www.yifrach.co.il/images/popup_jumping_image1_rndx1JZ.jpg)](https://www.yifrach.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#a)

[![](https://www.yifrach.co.il/images/System/popup_addToCart.jpg)](https://www.yifrach.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1#)

![נגישות](https://www.yifrach.co.il/Moduls/accessibility/icons/accesibility.svg)

×

### נגישות

[הצהרת נגישות](https://www.yifrach.co.il/pid.aspx?P_pageId=8&P_catId=1)![בטל נגישות](https://www.yifrach.co.il/Moduls/accessibility/icons/cancel.svg) בטל נגישות

![הגדלת טקסט](https://www.yifrach.co.il/Moduls/accessibility/icons/bigText.svg) הגדלת טקסט![](https://www.yifrach.co.il/Moduls/accessibility/icons/spaceLines.svg) מרווח שורות![](https://www.yifrach.co.il/Moduls/accessibility/icons/TextAlignment.svg) יישור טקסט![](https://www.yifrach.co.il/Moduls/accessibility/icons/legibleFont.svg) גופן קריא![](https://www.yifrach.co.il/Moduls/accessibility/icons/greyColors.svg) גווני אפור![](https://www.yifrach.co.il/Moduls/accessibility/icons/contrastIcon.svg) ניגודיות![](https://www.yifrach.co.il/Moduls/accessibility/icons/image.svg) הסתר תמונות![](https://www.yifrach.co.il/Moduls/accessibility/icons/underline.svg) הדגשת קישורים

התאמת צבעים

גודל גופןקטןבינוניגדולענק

![](https://www.yifrach.co.il/Moduls/accessibility/icons/blockFlickering.svg) חסום הבהובים![](https://www.yifrach.co.il/Moduls/accessibility/icons/mute.svg) השתקת אודיו![](https://www.yifrach.co.il/Moduls/accessibility/icons/enlarge.svg) הגדלת כותרות![](https://www.yifrach.co.il/Moduls/accessibility/icons/keyboard.svg) מקלדת וירטואלית