[דילוג לתוכן](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#content)

[פתח סרגל נגישות](javascript:void(0); "כלי נגישות")

כלי נגישות

*   [הגדל טקסט](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [הקטן טקסט](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [גווני אפור](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [ניגודיות גבוהה](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [ניגודיות הפוכה](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [רקע בהיר](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [הדגשת קישורים](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [פונט קריא](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)
*   [איפוס](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

העדפות פרטיות

אנו משתמשים בקובצי Cookies כדי לשפר את חוויית הגלישה שלך, להציע תכנים מותאמים אישית ולנתח תנועה באתר. תוכל לבחור אם לאפשר או לדחות עוגיות לא חיוניות בכל עת דרך “העדפות פרטיות”.

פונקציונלי- [x] פונקציונלי  Always active 

אחסון או גישה טכנית הנדרשת לצורך הפעלת האתר והשירותים הבסיסיים שבו, כגון התחברות לחשבון, שמירת פריטים בעגלת הקניות או הגדרות פרטיות. ללא עוגיות אלו האתר עלול שלא לפעול כראוי.

Preferences- [x] Preferences 

The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user.

סטטיסטיקה- [x] סטטיסטיקה 

The technical storage or access that is used exclusively for statistical purposes.עוגיות סטטיסטיות משמשות לאיסוף מידע אנונימי על שימוש באתר – כמו עמודים שנצפו, זמן שהייה, ומקורות תנועה. המידע מאפשר לנו לשפר את חוויית המשתמש וביצועי האתר. לא ניתן לזהות משתמשים באופן אישי באמצעות עוגיות אלה.

שיווק- [x] שיווק 

עוגיות שיווקיות משמשות ליצירת פרופיל משתמש לצורך הצגת פרסומות מותאמות אישית, או למדידת יעילות של קמפיינים שיווקיים. בנוסף, עוגיות אלה עשויות לעקוב אחר פעילות המשתמש באתרים שונים לצורכי פרסום.

*   [Manage options](https://h-shtilshop.co.il/cookie-policy-eu/#cmplz-manage-consent-container)
*   [Manage services](https://h-shtilshop.co.il/cookie-policy-eu/#cmplz-cookies-overview)
*   [Manage {vendor_count} vendors](https://h-shtilshop.co.il/cookie-policy-eu/#cmplz-tcf-wrapper)
*   [Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)

מאשר מסרב העדפות פרטיות שמור העדפות[העדפות פרטיות](https://h-shtilshop.co.il/cookie-policy-eu/#cmplz-manage-consent-container)

*   [Cookie Policy](https://h-shtilshop.co.il/cookie-policy-eu/)
*   [מדיניות פרטיות](https://h-shtilshop.co.il/%d7%9e%d7%93%d7%99%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%a8%d7%98%d7%99%d7%95%d7%aa/)
*   [{title}](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

חזר למלאי סולמות לעציצים

משלוחים גם בשישי ושבת!

הסכום המינימלי לביצוע הזמנה הוא ₪150

[דרושים](https://h-shtilshop.co.il/%d7%93%d7%a8%d7%95%d7%a9%d7%99%d7%9d/)

חזר למלאי סולמות לעציצים

*   [Follow](https://www.facebook.com/havayavashtil/ "Follow on Facebook")
*   [Follow](https://www.instagram.com/havaia_and_shtil/ "Follow on Instagram")

[03-9675005](tel:03-9675005)

*   [הזמנות](https://h-shtilshop.co.il/%d7%94%d7%97%d7%a9%d7%91%d7%95%d7%9f-%d7%a9%d7%9c%d7%99/orders/)
*   [פרטי חשבון](https://h-shtilshop.co.il/%d7%94%d7%97%d7%a9%d7%91%d7%95%d7%9f-%d7%a9%d7%9c%d7%99/edit-account/)
*   [אודות](https://h-shtilshop.co.il/%d7%90%d7%95%d7%93%d7%95%d7%aa/)
*   [דרושים](https://h-shtilshop.co.il/%d7%93%d7%a8%d7%95%d7%a9%d7%99%d7%9d/)
*   [כתבו עלינו](https://h-shtilshop.co.il/%d7%9b%d7%aa%d7%91%d7%95-%d7%a2%d7%9c%d7%99%d7%a0%d7%95/)
*   [צור קשר](https://h-shtilshop.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)

*   [הזמנות](https://h-shtilshop.co.il/%d7%94%d7%97%d7%a9%d7%91%d7%95%d7%9f-%d7%a9%d7%9c%d7%99/orders/)
*   [פרטי חשבון](https://h-shtilshop.co.il/%d7%94%d7%97%d7%a9%d7%91%d7%95%d7%9f-%d7%a9%d7%9c%d7%99/edit-account/)
*   [אודות](https://h-shtilshop.co.il/%d7%90%d7%95%d7%93%d7%95%d7%aa/)
*   [דרושים](https://h-shtilshop.co.il/%d7%93%d7%a8%d7%95%d7%a9%d7%99%d7%9d/)
*   [כתבו עלינו](https://h-shtilshop.co.il/%d7%9b%d7%aa%d7%91%d7%95-%d7%a2%d7%9c%d7%99%d7%a0%d7%95/)
*   [צור קשר](https://h-shtilshop.co.il/%d7%a6%d7%95%d7%a8-%d7%a7%d7%a9%d7%a8/)

[![Image 1](https://h-shtilshop.co.il/wp-content/uploads/2020/12/logo.jpg)](https://h-shtilshop.co.il/)

*   [דף הבית](https://h-shtilshop.co.il/)
*   [ראש השנה 🍏🍯](https://h-shtilshop.co.il/product-category/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-%f0%9f%8d%8f%f0%9f%8d%af/)
*   [פרחים](https://h-shtilshop.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [זרי כלה](https://h-shtilshop.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)

*   [תוספות שוות](https://h-shtilshop.co.il/product-category/%d7%aa%d7%95%d7%a1%d7%a4%d7%95%d7%aa-%d7%a9%d7%95%d7%95%d7%aa/)
    *   [יין](https://h-shtilshop.co.il/product-category/%d7%99%d7%99%d7%9f/)
    *   [שוקולד](https://h-shtilshop.co.il/product-category/%d7%a9%d7%95%d7%a7%d7%95%d7%9c%d7%93/)
    *   [כרטיסי ברכה מעוצבים](https://h-shtilshop.co.il/product-category/%d7%9b%d7%a8%d7%98%d7%99%d7%a1%d7%99-%d7%91%d7%a8%d7%9b%d7%94-%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d/)
    *   [בלון](https://h-shtilshop.co.il/product-category/%d7%91%d7%9c%d7%95%d7%9f/)

*   [צמחי פנים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/)
    *   [צמחי ריצפה](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%a8%d7%99%d7%a6%d7%a4%d7%94/)
    *   [צמחי מדף או תליה](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%9e%d7%93%d7%a3-%d7%90%d7%95-%d7%aa%d7%9c%d7%99%d7%94/)
    *   [צמחים למתחילים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%9e%d7%aa%d7%97%d7%99%d7%9c%d7%99%d7%9d/)
    *   [צמחי בונסאי ומעוצבים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%95%d7%a0%d7%a1%d7%90%d7%99-%d7%95%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d/)
    *   [צמחים רבי מכר](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%a8%d7%91%d7%99-%d7%9e%d7%9b%d7%a8/)
    *   [חבילת צמחים לבית חדש](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%97%d7%91%d7%99%d7%9c%d7%aa-%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%91%d7%99%d7%aa-%d7%97%d7%93%d7%a9-%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/)
    *   [צמחים שאתם חייבים בבית!](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%a9%d7%90%d7%aa%d7%9d-%d7%97%d7%99%d7%99%d7%91%d7%99%d7%9d-%d7%91%d7%91%d7%99%d7%aa/)
    *   [צמחים מטהרי אוויר](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9e%d7%98%d7%94%d7%a8%d7%99-%d7%90%d7%95%d7%95%d7%99%d7%a8/)
    *   [צמחים מעוצבים בכלי בטון](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d-%d7%91%d7%9b%d7%9c%d7%99-%d7%91%d7%98%d7%95%d7%9f/)
    *   [סוקולנטים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)
    *   [טרריום וצמחי אוויר](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%98%d7%a8%d7%a8%d7%99%d7%95%d7%9d-%d7%95%d7%a6%d7%9e%d7%97%d7%99-%d7%90%d7%95%d7%95%d7%99%d7%a8/)
    *   [סחלבים](https://h-shtilshop.co.il/product-category/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)

*   [צמחיית חוץ](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/)
    *   [מבצעי אביב](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%9e%d7%91%d7%a6%d7%a2%d7%99-%d7%90%d7%91%d7%99%d7%91/)
    *   [עציצים למרפסת/גינה](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%9e%d7%a8%d7%a4%d7%a1%d7%aa-%d7%92%d7%99%d7%a0%d7%94/)
    *   [צמחים לאדניות](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [צמחים מפיצי ריח](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9e%d7%a4%d7%99%d7%a6%d7%99-%d7%a8%d7%99%d7%97/)

*   [אדמה, דישון והדברה](https://h-shtilshop.co.il/product-category/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%93%d7%99%d7%a9%d7%95%d7%9f-%d7%95%d7%94%d7%93%d7%91%d7%a8%d7%94/)
*   [כלי שתילה ואקססוריז](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/)
    *   [פסלי גינה](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%a4%d7%a1%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%94/)
    *   [כלי שתילה דקורטיביים](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/)
        *   [פלסטיק איטליה](https://h-shtilshop.co.il/product-category/%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%90%d7%99%d7%98%d7%9c%d7%99%d7%94/)
        *   [אדניות פיבר – כלי פיבר](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/%d7%9b%d7%9c%d7%99-%d7%a4%d7%99%d7%91%d7%a8/)
            *   [כלי פיבר בטון](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a4%d7%99%d7%91%d7%a8-%d7%91%d7%98%d7%95%d7%9f/)

        *   [אדניות לשתילה](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%9c%d7%a9%d7%aa%d7%99%d7%9c%d7%94/)
        *   [כדי פלסטיק לשתילה](https://h-shtilshop.co.il/product-category/%d7%9b%d7%93%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)

    *   [הקולקציה ההודית](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/%d7%94%d7%a7%d7%95%d7%9c%d7%a7%d7%a6%d7%99%d7%94-%d7%94%d7%94%d7%95%d7%93%d7%99%d7%aa/)
    *   [כלים מקרמיקה](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/%d7%9b%d7%9c%d7%99%d7%9d-%d7%9e%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
    *   [שילוט](https://h-shtilshop.co.il/product-category/%d7%a9%d7%99%d7%9c%d7%95%d7%98/)

*   [מיוחד בשבילכם](https://h-shtilshop.co.il/product-category/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a2%d7%9d-%d7%97%d7%99%d7%99%d7%9d/)
    *   [עציצים מתנה לאירוע](https://h-shtilshop.co.il/product-category/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a2%d7%9d-%d7%97%d7%99%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9e%d7%aa%d7%a0%d7%94-%d7%9c%d7%90%d7%99%d7%a8%d7%95%d7%a2/)

*   [חוויה ושתיל – עיצובים](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/)
    *   [עיצוב מרפסות](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%9e%d7%a8%d7%a4%d7%a1%d7%95%d7%aa-%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%a4%d7%a8%d7%98%d7%99/)
    *   [עיצוב משרדים](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%9e%d7%a9%d7%a8%d7%93%d7%99%d7%9d-%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%a2%d7%a1%d7%a7%d7%99/)
    *   [חוויה ושתיל בבית האח הגדול 🧿](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/)
        *   [האח הגדול 2020](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2020/)
        *   [האח הגדול 2021](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2021/)
        *   [האח הגדול 2022](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2022/)
        *   [האח הגדול 2023](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2023/)
        *   [האח הגדול 2024](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2024/)
        *   [האח הגדול 2025](https://h-shtilshop.co.il/product-category/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2025/)
        *   [האח הגדול 2026](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2026/)

    *   [צילומי הפקות](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%a6%d7%99%d7%9c%d7%95%d7%9e%d7%99-%d7%94%d7%a4%d7%a7%d7%95%d7%aa/)

*   [Gift Card🎁](https://h-shtilshop.co.il/product-category/gift-card%f0%9f%8e%81/)
*   [בואו לעבוד איתנו!](https://h-shtilshop.co.il/product-category/%d7%91%d7%95%d7%90%d7%95-%d7%9c%d7%a2%d7%91%d7%95%d7%93-%d7%90%d7%99%d7%aa%d7%a0%d7%95/)

[](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product#)

*   [דף הבית](https://h-shtilshop.co.il/)
*   [ראש השנה 🍏🍯](https://h-shtilshop.co.il/product-category/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-%f0%9f%8d%8f%f0%9f%8d%af/)
*   [פרחים](https://h-shtilshop.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
    *   [זרי כלה](https://h-shtilshop.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)

*   [תוספות שוות](https://h-shtilshop.co.il/product-category/%d7%aa%d7%95%d7%a1%d7%a4%d7%95%d7%aa-%d7%a9%d7%95%d7%95%d7%aa/)
    *   [יין](https://h-shtilshop.co.il/product-category/%d7%99%d7%99%d7%9f/)
    *   [שוקולד](https://h-shtilshop.co.il/product-category/%d7%a9%d7%95%d7%a7%d7%95%d7%9c%d7%93/)
    *   [כרטיסי ברכה מעוצבים](https://h-shtilshop.co.il/product-category/%d7%9b%d7%a8%d7%98%d7%99%d7%a1%d7%99-%d7%91%d7%a8%d7%9b%d7%94-%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d/)
    *   [בלון](https://h-shtilshop.co.il/product-category/%d7%91%d7%9c%d7%95%d7%9f/)

*   [צמחי פנים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/)
    *   [צמחי ריצפה](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%a8%d7%99%d7%a6%d7%a4%d7%94/)
    *   [צמחי מדף או תליה](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%9e%d7%93%d7%a3-%d7%90%d7%95-%d7%aa%d7%9c%d7%99%d7%94/)
    *   [צמחים למתחילים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%9e%d7%aa%d7%97%d7%99%d7%9c%d7%99%d7%9d/)
    *   [צמחי בונסאי ומעוצבים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%95%d7%a0%d7%a1%d7%90%d7%99-%d7%95%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d/)
    *   [צמחים רבי מכר](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%a8%d7%91%d7%99-%d7%9e%d7%9b%d7%a8/)
    *   [חבילת צמחים לבית חדש](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%97%d7%91%d7%99%d7%9c%d7%aa-%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%91%d7%99%d7%aa-%d7%97%d7%93%d7%a9-%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/)
    *   [צמחים שאתם חייבים בבית!](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%a9%d7%90%d7%aa%d7%9d-%d7%97%d7%99%d7%99%d7%91%d7%99%d7%9d-%d7%91%d7%91%d7%99%d7%aa/)
    *   [צמחים מטהרי אוויר](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9e%d7%98%d7%94%d7%a8%d7%99-%d7%90%d7%95%d7%95%d7%99%d7%a8/)
    *   [צמחים מעוצבים בכלי בטון](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d-%d7%91%d7%9b%d7%9c%d7%99-%d7%91%d7%98%d7%95%d7%9f/)
    *   [סוקולנטים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d/)
    *   [טרריום וצמחי אוויר](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/%d7%98%d7%a8%d7%a8%d7%99%d7%95%d7%9d-%d7%95%d7%a6%d7%9e%d7%97%d7%99-%d7%90%d7%95%d7%95%d7%99%d7%a8/)
    *   [סחלבים](https://h-shtilshop.co.il/product-category/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)

*   [צמחיית חוץ](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/)
    *   [מבצעי אביב](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%9e%d7%91%d7%a6%d7%a2%d7%99-%d7%90%d7%91%d7%99%d7%91/)
    *   [עציצים למרפסת/גינה](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9c%d7%9e%d7%a8%d7%a4%d7%a1%d7%aa-%d7%92%d7%99%d7%a0%d7%94/)
    *   [צמחים לאדניות](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
    *   [צמחים מפיצי ריח](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9e%d7%a4%d7%99%d7%a6%d7%99-%d7%a8%d7%99%d7%97/)

*   [אדמה, דישון והדברה](https://h-shtilshop.co.il/product-category/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%93%d7%99%d7%a9%d7%95%d7%9f-%d7%95%d7%94%d7%93%d7%91%d7%a8%d7%94/)
*   [כלי שתילה ואקססוריז](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/)
    *   [פסלי גינה](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%a4%d7%a1%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%94/)
    *   [כלי שתילה דקורטיביים](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/)
        *   [פלסטיק איטליה](https://h-shtilshop.co.il/product-category/%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%90%d7%99%d7%98%d7%9c%d7%99%d7%94/)
        *   [אדניות פיבר – כלי פיבר](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/%d7%9b%d7%9c%d7%99-%d7%a4%d7%99%d7%91%d7%a8/)
            *   [כלי פיבר בטון](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a4%d7%99%d7%91%d7%a8-%d7%91%d7%98%d7%95%d7%9f/)

        *   [אדניות לשתילה](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%9c%d7%a9%d7%aa%d7%99%d7%9c%d7%94/)
        *   [כדי פלסטיק לשתילה](https://h-shtilshop.co.il/product-category/%d7%9b%d7%93%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)

    *   [הקולקציה ההודית](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/%d7%94%d7%a7%d7%95%d7%9c%d7%a7%d7%a6%d7%99%d7%94-%d7%94%d7%94%d7%95%d7%93%d7%99%d7%aa/)
    *   [כלים מקרמיקה](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/%d7%9b%d7%9c%d7%99-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%93%d7%a7%d7%95%d7%a8%d7%98%d7%99%d7%91%d7%99%d7%99%d7%9d/%d7%9b%d7%9c%d7%99%d7%9d-%d7%9e%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
    *   [שילוט](https://h-shtilshop.co.il/product-category/%d7%a9%d7%99%d7%9c%d7%95%d7%98/)

*   [מיוחד בשבילכם](https://h-shtilshop.co.il/product-category/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a2%d7%9d-%d7%97%d7%99%d7%99%d7%9d/)
    *   [עציצים מתנה לאירוע](https://h-shtilshop.co.il/product-category/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a2%d7%9d-%d7%97%d7%99%d7%99%d7%9d/%d7%a2%d7%a6%d7%99%d7%a6%d7%99%d7%9d-%d7%9e%d7%aa%d7%a0%d7%94-%d7%9c%d7%90%d7%99%d7%a8%d7%95%d7%a2/)

*   [חוויה ושתיל – עיצובים](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/)
    *   [עיצוב מרפסות](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%9e%d7%a8%d7%a4%d7%a1%d7%95%d7%aa-%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%a4%d7%a8%d7%98%d7%99/)
    *   [עיצוב משרדים](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%9e%d7%a9%d7%a8%d7%93%d7%99%d7%9d-%d7%a2%d7%99%d7%a6%d7%95%d7%91-%d7%a2%d7%a1%d7%a7%d7%99/)
    *   [חוויה ושתיל בבית האח הגדול 🧿](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/)
        *   [האח הגדול 2020](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2020/)
        *   [האח הגדול 2021](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2021/)
        *   [האח הגדול 2022](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2022/)
        *   [האח הגדול 2023](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2023/)
        *   [האח הגדול 2024](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2024/)
        *   [האח הגדול 2025](https://h-shtilshop.co.il/product-category/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2025/)
        *   [האח הגדול 2026](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%aa%d7%9b%d7%a0%d7%99%d7%aa-%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2026/)

    *   [צילומי הפקות](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/%d7%a6%d7%99%d7%9c%d7%95%d7%9e%d7%99-%d7%94%d7%a4%d7%a7%d7%95%d7%aa/)

*   [Gift Card🎁](https://h-shtilshop.co.il/product-category/gift-card%f0%9f%8e%81/)
*   [בואו לעבוד איתנו!](https://h-shtilshop.co.il/product-category/%d7%91%d7%95%d7%90%d7%95-%d7%9c%d7%a2%d7%91%d7%95%d7%93-%d7%90%d7%99%d7%aa%d7%a0%d7%95/)

[](https://h-shtilshop.co.il/%d7%a2%d7%92%d7%9c%d7%aa-%d7%a7%d7%a0%d7%99%d7%95%d7%aa/)

[](https://h-shtilshop.co.il/%D7%94%D7%97%D7%A9%D7%91%D7%95%D7%9F-%D7%A9%D7%9C%D7%99/)

[](https://h-shtilshop.co.il/?s=%D7%A4%D7%95%D7%AA%D7%95%D7%A1&post_type=product)

 Products search  

[עמוד הבית](https://h-shtilshop.co.il/)/[חנות](https://h-shtilshop.co.il/%D7%97%D7%A0%D7%95%D7%AA/)/תוצאות חיפוש עבור “פותוס”
# תוצאות חיפוש: "פותוס"

 לא נמצאו מוצרים התואמים את בחירתך. 

#### פוסטים אחרונים

*   [5 צמחי בית ש(כמעט) בלתי אפשרי להרוג (כן, גם אם אתם שכחנים!) 🌵💚 | חוויה ושתיל משתלה בראשון לציון](https://h-shtilshop.co.il/5-%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa-%d7%a9%d7%9b%d7%9e%d7%a2%d7%98-%d7%91%d7%9c%d7%aa%d7%99-%d7%90%d7%a4%d7%a9%d7%a8%d7%99-%d7%9c%d7%94%d7%a8%d7%95%d7%92-%d7%9b%d7%9f-%d7%92%d7%9d-%d7%90/)
*   [זן ואמנות אחזקת העציץ: למה הצמחים שלנו הם התרפיה הכי טובה שיש? 🧘‍♀️🌿 | חוויה ושתיל משתלה בראשון לציון](https://h-shtilshop.co.il/%d7%96%d7%9f-%d7%95%d7%90%d7%9e%d7%a0%d7%95%d7%aa-%d7%90%d7%97%d7%96%d7%a7%d7%aa-%d7%94%d7%a2%d7%a6%d7%99%d7%a5-%d7%9c%d7%9e%d7%94-%d7%94%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95-%d7%94/)
*   [גינת תה (וקוקטיילים!) במרפסת שלכם 🍹🌿 | חוויה ושתיל משתלה בראשון לציון](https://h-shtilshop.co.il/%d7%92%d7%99%d7%a0%d7%aa-%d7%aa%d7%94-%d7%95%d7%a7%d7%95%d7%a7%d7%98%d7%99%d7%99%d7%9c%d7%99%d7%9d-%d7%91%d7%9e%d7%a8%d7%a4%d7%a1%d7%aa-%d7%a9%d7%9c%d7%9b%d7%9d-%f0%9f%8d%b9%f0%9f%8c%bf/)
*   [מתכוננים לקיץ הישראלי: מה שותלים עכשיו? ☀️🌻 | חוויה ושתיל משתלה בראשון לציון](https://h-shtilshop.co.il/%d7%9e%d7%aa%d7%9b%d7%95%d7%a0%d7%a0%d7%99%d7%9d-%d7%9c%d7%a7%d7%99%d7%a5-%d7%94%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99-%d7%9e%d7%94-%d7%a9%d7%95%d7%aa%d7%9c%d7%99%d7%9d-%d7%a2%d7%9b%d7%a9%d7%99%d7%95/)
*   [5 טעויות שאנחנו עושים עם שתילות עונתיות (ואיך לתקן אותן בקלות!) 🍂☀️ | חוויה ושתיל משתלה בראשון לציון](https://h-shtilshop.co.il/5-%d7%98%d7%a2%d7%95%d7%99%d7%95%d7%aa-%d7%a9%d7%90%d7%a0%d7%97%d7%a0%d7%95-%d7%a2%d7%95%d7%a9%d7%99%d7%9d-%d7%a2%d7%9d-%d7%a9%d7%aa%d7%99%d7%9c%d7%95%d7%aa-%d7%a2%d7%95%d7%a0%d7%aa%d7%99%d7%95%d7%aa/)

#### קטגוריות מוצרים

*   [Black Friday](https://h-shtilshop.co.il/product-category/black-friday/)
*   [Gift Card🎁](https://h-shtilshop.co.il/product-category/gift-card%f0%9f%8e%81/)
*   [אדמה, דישון והדברה](https://h-shtilshop.co.il/product-category/%d7%9e%d7%95%d7%a6%d7%a8%d7%99-%d7%93%d7%99%d7%a9%d7%95%d7%9f-%d7%95%d7%94%d7%93%d7%91%d7%a8%d7%94/)
*   [אדניות](https://h-shtilshop.co.il/product-category/%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa/)
*   [בלון](https://h-shtilshop.co.il/product-category/%d7%91%d7%9c%d7%95%d7%9f/)
*   [האח הגדול 2025](https://h-shtilshop.co.il/product-category/%d7%94%d7%90%d7%97-%d7%94%d7%92%d7%93%d7%95%d7%9c-2025/)
*   [הנמכרים ביותר עמוד בית](https://h-shtilshop.co.il/product-category/%d7%94%d7%a0%d7%9e%d7%9b%d7%a8%d7%99%d7%9d-%d7%91%d7%99%d7%95%d7%aa%d7%a8-%d7%a2%d7%9e%d7%95%d7%93-%d7%91%d7%99%d7%aa/)
*   [הצעות ליום האישה🎁](https://h-shtilshop.co.il/product-category/%d7%94%d7%a6%d7%a2%d7%95%d7%aa-%d7%9c%d7%99%d7%95%d7%9d-%d7%94%d7%90%d7%99%d7%a9%d7%94/)
*   [זר אישי](https://h-shtilshop.co.il/product-category/%d7%96%d7%a8-%d7%90%d7%99%d7%a9%d7%99/)
*   [זרי כלה](https://h-shtilshop.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
*   [חג שבועות 🌾](https://h-shtilshop.co.il/product-category/%d7%97%d7%92-%d7%a9%d7%91%d7%95%d7%a2%d7%95%d7%aa/)
*   [חגי תשרי 🍏🍯🍁🎉](https://h-shtilshop.co.il/product-category/%d7%97%d7%92%d7%99-%d7%aa%d7%a9%d7%a8%d7%99-%f0%9f%8d%8f%f0%9f%8d%af%f0%9f%8d%81%f0%9f%8e%89/)
*   [חוגגים 33 🎁](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%92%d7%92%d7%99%d7%9d-33-%f0%9f%8e%81/)
*   [חוויה ושתיל - עיצובים](https://h-shtilshop.co.il/product-category/%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c-%d7%9c%d7%a2%d7%a1%d7%a7%d7%99%d7%9d/)
*   [ט"ו באב ❤️](https://h-shtilshop.co.il/product-category/%d7%98%d7%95-%d7%91%d7%90%d7%91/)
*   [יין](https://h-shtilshop.co.il/product-category/%d7%99%d7%99%d7%9f/)
*   [כדי פלסטיק לשתילה](https://h-shtilshop.co.il/product-category/%d7%9b%d7%93%d7%99-%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
*   [כלי שתילה ואקססוריז](https://h-shtilshop.co.il/product-category/%d7%90%d7%a7%d7%a1%d7%a1%d7%95%d7%a8%d7%99%d7%96/)
*   [כרטיסי ברכה מעוצבים](https://h-shtilshop.co.il/product-category/%d7%9b%d7%a8%d7%98%d7%99%d7%a1%d7%99-%d7%91%d7%a8%d7%9b%d7%94-%d7%9e%d7%a2%d7%95%d7%a6%d7%91%d7%99%d7%9d/)
*   [לוולנטיין 💞](https://h-shtilshop.co.il/product-category/%d7%95%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%99%d7%9f-%d7%93%d7%99%d7%99/)
*   [ליום המשפחה 👨‍👩‍👧‍👧](https://h-shtilshop.co.il/product-category/%d7%99%d7%95%d7%9d-%d7%94%d7%9e%d7%a9%d7%a4%d7%97%d7%94/)
*   [לצד הפרחים](https://h-shtilshop.co.il/product-category/%d7%9c%d7%a6%d7%93-%d7%94%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
*   [מיוחד בשבילכם](https://h-shtilshop.co.il/product-category/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%a2%d7%9d-%d7%97%d7%99%d7%99%d7%9d/)
*   [מיקס 2022](https://h-shtilshop.co.il/product-category/%d7%9e%d7%99%d7%a7%d7%a1-2022-%d7%97%d7%95%d7%95%d7%99%d7%94-%d7%95%d7%a9%d7%aa%d7%99%d7%9c/)
*   [סחלבים](https://h-shtilshop.co.il/product-category/%d7%a1%d7%97%d7%9c%d7%91%d7%99%d7%9d/)
*   [פלסטיק איטליה](https://h-shtilshop.co.il/product-category/%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7-%d7%90%d7%99%d7%98%d7%9c%d7%99%d7%94/)
*   [פסח 2026 🌺](https://h-shtilshop.co.il/product-category/%d7%a4%d7%a1%d7%97-2024/)
*   [פרחים](https://h-shtilshop.co.il/product-category/%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
*   [צמחי בית](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%91%d7%99%d7%aa/)
*   [צמחי פנים](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%a4%d7%a0%d7%99%d7%9d/)
*   [צמחיית חוץ](https://h-shtilshop.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%99%d7%aa-%d7%97%d7%95%d7%a5/)
*   [ראש השנה 🍏🍯](https://h-shtilshop.co.il/product-category/%d7%a8%d7%90%d7%a9-%d7%94%d7%a9%d7%a0%d7%94-%f0%9f%8d%8f%f0%9f%8d%af/)
*   [שוקולד](https://h-shtilshop.co.il/product-category/%d7%a9%d7%95%d7%a7%d7%95%d7%9c%d7%93/)
*   [שילוט](https://h-shtilshop.co.il/product-category/%d7%a9%d7%99%d7%9c%d7%95%d7%98/)
*   [תוספות שוות](https://h-shtilshop.co.il/product-category/%d7%aa%d7%95%d7%a1%d7%a4%d7%95%d7%aa-%d7%a9%d7%95%d7%95%d7%aa/)

### איזור אישי

*   [הזמנות](https://h-shtilshop.co.il/%d7%94%d7%97%d7%a9%d7%91%d7%95%d7%9f-%d7%a9%d7%9c%d7%99/orders/)
*   [פרטי חשבון](https://h-shtilshop.co.il/%d7%94%d7%97%d7%a9%d7%91%d7%95%d7%9f-%d7%a9%d7%9c%d7%99/edit-account/)
*   [משלוחים](https://h-shtilshop.co.il/%d7%9e%d7%a9%d7%9c%d7%95%d7%97%d7%99%d7%9d/)
*   [מדיניות פרטיות](https://h-shtilshop.co.il/%d7%9e%d7%93%d7%99%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%a8%d7%98%d7%99%d7%95%d7%aa/)
*   [תקנון](https://h-shtilshop.co.il/%d7%aa%d7%a7%d7%a0%d7%95%d7%9f/)
*   [Cookie Policy (EU)](https://h-shtilshop.co.il/cookie-policy-eu/)
*   [הצהרת נגישות](https://h-shtilshop.co.il/%d7%94%d7%a6%d7%94%d7%a8%d7%aa-%d7%a0%d7%92%d7%99%d7%a9%d7%95%d7%aa/)

תשלום מאובטח על ידי

![Image 2: mastercard](https://h-shtilshop.co.il/wp-content/uploads/2020/05/mastercard.png)

![Image 3: visa](https://h-shtilshop.co.il/wp-content/uploads/2020/05/visa.png)

![Image 4: american_express](https://h-shtilshop.co.il/wp-content/uploads/2020/05/american_express.png)

[דף הבית](https://h-shtilshop.co.il/)

[אודות](https://h-shtilshop.co.il/%D7%90%D7%95%D7%93%D7%95%D7%AA)

[צמחי פנים](https://h-shtilshop.co.il/product-category/%D7%A6%D7%9E%D7%97%D7%99-%D7%A4%D7%A0%D7%99%D7%9D/)

[צמחיית חוץ](https://h-shtilshop.co.il/product-category/%D7%A6%D7%9E%D7%97%D7%99%D7%99%D7%AA-%D7%97%D7%95%D7%A5/)

[חוויה ושתיל לעסקים](https://h-shtilshop.co.il/product-category/%D7%97%D7%95%D7%95%D7%99%D7%94-%D7%95%D7%A9%D7%AA%D7%99%D7%9C-%D7%9C%D7%A2%D7%A1%D7%A7%D7%99%D7%9D/)

[צור קשר](https://h-shtilshop.co.il/%D7%A6%D7%95%D7%A8-%D7%A7%D7%A9%D7%A8/)

[מאמרים](https://h-shtilshop.co.il/category/%D7%9E%D7%90%D7%9E%D7%A8%D7%99%D7%9D/)

*   [Follow](https://www.facebook.com/havayavashtil/ "Follow on Facebook")
*   [Follow](https://www.instagram.com/havaia_and_shtil/ "Follow on Instagram")

### צור קשר

**כתובת**

 דרך המכבים 71,

 ראשון לציון

 כביש בית דגן

**שעות פעילות**

 א'-ה' 08:30 – 16:30

 ו' עד 08:30 – 16:30

 שבת 08:30 – 16:30

[03-9675005](tel:03-9675005)

**אימייל**

[h.shtilshop@gmail.com](mailto:h.shtilshop@gmail.com)

כל הזכויות והתמונות שמורות לחוויה ושתיל ©

[בניית אתרים](https://www.smartsoftweb.com/)Smart Soft Web

[הרשמה למועדון לקוחות](https://s1c.me/havaya_ve_join)

להטבת מועדון התקשרו

[03-9675005](tel:03-9675005)

העדפות פרטיות

עגלת קניות 0

אין מוצרים בעגלה!

המשך בקניות

0

 Products search  

WhatsApp us