[![Plants](https://mashtelatramatgan.co.il/wp-content/uploads/2021/08/logo-clean-1.png)](https://mashtelatramatgan.co.il)

* [קטלוג צמחים](#)
  + [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/)
  + [צמחים לצל מלא](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a6%d7%9c-%d7%9e%d7%9c%d7%90/)
  + [צמחים לשמש מלאה](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/)
    - [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/)
    - [עצי הדר](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/%d7%a2%d7%a6%d7%99-%d7%94%d7%93%d7%a8/)
    - [קקטוסים](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/%d7%a7%d7%a7%d7%98%d7%95%d7%a1%d7%99%d7%9d/)
    - [סוקולנטים](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/%d7%a1%d7%95%d7%a7%d7%95%d7%9c%d7%a0%d7%98%d7%99%d7%9d-%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a9%d7%9e%d7%a9-%d7%9e%d7%9c%d7%90%d7%94/)
  + [צמחים חצי צל חצי שמש](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%97%d7%a6%d7%99-%d7%a6%d7%9c-%d7%97%d7%a6%d7%99-%d7%a9%d7%9e%d7%a9/)
  + [צמחים שקשה להרוג](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%a9%d7%a7%d7%a9%d7%94-%d7%9c%d7%94%d7%a8%d7%95%d7%92/)
  + [המיוחדים מהולנד](https://mashtelatramatgan.co.il/product-category/%d7%94%d7%9e%d7%99%d7%95%d7%97%d7%93%d7%99%d7%9d-%d7%9e%d7%94%d7%95%d7%9c%d7%a0%d7%93/)
  + [זרעים ופקעות](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%a2%d7%99%d7%9d-%d7%95%d7%a4%d7%a7%d7%a2%d7%95%d7%aa/)
  + [צמחי תבלין](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99-%d7%aa%d7%91%d7%9c%d7%99%d7%9f/)
  + [צמח + כלי as is](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99-as-is/)
* [קטלוג אדניות וכלים](#)
  + [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/)
  + [תלייה](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%aa%d7%9c%d7%99%d7%99%d7%94/)
  + [קרמיקה](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94/)
  + [פיבר](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a4%d7%99%d7%91%d7%a8/)
  + [פוליאתילן](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a4%d7%95%d7%9c%d7%99%d7%90%d7%aa%d7%99%d7%9c%d7%9f/)
  + [זכוכית](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%96%d7%9b%d7%95%d7%9b%d7%99%d7%aa/)
  + [פלסטיק](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a4%d7%9c%d7%a1%d7%98%d7%99%d7%a7/)
  + [עץ](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a2%d7%a5/)
  + [קש](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%90%d7%93%d7%a0%d7%99%d7%95%d7%aa-%d7%95%d7%9b%d7%9c%d7%99%d7%9d/%d7%a7%d7%a9/)
* [כלי גינון השקיה ועוד](#)
  + [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/)
  + [השקיה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%94%d7%a9%d7%a7%d7%99%d7%94/)
  + [צנרת](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%a6%d7%a0%d7%a8%d7%aa/)
  + [מחברי השקיה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%9e%d7%97%d7%91%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%94/)
  + [אביזרי השקיה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%94%d7%a9%d7%a7%d7%99%d7%94/)
  + [מערכות השקיה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%9e%d7%a2%d7%a8%d7%9b%d7%95%d7%aa-%d7%94%d7%a9%d7%a7%d7%99%d7%94/)
  + [אביזרי גינה](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%90%d7%91%d7%99%d7%96%d7%a8%d7%99-%d7%92%d7%99%d7%a0%d7%94/)
  + [תאורה סולארית](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%aa%d7%90%d7%95%d7%a8%d7%94-%d7%a1%d7%95%d7%9c%d7%90%d7%a8%d7%99%d7%aa/)
  + [מזרקות](https://mashtelatramatgan.co.il/product-category/%d7%9b%d7%9c%d7%99-%d7%92%d7%99%d7%a0%d7%95%d7%9f-%d7%94%d7%a9%d7%a7%d7%99%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%9e%d7%96%d7%a8%d7%a7%d7%95%d7%aa/)
* [אדמת שתילה ועוד](#)
  + [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/)
  + [תערובת שתילה](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%aa%d7%a2%d7%a8%d7%95%d7%91%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94/)
  + [דשנים והדברה](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%93%d7%a9%d7%a0%d7%99%d7%9d-%d7%95%d7%94%d7%93%d7%91%d7%a8%d7%94/)
  + [טוף](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%98%d7%95%d7%a3/)
  + [חלוקי נחל](https://mashtelatramatgan.co.il/product-category/%d7%90%d7%93%d7%9e%d7%aa-%d7%a9%d7%aa%d7%99%d7%9c%d7%94-%d7%95%d7%a2%d7%95%d7%93/%d7%97%d7%9c%d7%95%d7%a7%d7%99-%d7%a0%d7%97%d7%9c/)
* [זרי פרחים](#)
  + [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [זרי פרחים](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [מארזי פרחים](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%9e%d7%90%d7%a8%d7%96%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/)
  + [זרים לראש](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%96%d7%a8%d7%99%d7%9d-%d7%9c%d7%a8%d7%90%d7%a9/)
  + [זרי כלה](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%96%d7%a8%d7%99-%d7%9b%d7%9c%d7%94/)
  + [קישוט רכבים](https://mashtelatramatgan.co.il/product-category/%d7%96%d7%a8%d7%99-%d7%a4%d7%a8%d7%97%d7%99%d7%9d/%d7%a7%d7%99%d7%a9%d7%95%d7%98-%d7%a8%d7%9b%d7%91%d7%99%d7%9d/)
* [צמחיה מלאכותית](https://mashtelatramatgan.co.il/product-category/%d7%a6%d7%9e%d7%97%d7%99%d7%94-%d7%9e%d7%9c%d7%90%d7%9b%d7%95%d7%aa%d7%99%d7%aa/)
* [קטלוג ריהוט גן](https://mashtelatramatgan.co.il/product-category/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a8%d7%99%d7%94%d7%95%d7%98-%d7%92%d7%9f/)
* [גיפט-קארד מתנות ועוד](#)
  + [צפו בהכל](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/)
  + [יינות ומארזי שוקולד](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/%d7%99%d7%99%d7%a0%d7%95%d7%aa-%d7%95%d7%9e%d7%90%d7%a8%d7%96%d7%99-%d7%a9%d7%95%d7%a7%d7%95%d7%9c%d7%93/)
  + [בלוני הליום](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/%d7%91%d7%9c%d7%95%d7%a0%d7%99-%d7%94%d7%9c%d7%99%d7%95%d7%9d/)
  + [כרטיסי ברכה](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/%d7%9b%d7%a8%d7%98%d7%99%d7%a1%d7%99-%d7%91%d7%a8%d7%9b%d7%94-%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/)
  + [מתנות וקישוטי נוי](https://mashtelatramatgan.co.il/product-category/%d7%92%d7%99%d7%a4%d7%98-%d7%a7%d7%90%d7%a8%d7%93-%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a2%d7%95%d7%93/%d7%9e%d7%aa%d7%a0%d7%95%d7%aa-%d7%95%d7%a7%d7%99%d7%a9%d7%95%d7%98%d7%99-%d7%a0%d7%95%d7%99/)
* [אודותינו](https://mashtelatramatgan.co.il/%d7%90%d7%95%d7%93%d7%95%d7%aa%d7%99%d7%a0%d7%95/)
* [השירותים שלנו](https://mashtelatramatgan.co.il/%d7%94%d7%a9%d7%99%d7%a8%d7%95%d7%aa%d7%99%d7%9d-%d7%a9%d7%9c%d7%a0%d7%95/)
* [טלפון: 03-7509080](tel:03-7509080)

# Search Results for: מונסטרה

₪ 59 — ₪ 298

גובה מקסימלי

0cm — 1000cm

רוחב מקסימלי

0cm — 1000cm

תנאי השקיה

תנאי תאורה

עונתיות

[![מונסטרה בכלי קרמיקה בשילוב חלוקי נחל צבע שחור](https://mashtelatramatgan.co.il/wp-content/uploads/2020/08/מונסטרה-בעלי-קרמיקה-בשילוב-חלוקי-נחל-צבע-שחור-600x600.jpg)](https://mashtelatramatgan.co.il/shop/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99-as-is/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%9b%d7%9c%d7%99-%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94-%d7%91%d7%a9%d7%99%d7%9c%d7%95%d7%91-%d7%97%d7%9c%d7%95%d7%a7%d7%99-%d7%a0%d7%97%d7%9c-%d7%a6/)

[מונסטרה בכלי קרמיקה בשילוב...](https://mashtelatramatgan.co.il/shop/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99-as-is/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%9b%d7%9c%d7%99-%d7%a7%d7%a8%d7%9e%d7%99%d7%a7%d7%94-%d7%91%d7%a9%d7%99%d7%9c%d7%95%d7%91-%d7%97%d7%9c%d7%95%d7%a7%d7%99-%d7%a0%d7%97%d7%9c-%d7%a6/)

₪99.00

[הוספה לסל](?add-to-cart=12422)

[![מונסטרה בשילוב כלי קש עבודת יד](https://mashtelatramatgan.co.il/wp-content/uploads/2020/08/מונסטרה-בשילוב-כלי-קש-עבודת-יד-600x600.jpg)](https://mashtelatramatgan.co.il/shop/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99-as-is/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%a9%d7%99%d7%9c%d7%95%d7%91-%d7%9b%d7%9c%d7%99-%d7%a7%d7%a9-%d7%a2%d7%91%d7%95%d7%93%d7%aa-%d7%99%d7%93/)

[מונסטרה בשילוב כלי קש...](https://mashtelatramatgan.co.il/shop/%d7%a7%d7%98%d7%9c%d7%95%d7%92-%d7%a6%d7%9e%d7%97%d7%99%d7%9d/%d7%a6%d7%9e%d7%97-%d7%9b%d7%9c%d7%99-as-is/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%91%d7%a9%d7%99%d7%9c%d7%95%d7%91-%d7%9b%d7%9c%d7%99-%d7%a7%d7%a9-%d7%a2%d7%91%d7%95%d7%93%d7%aa-%d7%99%d7%93/)

₪298.00

[הוספה לסל](?add-to-cart=12423)

[![מונסטרה מאנקי - Monstera Monkey](https://mashtelatramatgan.co.il/wp-content/uploads/2020/07/מונסטרה-מאנקי-600x600.jpg)](https://mashtelatramatgan.co.il/shop/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a6%d7%9c-%d7%9e%d7%9c%d7%90/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%90%d7%a0%d7%a7%d7%99-%d7%a6%d7%9e%d7%97%d7%99-%d7%92%d7%9f-%d7%95%d7%92%d7%99%d7%a0%d7%94/)

[מונסטרה מאנקי – Monstera...](https://mashtelatramatgan.co.il/shop/%d7%a6%d7%9e%d7%97%d7%99%d7%9d-%d7%9c%d7%a6%d7%9c-%d7%9e%d7%9c%d7%90/%d7%9e%d7%95%d7%a0%d7%a1%d7%98%d7%a8%d7%94-%d7%9e%d7%90%d7%a0%d7%a7%d7%99-%d7%a6%d7%9e%d7%97%d7%99-%d7%92%d7%9f-%d7%95%d7%92%d7%99%d7%a0%d7%94/)

₪59.00

[הוספה לסל](?add-to-cart=12424)

![](https://mashtelatramatgan.co.il/wp-content/uploads/2020/01/good.svg)

התאמת צמחים מדוייקת

![](https://mashtelatramatgan.co.il/wp-content/uploads/2020/01/sofa.svg)

מכל מקום ובכל זמן

![](https://mashtelatramatgan.co.il/wp-content/uploads/2020/01/award.svg)

איכות ללא פשרות

![](https://mashtelatramatgan.co.il/wp-content/uploads/2020/01/truck.svg)

מגיעים עד אליך

[דילוג לתוכן](#content)
 